import 'package:flutter/material.dart';
import '../models/app_state.dart';

class ReportsScreen extends StatefulWidget {
  const ReportsScreen({Key? key}) : super(key: key);

  @override
  ReportsScreenState createState() => ReportsScreenState();
}

class ReportsScreenState extends State<ReportsScreen> {
  String _selectedReportType = 'Daily Reports';

  final List<AttendanceSession> _sessions = [
    AttendanceSession(
      courseCode: 'CS301',
      courseName: 'Data Structures',
      dateTime: DateTime.now(),
      presentCount: 28,
      totalCount: 35,
    ),
    AttendanceSession(
      courseCode: 'MATH201',
      courseName: 'Linear Algebra',
      dateTime: DateTime.now(),
      presentCount: 42,
      totalCount: 45,
    ),
    AttendanceSession(
      courseCode: 'PHY401',
      courseName: 'Quantum Physics',
      dateTime: DateTime.now().subtract(const Duration(days: 1)),
      presentCount: 18,
      totalCount: 25,
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        children: [
          // Report Type Selector
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 12),
            decoration: BoxDecoration(
              border: Border.all(color: Theme.of(context).dividerColor, width: 2),
              borderRadius: BorderRadius.circular(8),
            ),
            child: DropdownButtonHideUnderline(
              child: DropdownButton<String>(
                value: _selectedReportType,
                isExpanded: true,
                items: [
                  'Daily Reports',
                  'Weekly Reports',
                  'Monthly Reports',
                  'Course Reports',
                ].map((type) => DropdownMenuItem(value: type, child: Text(type))).toList(),
                onChanged: (value) {
                  setState(() {
                    _selectedReportType = value ?? 'Daily Reports';
                  });
                },
              ),
            ),
          ),
          const SizedBox(height: 25),

          // Stats Row
          Row(
            children: [
              Expanded(child: _buildStatCard('85%', 'Avg Attendance')),
              const SizedBox(width: 12),
              Expanded(child: _buildStatCard('1,240', 'Total Check-ins')),
              const SizedBox(width: 12),
              Expanded(child: _buildStatCard('23', 'Sessions Today')),
            ],
          ),
          const SizedBox(height: 25),

          // Recent Sessions Table
          Container(
            decoration: BoxDecoration(
              color: Theme.of(context).cardColor,
              borderRadius: BorderRadius.circular(8),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.1),
                  blurRadius: 8,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Column(
              children: [
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(15),
                  decoration: BoxDecoration(
                    color: Theme.of(context).brightness == Brightness.dark
                        ? const Color(0xFF2d2d2d)
                        : const Color(0xFFf8f9fa),
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(8),
                      topRight: Radius.circular(8),
                    ),
                    border: Border(
                      bottom: BorderSide(color: Theme.of(context).dividerColor),
                    ),
                  ),
                  child: Text(
                    'Recent Attendance Sessions',
                    style: TextStyle(
                      fontWeight: FontWeight.w600,
                      color: Theme.of(context).textTheme.bodyLarge?.color,
                    ),
                  ),
                ),
                ..._sessions.map((session) => _buildSessionRow(session)).toList(),
              ],
            ),
          ),
          const SizedBox(height: 20),

          // Export Button
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: _exportReports,
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF667eea),
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 12),
              ),
              child: const Text('Export Reports'),
            ),
          ),
          const SizedBox(height: 100), // Bottom padding
        ],
      ),
    );
  }

  Widget _buildStatCard(String number, String label) {
    return Container(
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(10),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.1),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        children: [
          Text(
            number,
            style: const TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: Color(0xFF667eea),
            ),
          ),
          const SizedBox(height: 5),
          Text(
            label,
            style: TextStyle(
              fontSize: 12,
              color: Theme.of(context).textTheme.bodyMedium?.color,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildSessionRow(AttendanceSession session) {
    final isToday = DateTime.now().difference(session.dateTime).inDays == 0;
    final timeString = isToday ? 'Today' : 'Yesterday';
    final percentage = session.percentage.round();

    Color badgeColor;
    if (percentage >= 90) {
      badgeColor = const Color(0xFFd4edda);
    } else if (percentage >= 75) {
      badgeColor = const Color(0xFFfff3cd);
    } else {
      badgeColor = const Color(0xFFf8d7da);
    }

    return Container(
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        border: Border(
          bottom: BorderSide(color: Theme.of(context).dividerColor),
        ),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '${session.courseCode} - ${session.courseName}',
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: Theme.of(context).textTheme.bodyLarge?.color,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  '$timeString ${session.dateTime.hour}:${session.dateTime.minute.toString().padLeft(2, '0')} • ${session.presentCount}/${session.totalCount} students',
                  style: TextStyle(
                    fontSize: 12,
                    color: Theme.of(context).textTheme.bodyMedium?.color,
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: badgeColor,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Text(
              '$percentage%',
              style: TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w500,
                color: percentage >= 90 ? const Color(0xFF155724) :
                       percentage >= 75 ? const Color(0xFF856404) : const Color(0xFF721c24),
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _exportReports() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Reports exported successfully!'),
        duration: Duration(seconds: 2),
      ),
    );
  }
}
