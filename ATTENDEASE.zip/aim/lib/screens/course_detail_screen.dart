import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../models/course.dart';
import '../models/course_status.dart';

class CourseDetailScreen extends StatefulWidget {
  final Course course;
  final bool isDarkMode;

  const CourseDetailScreen({
    Key? key,
    required this.course,
    required this.isDarkMode,
  }) : super(key: key);

  @override
  State<CourseDetailScreen> createState() => _CourseDetailScreenState();
}

class _CourseDetailScreenState extends State<CourseDetailScreen>
    with TickerProviderStateMixin {
  late TabController _tabController;
  bool _isBookmarked = false;

  // Sample data for the course
  final List<Announcement> _announcements = [
    Announcement(
      id: '1',
      title: 'Course Canceled - December 10th',
      content: 'Due to unforeseen circumstances, today\'s lecture has been canceled. Please review Chapter 5 materials for next class.',
      lecturer: 'Dr. Sarah Johnson',
      timestamp: DateTime.now().subtract(Duration(hours: 2)),
      type: AnnouncementType.courseCanceled,
      isUrgent: true,
    ),
    Announcement(
      id: '2',
      title: 'Assignment 3 Due Date Extended',
      content: 'The due date for Assignment 3 has been extended to December 15th. Please submit your work through the course portal.',
      lecturer: 'Dr. Sarah Johnson',
      timestamp: DateTime.now().subtract(Duration(days: 1)),
      type: AnnouncementType.assignment,
      isUrgent: false,
    ),
    Announcement(
      id: '3',
      title: 'New Course Materials Available',
      content: 'I\'ve uploaded additional reading materials for Chapter 6. Please download them from the materials section.',
      lecturer: 'Dr. Sarah Johnson',
      timestamp: DateTime.now().subtract(Duration(days: 2)),
      type: AnnouncementType.materials,
      isUrgent: false,
    ),
    Announcement(
      id: '4',
      title: 'Midterm Exam Schedule',
      content: 'The midterm examination will be held on December 20th at 2:00 PM in Room 301. Please bring your student ID and calculator.',
      lecturer: 'Dr. Sarah Johnson',
      timestamp: DateTime.now().subtract(Duration(days: 3)),
      type: AnnouncementType.exam,
      isUrgent: true,
    ),
  ];

  final List<Assignment> _assignments = [
    Assignment(
      id: '1',
      title: 'Data Structures Implementation',
      description: 'Implement basic data structures including linked lists, stacks, and queues using your preferred programming language.',
      dueDate: DateTime.now().add(Duration(days: 5)),
      maxPoints: 100,
      submissionStatus: SubmissionStatus.notSubmitted,
      attachments: ['assignment_3_requirements.pdf'],
    ),
    Assignment(
      id: '2',
      title: 'Algorithm Analysis Report',
      description: 'Write a comprehensive report analyzing the time and space complexity of sorting algorithms.',
      dueDate: DateTime.now().add(Duration(days: 12)),
      maxPoints: 80,
      submissionStatus: SubmissionStatus.notSubmitted,
      attachments: ['algorithm_analysis_template.docx'],
    ),
    Assignment(
      id: '3',
      title: 'Binary Tree Traversal',
      description: 'Implement and demonstrate different binary tree traversal methods with visual representation.',
      dueDate: DateTime.now().subtract(Duration(days: 2)),
      maxPoints: 90,
      submissionStatus: SubmissionStatus.submitted,
      submittedDate: DateTime.now().subtract(Duration(days: 3)),
      grade: 85,
      attachments: [],
    ),
  ];

  final List<CourseMaterial> _materials = [
    CourseMaterial(
      id: '1',
      title: 'Chapter 6: Advanced Data Structures',
      description: 'Comprehensive guide to advanced data structures including B-trees, heaps, and hash tables.',
      type: MaterialType.pdf,
      size: '2.5 MB',
      uploadDate: DateTime.now().subtract(Duration(days: 1)),
      downloadCount: 45,
      isNew: true,
    ),
    CourseMaterial(
      id: '2',
      title: 'Lecture 12: Graph Algorithms',
      description: 'Video recording of the lecture covering graph algorithms including DFS, BFS, and shortest path algorithms.',
      type: MaterialType.video,
      size: '156 MB',
      uploadDate: DateTime.now().subtract(Duration(days: 3)),
      downloadCount: 32,
      duration: '1h 25m',
    ),
    CourseMaterial(
      id: '3',
      title: 'Code Examples: Sorting Algorithms',
      description: 'Complete source code examples for various sorting algorithms with detailed comments.',
      type: MaterialType.code,
      size: '45 KB',
      uploadDate: DateTime.now().subtract(Duration(days: 5)),
      downloadCount: 67,
    ),
    CourseMaterial(
      id: '4',
      title: 'Practice Problems Set 3',
      description: 'Additional practice problems for data structures and algorithms with solutions.',
      type: MaterialType.document,
      size: '1.2 MB',
      uploadDate: DateTime.now().subtract(Duration(days: 7)),
      downloadCount: 89,
    ),
  ];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Color get backgroundColor => widget.isDarkMode ? const Color(0xFF1a1a2e) : const Color(0xFFF8F9FA);
  Color get cardColor => widget.isDarkMode ? const Color(0xFF2d2d42) : Colors.white;
  Color get textColor => widget.isDarkMode ? Colors.white : const Color(0xFF2D3748);
  Color get subtitleColor => widget.isDarkMode ? Colors.grey[400]! : const Color(0xFF718096);

  LinearGradient get primaryGradient => const LinearGradient(
    colors: [Color(0xFF667eea), Color(0xFF764ba2)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: backgroundColor,
      body: CustomScrollView(
        slivers: [
          _buildSliverAppBar(),
          SliverFillRemaining(
            child: Column(
              children: [
                _buildCourseInfo(),
                _buildTabBar(),
                Expanded(
                  child: TabBarView(
                    controller: _tabController,
                    children: [
                      _buildOverviewTab(),
                      _buildAnnouncementsTab(),
                      _buildAssignmentsTab(),
                      _buildMaterialsTab(),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSliverAppBar() {
    return SliverAppBar(
      expandedHeight: 200,
      floating: false,
      pinned: true,
      backgroundColor: backgroundColor,
      leading: IconButton(
        onPressed: () => Navigator.pop(context),
        icon: Icon(Icons.arrow_back, color: textColor),
      ),
      actions: [
        IconButton(
          onPressed: () {
            setState(() => _isBookmarked = !_isBookmarked);
            HapticFeedback.lightImpact();
            _showSnackBar(_isBookmarked ? 'Course bookmarked' : 'Bookmark removed');
          },
          icon: Icon(
            _isBookmarked ? Icons.bookmark : Icons.bookmark_border,
            color: _isBookmarked ? Colors.amber : textColor,
          ),
        ),
        IconButton(
          onPressed: () => _showShareDialog(),
          icon: Icon(Icons.share, color: textColor),
        ),
      ],
      flexibleSpace: FlexibleSpaceBar(
        background: Container(
          decoration: BoxDecoration(
            gradient: primaryGradient,
          ),
          child: SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.end,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(
                      widget.course.code,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    widget.course.name,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    widget.course.lecturer,
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.9),
                      fontSize: 16,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildCourseInfo() {
    return Container(
      margin: const EdgeInsets.all(16),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: cardColor,
        borderRadius: BorderRadius.circular(16),
        boxShadow: widget.isDarkMode ? [] : [
          BoxShadow(
            color: Colors.black.withOpacity(0.06),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        children: [
          Expanded(
            child: _buildInfoItem(
              Icons.schedule,
              'Schedule',
              widget.course.schedule,
            ),
          ),
          Container(
            width: 1,
            height: 40,
            color: subtitleColor.withOpacity(0.3),
          ),
          Expanded(
            child: _buildInfoItem(
              Icons.school,
              'Credits',
              '${widget.course.creditHours} ',
            ),
          ),
          Container(
            width: 1,
            height: 40,
            color: subtitleColor.withOpacity(0.3),
          ),
          Expanded(
            child: _buildInfoItem(
              Icons.trending_up,
              'Attendance',
              '${widget.course.attendancePercentage.toInt()}%',
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoItem(IconData icon, String label, String value) {
    return Column(
      children: [
        Icon(icon, color: const Color(0xFF667eea), size: 24),
        const SizedBox(height: 8),
        Text(
          value,
          style: TextStyle(
            color: textColor,
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
        Text(
          label,
          style: TextStyle(
            color: subtitleColor,
            fontSize: 12,
          ),
        ),
      ],
    );
  }

  Widget _buildTabBar() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      decoration: BoxDecoration(
        color: cardColor,
        borderRadius: BorderRadius.circular(12),
        boxShadow: widget.isDarkMode ? [] : [
          BoxShadow(
            color: Colors.black.withOpacity(0.06),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: TabBar(
        controller: _tabController,
        labelColor: Colors.white,
        unselectedLabelColor: subtitleColor,
        indicator: BoxDecoration(
          gradient: primaryGradient,
          borderRadius: BorderRadius.circular(8),
        ),
        indicatorSize: TabBarIndicatorSize.tab,
        dividerColor: Colors.transparent,
        tabs: const [
          Tab(text: 'Overview'),
          Tab(text: 'Announcements'),
          Tab(text: 'Assignments'),
          Tab(text: 'Materials'),
        ],
      ),
    );
  }

  Widget _buildOverviewTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildSectionHeader('Course Statistics'),
          _buildStatsCard(),
          const SizedBox(height: 24),
          _buildSectionHeader('Recent Activity'),
          _buildRecentActivityCard(),
          const SizedBox(height: 24),
          _buildSectionHeader('Upcoming Events'),
          _buildUpcomingEventsCard(),
        ],
      ),
    );
  }

  Widget _buildStatsCard() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: cardColor,
        borderRadius: BorderRadius.circular(16),
        boxShadow: widget.isDarkMode ? [] : [
          BoxShadow(
            color: Colors.black.withOpacity(0.06),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: _buildStatItem(
                  'Sessions Attended',
                  '${widget.course.sessionsAttended}',
                  '${widget.course.totalSessions}',
                  Colors.green,
                ),
              ),
              Expanded(
                child: _buildStatItem(
                  'On Time',
                  '${widget.course.onTime}',
                  '${widget.course.sessionsAttended}',
                  Colors.blue,
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          Row(
            children: [
              Expanded(
                child: _buildStatItem(
                  'Late Arrivals',
                  '${widget.course.late}',
                  '${widget.course.sessionsAttended}',
                  Colors.orange,
                ),
              ),
              Expanded(
                child: _buildStatItem(
                  'Assignments',
                  '${_assignments.where((a) => a.submissionStatus == SubmissionStatus.submitted).length}',
                  '${_assignments.length}',
                  Colors.purple,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildStatItem(String label, String value, String total, Color color) {
    return Column(
      children: [
        Container(
          width: 60,
          height: 60,
          decoration: BoxDecoration(
            color: color.withOpacity(0.1),
            borderRadius: BorderRadius.circular(30),
            border: Border.all(color: color.withOpacity(0.3)),
          ),
          child: Center(
            child: Text(
              value,
              style: TextStyle(
                color: color,
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ),
        const SizedBox(height: 8),
        Text(
          label,
          style: TextStyle(
            color: textColor,
            fontSize: 12,
            fontWeight: FontWeight.w600,
          ),
          textAlign: TextAlign.center,
        ),
        Text(
          'of $total',
          style: TextStyle(
            color: subtitleColor,
            fontSize: 10,
          ),
        ),
      ],
    );
  }

  Widget _buildRecentActivityCard() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: cardColor,
        borderRadius: BorderRadius.circular(16),
        boxShadow: widget.isDarkMode ? [] : [
          BoxShadow(
            color: Colors.black.withOpacity(0.06),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        children: [
          _buildActivityItem(
            Icons.assignment_turned_in,
            'Assignment Submitted',
            'Binary Tree Traversal - Grade: 85/90',
            '3 days ago',
            Colors.green,
          ),
          const Divider(height: 24),
          _buildActivityItem(
            Icons.check_circle,
            'Attendance Recorded',
            'Present - On time arrival',
            '1 day ago',
            Colors.blue,
          ),
          const Divider(height: 24),
          _buildActivityItem(
            Icons.download,
            'Material Downloaded',
            'Chapter 6: Advanced Data Structures',
            '2 days ago',
            Colors.purple,
          ),
        ],
      ),
    );
  }

  Widget _buildActivityItem(IconData icon, String title, String subtitle, String time, Color color) {
    return Row(
      children: [
        Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            color: color.withOpacity(0.1),
            borderRadius: BorderRadius.circular(20),
          ),
          child: Icon(icon, color: color, size: 20),
        ),
        const SizedBox(width: 16),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: TextStyle(
                  color: textColor,
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                ),
              ),
              Text(
                subtitle,
                style: TextStyle(
                  color: subtitleColor,
                  fontSize: 12,
                ),
              ),
            ],
          ),
        ),
        Text(
          time,
          style: TextStyle(
            color: subtitleColor,
            fontSize: 10,
          ),
        ),
      ],
    );
  }

  Widget _buildUpcomingEventsCard() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: cardColor,
        borderRadius: BorderRadius.circular(16),
        boxShadow: widget.isDarkMode ? [] : [
          BoxShadow(
            color: Colors.black.withOpacity(0.06),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        children: [
          _buildEventItem(
            'Midterm Exam',
            'December 20, 2024 at 2:00 PM',
            'Room 301',
            Colors.red,
            true,
          ),
          const Divider(height: 24),
          _buildEventItem(
            'Assignment Due',
            'December 15, 2024 at 11:59 PM',
            'Data Structures Implementation',
            Colors.orange,
            false,
          ),
          const Divider(height: 24),
          _buildEventItem(
            'Next Lecture',
            'December 12, 2024 at 10:00 AM',
            'Graph Algorithms',
            Colors.blue,
            false,
          ),
        ],
      ),
    );
  }

  Widget _buildEventItem(String title, String time, String location, Color color, bool isUrgent) {
    return Row(
      children: [
        Container(
          width: 4,
          height: 40,
          decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.circular(2),
          ),
        ),
        const SizedBox(width: 16),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Text(
                    title,
                    style: TextStyle(
                      color: textColor,
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  if (isUrgent) ...[
                    const SizedBox(width: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(
                        color: Colors.red.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: const Text(
                        'URGENT',
                        style: TextStyle(
                          color: Colors.red,
                          fontSize: 8,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ],
                ],
              ),
              Text(
                time,
                style: TextStyle(
                  color: subtitleColor,
                  fontSize: 12,
                ),
              ),
              Text(
                location,
                style: TextStyle(
                  color: subtitleColor,
                  fontSize: 11,
                ),
              ),
            ],
          ),
        ),
        Icon(Icons.arrow_forward_ios, color: subtitleColor, size: 16),
      ],
    );
  }

  Widget _buildAnnouncementsTab() {
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _announcements.length,
      itemBuilder: (context, index) {
        final announcement = _announcements[index];
        return _buildAnnouncementCard(announcement);
      },
    );
  }

  Widget _buildAnnouncementCard(Announcement announcement) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: cardColor,
        borderRadius: BorderRadius.circular(16),
        border: announcement.isUrgent ? Border.all(color: Colors.red.withOpacity(0.3), width: 2) : null,
        boxShadow: widget.isDarkMode ? [] : [
          BoxShadow(
            color: Colors.black.withOpacity(0.06),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: _getAnnouncementColor(announcement.type).withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Icon(
                  _getAnnouncementIcon(announcement.type),
                  color: _getAnnouncementColor(announcement.type),
                  size: 20,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            announcement.title,
                            style: TextStyle(
                              color: textColor,
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                        if (announcement.isUrgent)
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                            decoration: BoxDecoration(
                              color: Colors.red.withOpacity(0.1),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: const Text(
                              'URGENT',
                              style: TextStyle(
                                color: Colors.red,
                                fontSize: 10,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                      ],
                    ),
                    Text(
                      announcement.lecturer,
                      style: TextStyle(
                        color: subtitleColor,
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Text(
            announcement.content,
            style: TextStyle(
              color: textColor,
              fontSize: 14,
              height: 1.5,
            ),
          ),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                _formatTimestamp(announcement.timestamp),
                style: TextStyle(
                  color: subtitleColor,
                  fontSize: 12,
                ),
              ),
              Row(
                children: [
                  IconButton(
                    onPressed: () => _showSnackBar('Announcement bookmarked'),
                    icon: Icon(Icons.bookmark_border, color: subtitleColor, size: 20),
                  ),
                  IconButton(
                    onPressed: () => _showSnackBar('Announcement shared'),
                    icon: Icon(Icons.share, color: subtitleColor, size: 20),
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildAssignmentsTab() {
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _assignments.length,
      itemBuilder: (context, index) {
        final assignment = _assignments[index];
        return _buildAssignmentCard(assignment);
      },
    );
  }

  Widget _buildAssignmentCard(Assignment assignment) {
    final isOverdue = assignment.dueDate.isBefore(DateTime.now()) && 
                     assignment.submissionStatus != SubmissionStatus.submitted;
    final daysUntilDue = assignment.dueDate.difference(DateTime.now()).inDays;

    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: cardColor,
        borderRadius: BorderRadius.circular(16),
        border: isOverdue ? Border.all(color: Colors.red.withOpacity(0.3), width: 2) : null,
        boxShadow: widget.isDarkMode ? [] : [
          BoxShadow(
            color: Colors.black.withOpacity(0.06),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: _getSubmissionStatusColor(assignment.submissionStatus).withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Icon(
                  _getSubmissionStatusIcon(assignment.submissionStatus),
                  color: _getSubmissionStatusColor(assignment.submissionStatus),
                  size: 20,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      assignment.title,
                      style: TextStyle(
                        color: textColor,
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text(
                      '${assignment.maxPoints} points',
                      style: TextStyle(
                        color: subtitleColor,
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: _getSubmissionStatusColor(assignment.submissionStatus).withOpacity(0.1),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  _getSubmissionStatusText(assignment.submissionStatus),
                  style: TextStyle(
                    color: _getSubmissionStatusColor(assignment.submissionStatus),
                    fontSize: 10,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Text(
            assignment.description,
            style: TextStyle(
              color: textColor,
              fontSize: 14,
              height: 1.5,
            ),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Icon(Icons.schedule, color: subtitleColor, size: 16),
              const SizedBox(width: 8),
              Text(
                'Due: ${_formatDate(assignment.dueDate)}',
                style: TextStyle(
                  color: isOverdue ? Colors.red : subtitleColor,
                  fontSize: 12,
                  fontWeight: isOverdue ? FontWeight.bold : FontWeight.normal,
                ),
              ),
              if (!isOverdue && assignment.submissionStatus != SubmissionStatus.submitted) ...[
                const SizedBox(width: 16),
                Text(
                  daysUntilDue > 0 ? '$daysUntilDue days left' : 'Due today',
                  style: TextStyle(
                    color: daysUntilDue <= 1 ? Colors.orange : subtitleColor,
                    fontSize: 12,
                    fontWeight: daysUntilDue <= 1 ? FontWeight.bold : FontWeight.normal,
                  ),
                ),
              ],
            ],
          ),
          if (assignment.submissionStatus == SubmissionStatus.submitted) ...[
            const SizedBox(height: 8),
            Row(
              children: [
                Icon(Icons.check_circle, color: Colors.green, size: 16),
                const SizedBox(width: 8),
                Text(
                  'Submitted: ${_formatDate(assignment.submittedDate!)}',
                  style: TextStyle(
                    color: Colors.green,
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                if (assignment.grade != null) ...[
                  const SizedBox(width: 16),
                  Text(
                    'Grade: ${assignment.grade}/${assignment.maxPoints}',
                    style: TextStyle(
                      color: const Color(0xFF667eea),
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ],
            ),
          ],
          if (assignment.attachments.isNotEmpty) ...[
            const SizedBox(height: 16),
            Text(
              'Attachments:',
              style: TextStyle(
                color: textColor,
                fontSize: 12,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 8),
            ...assignment.attachments.map((attachment) => 
              Padding(
                padding: const EdgeInsets.only(bottom: 4),
                child: Row(
                  children: [
                    Icon(Icons.attach_file, color: subtitleColor, size: 16),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        attachment,
                        style: TextStyle(
                          color: const Color(0xFF667eea),
                          fontSize: 12,
                          decoration: TextDecoration.underline,
                        ),
                      ),
                    ),
                    IconButton(
                      onPressed: () => _showSnackBar('Downloading $attachment...'),
                      icon: Icon(Icons.download, color: subtitleColor, size: 16),
                    ),
                  ],
                ),
              ),
            ),
          ],
          const SizedBox(height: 16),
          Row(
            children: [
              if (assignment.submissionStatus != SubmissionStatus.submitted)
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: () => _showSubmissionDialog(assignment),
                    icon: const Icon(Icons.upload, size: 16),
                    label: const Text('Submit Assignment'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF667eea),
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                  ),
                ),
              if (assignment.submissionStatus != SubmissionStatus.submitted)
                const SizedBox(width: 12),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () => _showSnackBar('Opening assignment details...'),
                  icon: const Icon(Icons.info_outline, size: 16),
                  label: const Text('View Details'),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: const Color(0xFF667eea),
                    side: const BorderSide(color: Color(0xFF667eea)),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildMaterialsTab() {
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _materials.length,
      itemBuilder: (context, index) {
        final material = _materials[index];
        return _buildMaterialCard(material);
      },
    );
  }

  Widget _buildMaterialCard(CourseMaterial material) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: cardColor,
        borderRadius: BorderRadius.circular(16),
        boxShadow: widget.isDarkMode ? [] : [
          BoxShadow(
            color: Colors.black.withOpacity(0.06),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: _getMaterialTypeColor(material.type).withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Icon(
                  _getMaterialTypeIcon(material.type),
                  color: _getMaterialTypeColor(material.type),
                  size: 20,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            material.title,
                            style: TextStyle(
                              color: textColor,
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                        if (material.isNew) ...[
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                            decoration: BoxDecoration(
                              color: Colors.green.withOpacity(0.1),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: const Text(
                              'NEW',
                              style: TextStyle(
                                color: Colors.green,
                                fontSize: 10,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ],
                      ],
                    ),
                    Row(
                      children: [
                        Text(
                          material.size,
                          style: TextStyle(
                            color: subtitleColor,
                            fontSize: 12,
                          ),
                        ),
                        if (material.duration != null) ...[
                          Text(
                            ' • ${material.duration}',
                            style: TextStyle(
                              color: subtitleColor,
                              fontSize: 12,
                            ),
                          ),
                        ],
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Text(
            material.description,
            style: TextStyle(
              color: textColor,
              fontSize: 14,
              height: 1.5,
            ),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Icon(Icons.schedule, color: subtitleColor, size: 16),
              const SizedBox(width: 8),
              Text(
                'Uploaded: ${_formatDate(material.uploadDate)}',
                style: TextStyle(
                  color: subtitleColor,
                  fontSize: 12,
                ),
              ),
              const SizedBox(width: 16),
              Icon(Icons.download, color: subtitleColor, size: 16),
              const SizedBox(width: 4),
              Text(
                '${material.downloadCount} downloads',
                style: TextStyle(
                  color: subtitleColor,
                  fontSize: 12,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: () => _downloadMaterial(material),
                  icon: const Icon(Icons.download, size: 16),
                  label: const Text('Download'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF667eea),
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () => _previewMaterial(material),
                  icon: const Icon(Icons.visibility, size: 16),
                  label: const Text('Preview'),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: const Color(0xFF667eea),
                    side: const BorderSide(color: Color(0xFF667eea)),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildSectionHeader(String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Text(
        title,
        style: TextStyle(
          color: textColor,
          fontSize: 18,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  // Helper methods
  Color _getAnnouncementColor(AnnouncementType type) {
    switch (type) {
      case AnnouncementType.courseCanceled:
        return Colors.red;
      case AnnouncementType.assignment:
        return Colors.orange;
      case AnnouncementType.materials:
        return Colors.blue;
      case AnnouncementType.exam:
        return Colors.purple;
      case AnnouncementType.general:
        return Colors.grey;
    }
  }

  IconData _getAnnouncementIcon(AnnouncementType type) {
    switch (type) {
      case AnnouncementType.courseCanceled:
        return Icons.cancel;
      case AnnouncementType.assignment:
        return Icons.assignment;
      case AnnouncementType.materials:
        return Icons.folder;
      case AnnouncementType.exam:
        return Icons.quiz;
      case AnnouncementType.general:
        return Icons.info;
    }
  }

  Color _getSubmissionStatusColor(SubmissionStatus status) {
    switch (status) {
      case SubmissionStatus.submitted:
        return Colors.green;
      case SubmissionStatus.late:
        return Colors.orange;
      case SubmissionStatus.notSubmitted:
        return Colors.grey;
    }
  }

  IconData _getSubmissionStatusIcon(SubmissionStatus status) {
    switch (status) {
      case SubmissionStatus.submitted:
        return Icons.check_circle;
      case SubmissionStatus.late:
        return Icons.schedule;
      case SubmissionStatus.notSubmitted:
        return Icons.pending;
    }
  }

  String _getSubmissionStatusText(SubmissionStatus status) {
    switch (status) {
      case SubmissionStatus.submitted:
        return 'SUBMITTED';
      case SubmissionStatus.late:
        return 'LATE';
      case SubmissionStatus.notSubmitted:
        return 'PENDING';
    }
  }

  Color _getMaterialTypeColor(MaterialType type) {
    switch (type) {
      case MaterialType.pdf:
        return Colors.red;
      case MaterialType.video:
        return Colors.blue;
      case MaterialType.document:
        return Colors.green;
      case MaterialType.code:
        return Colors.purple;
    }
  }

  IconData _getMaterialTypeIcon(MaterialType type) {
    switch (type) {
      case MaterialType.pdf:
        return Icons.picture_as_pdf;
      case MaterialType.video:
        return Icons.play_circle;
      case MaterialType.document:
        return Icons.description;
      case MaterialType.code:
        return Icons.code;
    }
  }

  String _formatTimestamp(DateTime timestamp) {
    final now = DateTime.now();
    final difference = now.difference(timestamp);

    if (difference.inDays > 0) {
      return '${difference.inDays} day${difference.inDays == 1 ? '' : 's'} ago';
    } else if (difference.inHours > 0) {
      return '${difference.inHours} hour${difference.inHours == 1 ? '' : 's'} ago';
    } else if (difference.inMinutes > 0) {
      return '${difference.inMinutes} minute${difference.inMinutes == 1 ? '' : 's'} ago';
    } else {
      return 'Just now';
    }
  }

  String _formatDate(DateTime date) {
    return '${date.day}/${date.month}/${date.year}';
  }

  void _downloadMaterial(CourseMaterial material) {
    _showSnackBar('Downloading ${material.title}...');
    // Simulate download progress
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        backgroundColor: cardColor,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const CircularProgressIndicator(color: Color(0xFF667eea)),
            const SizedBox(height: 16),
            Text('Downloading ${material.title}...', style: TextStyle(color: textColor)),
          ],
        ),
      ),
    );

    Future.delayed(const Duration(seconds: 2), () {
      Navigator.pop(context);
      _showSnackBar('${material.title} downloaded successfully');
    });
  }

  void _previewMaterial(CourseMaterial material) {
    _showSnackBar('Opening preview for ${material.title}...');
  }

  void _showSubmissionDialog(Assignment assignment) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: cardColor,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text('Submit Assignment', style: TextStyle(color: textColor)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'Submit your assignment for "${assignment.title}"',
              style: TextStyle(color: subtitleColor),
            ),
            const SizedBox(height: 16),
            Container(
              width: double.infinity,
              height: 100,
              decoration: BoxDecoration(
                border: Border.all(color: subtitleColor.withOpacity(0.3)),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.cloud_upload, color: subtitleColor, size: 32),
                  const SizedBox(height: 8),
                  Text(
                    'Tap to upload files',
                    style: TextStyle(color: subtitleColor, fontSize: 12),
                  ),
                ],
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel', style: TextStyle(color: subtitleColor)),
          ),
          Container(
            decoration: BoxDecoration(
              gradient: primaryGradient,
              borderRadius: BorderRadius.circular(8),
            ),
            child: TextButton(
              onPressed: () {
                Navigator.pop(context);
                _showSnackBar('Assignment submitted successfully!');
              },
              child: const Text('Submit', style: TextStyle(color: Colors.white)),
            ),
          ),
        ],
      ),
    );
  }

  void _showShareDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: cardColor,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text('Share Course', style: TextStyle(color: textColor)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'Share "${widget.course.name}" with others',
              style: TextStyle(color: subtitleColor),
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _buildShareOption('Copy Link', Icons.link, () {
                  Navigator.pop(context);
                  _showSnackBar('Course link copied to clipboard');
                }),
                _buildShareOption('Email', Icons.email, () {
                  Navigator.pop(context);
                  _showSnackBar('Opening email...');
                }),
                _buildShareOption('Message', Icons.message, () {
                  Navigator.pop(context);
                  _showSnackBar('Opening messages...');
                }),
              ],
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close', style: TextStyle(color: Color(0xFF667eea))),
          ),
        ],
      ),
    );
  }

  Widget _buildShareOption(String label, IconData icon, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: const Color(0xFF667eea).withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(icon, color: const Color(0xFF667eea), size: 24),
          ),
          const SizedBox(height: 8),
          Text(label, style: TextStyle(color: textColor, fontSize: 12)),
        ],
      ),
    );
  }

  void _showSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: const Color(0xFF667eea),
        duration: const Duration(seconds: 2),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }
}

// Data Models
class Announcement {
  final String id;
  final String title;
  final String content;
  final String lecturer;
  final DateTime timestamp;
  final AnnouncementType type;
  final bool isUrgent;

  Announcement({
    required this.id,
    required this.title,
    required this.content,
    required this.lecturer,
    required this.timestamp,
    required this.type,
    required this.isUrgent,
  });
}

enum AnnouncementType {
  courseCanceled,
  assignment,
  materials,
  exam,
  general,
}

class Assignment {
  final String id;
  final String title;
  final String description;
  final DateTime dueDate;
  final int maxPoints;
  final SubmissionStatus submissionStatus;
  final DateTime? submittedDate;
  final int? grade;
  final List<String> attachments;

  Assignment({
    required this.id,
    required this.title,
    required this.description,
    required this.dueDate,
    required this.maxPoints,
    required this.submissionStatus,
    this.submittedDate,
    this.grade,
    required this.attachments,
  });
}

enum SubmissionStatus {
  submitted,
  late,
  notSubmitted,
}

class CourseMaterial {
  final String id;
  final String title;
  final String description;
  final MaterialType type;
  final String size;
  final DateTime uploadDate;
  final int downloadCount;
  final bool isNew;
  final String? duration;

  CourseMaterial({
    required this.id,
    required this.title,
    required this.description,
    required this.type,
    required this.size,
    required this.uploadDate,
    required this.downloadCount,
    this.isNew = false,
    this.duration,
  });
}

enum MaterialType {
  pdf,
  video,
  document,
  code,
}
