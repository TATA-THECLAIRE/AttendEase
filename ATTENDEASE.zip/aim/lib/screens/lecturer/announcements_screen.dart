import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import '../../models/announcement.dart';

class AnnouncementsScreen extends StatefulWidget {
  final bool isDarkMode;

  const AnnouncementsScreen({
    Key? key,
    required this.isDarkMode,
  }) : super(key: key);

  @override
  _AnnouncementsScreenState createState() => _AnnouncementsScreenState();
}

class _AnnouncementsScreenState extends State<AnnouncementsScreen> with TickerProviderStateMixin {
  late TabController _tabController;
  
  List<Announcement> announcements = [
    Announcement(
      id: '1',
      title: 'Class Cancelled - Software Engineering',
      message: 'Tomorrow\'s Software Engineering class is cancelled due to a faculty meeting.',
      courseCode: 'CSC301',
      timestamp: DateTime.now().subtract(Duration(hours: 2)),
      type: AnnouncementType.classCancelled,
    ),
    Announcement(
      id: '2',
      title: 'Assignment Due Reminder',
      message: 'Database Systems assignment is due this Friday. Please submit on time.',
      courseCode: 'CSC302',
      timestamp: DateTime.now().subtract(Duration(days: 1)),
      type: AnnouncementType.reminder,
    ),
  ];

  List<CourseMaterial> courseMaterials = [
    CourseMaterial(
      id: '1',
      title: 'Software Engineering Lecture Notes',
      fileName: 'SE_Chapter1.pdf',
      fileSize: '2.5 MB',
      uploadDate: DateTime.now().subtract(Duration(days: 3)),
      courseCode: 'CSC301',
      type: MaterialType.lecture,
    ),
    CourseMaterial(
      id: '2',
      title: 'Database Assignment Template',
      fileName: 'DB_Assignment.docx',
      fileSize: '1.2 MB',
      uploadDate: DateTime.now().subtract(Duration(days: 1)),
      courseCode: 'CSC302',
      type: MaterialType.assignment,
    ),
  ];

  List<StudentComplaint> complaints = [
    StudentComplaint(
      id: '1',
      studentName: 'Tabe Mercy',
      matricNo: 'FE19A001',
      subject: 'Attendance Marking Issue',
      message: 'I was present in yesterday\'s class but marked absent. Please review.',
      timestamp: DateTime.now().subtract(Duration(hours: 5)),
      status: ComplaintStatus.pending,
      courseCode: 'CSC301',
    ),
    StudentComplaint(
      id: '2',
      studentName: 'Ngozi Paul',
      matricNo: 'FE19A002',
      subject: 'Assignment Submission Problem',
      message: 'Unable to submit assignment due to technical issues with the platform.',
      timestamp: DateTime.now().subtract(Duration(days: 1)),
      status: ComplaintStatus.resolved,
      courseCode: 'CSC302',
    ),
  ];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Color get backgroundColor => widget.isDarkMode ? const Color(0xFF1a1a2e) : const Color(0xFFF8F9FA);
  Color get cardColor => widget.isDarkMode ? const Color(0xFF2d2d42) : Colors.white;
  Color get textColor => widget.isDarkMode ? Colors.white : const Color(0xFF2D3748);
  Color get subtitleColor => widget.isDarkMode ? Colors.grey[400]! : const Color(0xFF718096);

  LinearGradient get primaryGradient => const LinearGradient(
    colors: [Color(0xFF667eea), Color(0xFF764ba2)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: backgroundColor,
      body: SafeArea(
        child: Column(
          children: [
            _buildHeader(),
            _buildTabBar(),
            Expanded(
              child: TabBarView(
                controller: _tabController,
                children: [
                  _buildAnnouncementsTab(),
                  _buildCourseMaterialsTab(),
                  _buildStudentListTab(),
                  _buildComplaintsTab(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        gradient: primaryGradient,
      ),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            Row(
              children: [
                // Attendease Logo
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(20),
                    child: Image.asset(
                      'assets/images/attendease_logo.png',
                      fit: BoxFit.cover,
                      errorBuilder: (context, error, stackTrace) {
                        return Container(
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [Colors.purple, Colors.teal],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: const Center(
                            child: Text(
                              'A',
                              style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 20,
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Course Management',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        'Manage announcements, materials & more',
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.9),
                          fontSize: 14,
                        ),
                      ),
                    ],
                  ),
                ),
                IconButton(
                  onPressed: () => Navigator.pop(context),
                  icon: const Icon(Icons.close, color: Colors.white),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTabBar() {
    return Container(
      color: cardColor,
      child: TabBar(
        controller: _tabController,
        labelColor: const Color(0xFF667eea),
        unselectedLabelColor: subtitleColor,
        indicatorColor: const Color(0xFF667eea),
        labelStyle: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600),
        unselectedLabelStyle: const TextStyle(fontSize: 12),
        tabs: const [
          Tab(text: 'Announcements'),
          Tab(text: 'Materials'),
          Tab(text: 'Student List'),
          Tab(text: 'Complaints'),
        ],
      ),
    );
  }

  Widget _buildAnnouncementsTab() {
    return Container(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          _buildCreateButton(
            'Create Announcement',
            Icons.campaign,
            () => _showCreateAnnouncementDialog(),
          ),
          const SizedBox(height: 16),
          Expanded(
            child: ListView.builder(
              itemCount: announcements.length,
              itemBuilder: (context, index) {
                final announcement = announcements[index];
                return _buildAnnouncementCard(announcement);
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCourseMaterialsTab() {
    return Container(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          _buildCreateButton(
            'Upload Material',
            Icons.upload_file,
            () => _uploadCourseMaterial(),
          ),
          const SizedBox(height: 16),
          Expanded(
            child: ListView.builder(
              itemCount: courseMaterials.length,
              itemBuilder: (context, index) {
                final material = courseMaterials[index];
                return _buildMaterialCard(material);
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStudentListTab() {
    return Container(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          _buildCreateButton(
            'Upload Student List',
            Icons.upload,
            () => _uploadStudentList(),
          ),
          const SizedBox(height: 16),
          Expanded(
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.people_outline,
                    size: 64,
                    color: subtitleColor,
                  ),
                  const SizedBox(height: 16),
                  Text(
                    'No student lists uploaded yet',
                    style: TextStyle(
                      color: subtitleColor,
                      fontSize: 16,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Upload CSV or Excel files with student information',
                    style: TextStyle(
                      color: subtitleColor,
                      fontSize: 12,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildComplaintsTab() {
    return Container(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: cardColor,
              borderRadius: BorderRadius.circular(12),
              boxShadow: widget.isDarkMode ? [] : [
                BoxShadow(
                  color: Colors.black.withOpacity(0.06),
                  blurRadius: 8,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Row(
              children: [
                Icon(Icons.feedback, color: const Color(0xFF667eea)),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Student Complaints',
                        style: TextStyle(
                          color: textColor,
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        '${complaints.where((c) => c.status == ComplaintStatus.pending).length} pending complaints',
                        style: TextStyle(
                          color: subtitleColor,
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          Expanded(
            child: ListView.builder(
              itemCount: complaints.length,
              itemBuilder: (context, index) {
                final complaint = complaints[index];
                return _buildComplaintCard(complaint);
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCreateButton(String text, IconData icon, VoidCallback onPressed) {
    return SizedBox(
      width: double.infinity,
      child: Container(
        decoration: BoxDecoration(
          gradient: primaryGradient,
          borderRadius: BorderRadius.circular(12),
        ),
        child: TextButton.icon(
          onPressed: onPressed,
          icon: Icon(icon, color: Colors.white),
          label: Text(
            text,
            style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildAnnouncementCard(Announcement announcement) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: cardColor,
        borderRadius: BorderRadius.circular(12),
        boxShadow: widget.isDarkMode ? [] : [
          BoxShadow(
            color: Colors.black.withOpacity(0.06),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                _getAnnouncementIcon(announcement.type),
                color: _getAnnouncementColor(announcement.type),
                size: 20,
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  announcement.title,
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: textColor,
                  ),
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: widget.isDarkMode ? Color(0xFF4a5568) : Color(0xFFf8f9ff),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  announcement.courseCode,
                  style: TextStyle(
                    fontSize: 12,
                    color: subtitleColor,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            announcement.message,
            style: TextStyle(
              fontSize: 14,
              color: subtitleColor,
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Text(
                _formatTimestamp(announcement.timestamp),
                style: TextStyle(
                  fontSize: 12,
                  color: subtitleColor.withOpacity(0.7),
                ),
              ),
              const Spacer(),
              IconButton(
                onPressed: () => _editAnnouncement(announcement),
                icon: Icon(Icons.edit, size: 18, color: subtitleColor),
              ),
              IconButton(
                onPressed: () => _deleteAnnouncement(announcement.id),
                icon: const Icon(Icons.delete, size: 18, color: Colors.red),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildMaterialCard(CourseMaterial material) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: cardColor,
        borderRadius: BorderRadius.circular(12),
        boxShadow: widget.isDarkMode ? [] : [
          BoxShadow(
            color: Colors.black.withOpacity(0.06),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: _getMaterialColor(material.type).withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(
              _getMaterialIcon(material.type),
              color: _getMaterialColor(material.type),
              size: 24,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  material.title,
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: textColor,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  '${material.fileName} • ${material.fileSize}',
                  style: TextStyle(
                    fontSize: 12,
                    color: subtitleColor,
                  ),
                ),
                Text(
                  'Uploaded ${_formatTimestamp(material.uploadDate)}',
                  style: TextStyle(
                    fontSize: 10,
                    color: subtitleColor.withOpacity(0.7),
                  ),
                ),
              ],
            ),
          ),
          IconButton(
            onPressed: () => _deleteMaterial(material.id),
            icon: const Icon(Icons.delete, size: 18, color: Colors.red),
          ),
        ],
      ),
    );
  }

  Widget _buildComplaintCard(StudentComplaint complaint) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: cardColor,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: complaint.status == ComplaintStatus.pending 
              ? Colors.orange.withOpacity(0.3)
              : Colors.green.withOpacity(0.3),
        ),
        boxShadow: widget.isDarkMode ? [] : [
          BoxShadow(
            color: Colors.black.withOpacity(0.06),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      complaint.subject,
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                        color: textColor,
                      ),
                    ),
                    Text(
                      '${complaint.studentName} (${complaint.matricNo})',
                      style: TextStyle(
                        fontSize: 12,
                        color: subtitleColor,
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: complaint.status == ComplaintStatus.pending 
                      ? Colors.orange.withOpacity(0.1)
                      : Colors.green.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  complaint.status == ComplaintStatus.pending ? 'Pending' : 'Resolved',
                  style: TextStyle(
                    fontSize: 10,
                    fontWeight: FontWeight.bold,
                    color: complaint.status == ComplaintStatus.pending 
                        ? Colors.orange
                        : Colors.green,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            complaint.message,
            style: TextStyle(
              fontSize: 12,
              color: subtitleColor,
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Text(
                _formatTimestamp(complaint.timestamp),
                style: TextStyle(
                  fontSize: 10,
                  color: subtitleColor.withOpacity(0.7),
                ),
              ),
              const Spacer(),
              if (complaint.status == ComplaintStatus.pending)
                TextButton(
                  onPressed: () => _resolveComplaint(complaint.id),
                  child: const Text(
                    'Mark Resolved',
                    style: TextStyle(
                      color: Colors.green,
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
            ],
          ),
        ],
      ),
    );
  }

  // Helper methods
  IconData _getAnnouncementIcon(AnnouncementType type) {
    switch (type) {
      case AnnouncementType.classCancelled:
        return Icons.cancel;
      case AnnouncementType.reminder:
        return Icons.alarm;
      case AnnouncementType.courseMaterial:
        return Icons.file_present;
      case AnnouncementType.general:
        return Icons.announcement;
    }
  }

  Color _getAnnouncementColor(AnnouncementType type) {
    switch (type) {
      case AnnouncementType.classCancelled:
        return Colors.red;
      case AnnouncementType.reminder:
        return Colors.orange;
      case AnnouncementType.courseMaterial:
        return Colors.blue;
      case AnnouncementType.general:
        return Colors.green;
    }
  }

  IconData _getMaterialIcon(MaterialType type) {
    switch (type) {
      case MaterialType.lecture:
        return Icons.slideshow;
      case MaterialType.assignment:
        return Icons.assignment;
      case MaterialType.reference:
        return Icons.book;
      case MaterialType.video:
        return Icons.video_library;
    }
  }

  Color _getMaterialColor(MaterialType type) {
    switch (type) {
      case MaterialType.lecture:
        return Colors.blue;
      case MaterialType.assignment:
        return Colors.orange;
      case MaterialType.reference:
        return Colors.green;
      case MaterialType.video:
        return Colors.purple;
    }
  }

  String _formatTimestamp(DateTime timestamp) {
    final now = DateTime.now();
    final difference = now.difference(timestamp);
    
    if (difference.inDays > 0) {
      return '${difference.inDays}d ago';
    } else if (difference.inHours > 0) {
      return '${difference.inHours}h ago';
    } else {
      return '${difference.inMinutes}m ago';
    }
  }

  // Action methods
  void _showCreateAnnouncementDialog() {
    showDialog(
      context: context,
      builder: (context) => _CreateAnnouncementDialog(
        isDarkMode: widget.isDarkMode,
        onSave: (announcement) {
          setState(() {
            announcements.insert(0, announcement);
          });
        },
      ),
    );
  }

  void _editAnnouncement(Announcement announcement) {
    showDialog(
      context: context,
      builder: (context) => _CreateAnnouncementDialog(
        isDarkMode: widget.isDarkMode,
        announcement: announcement,
        onSave: (updatedAnnouncement) {
          setState(() {
            final index = announcements.indexWhere((a) => a.id == announcement.id);
            if (index != -1) {
              announcements[index] = updatedAnnouncement;
            }
          });
        },
      ),
    );
  }

  void _deleteAnnouncement(String id) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: cardColor,
        title: Text('Delete Announcement', style: TextStyle(color: textColor)),
        content: Text('Are you sure you want to delete this announcement?', style: TextStyle(color: subtitleColor)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel', style: TextStyle(color: subtitleColor)),
          ),
          TextButton(
            onPressed: () {
              setState(() {
                announcements.removeWhere((a) => a.id == id);
              });
              Navigator.pop(context);
            },
            child: const Text('Delete', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  Future<void> _uploadCourseMaterial() async {
    try {
      FilePickerResult? result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['pdf', 'doc', 'docx', 'ppt', 'pptx', 'mp4', 'avi'],
      );

      if (result != null) {
        final file = result.files.first;
        final material = CourseMaterial(
          id: DateTime.now().millisecondsSinceEpoch.toString(),
          title: file.name.split('.').first,
          fileName: file.name,
          fileSize: '${(file.size / 1024 / 1024).toStringAsFixed(1)} MB',
          uploadDate: DateTime.now(),
          courseCode: 'CSC301',
          type: MaterialType.lecture,
        );

        setState(() {
          courseMaterials.insert(0, material);
        });

        _showSnackBar('Material uploaded successfully');
      }
    } catch (e) {
      _showSnackBar('Error uploading file: $e');
    }
  }

  Future<void> _uploadStudentList() async {
    try {
      FilePickerResult? result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['csv', 'xlsx', 'xls'],
      );

      if (result != null) {
        _showSnackBar('Student list uploaded successfully');
      }
    } catch (e) {
      _showSnackBar('Error uploading student list: $e');
    }
  }

  void _deleteMaterial(String id) {
    setState(() {
      courseMaterials.removeWhere((m) => m.id == id);
    });
    _showSnackBar('Material deleted');
  }

  void _resolveComplaint(String id) {
    setState(() {
      final index = complaints.indexWhere((c) => c.id == id);
      if (index != -1) {
        complaints[index].status = ComplaintStatus.resolved;
      }
    });
    _showSnackBar('Complaint marked as resolved');
  }

  void _showSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: const Color(0xFF667eea),
        duration: const Duration(seconds: 2),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }
}

// Dialog for creating/editing announcements
class _CreateAnnouncementDialog extends StatefulWidget {
  final bool isDarkMode;
  final Announcement? announcement;
  final Function(Announcement) onSave;

  const _CreateAnnouncementDialog({
    Key? key,
    required this.isDarkMode,
    this.announcement,
    required this.onSave,
  }) : super(key: key);

  @override
  _CreateAnnouncementDialogState createState() => _CreateAnnouncementDialogState();
}

class _CreateAnnouncementDialogState extends State<_CreateAnnouncementDialog> {
  final _titleController = TextEditingController();
  final _messageController = TextEditingController();
  String _selectedCourse = 'CSC301';
  AnnouncementType _selectedType = AnnouncementType.general;

  final List<String> courses = ['CSC301', 'CSC302', 'CSC201'];

  @override
  void initState() {
    super.initState();
    if (widget.announcement != null) {
      _titleController.text = widget.announcement!.title;
      _messageController.text = widget.announcement!.message;
      _selectedCourse = widget.announcement!.courseCode;
      _selectedType = widget.announcement!.type;
    }
  }

  Color get cardColor => widget.isDarkMode ? const Color(0xFF2d2d42) : Colors.white;
  Color get textColor => widget.isDarkMode ? Colors.white : const Color(0xFF2D3748);
  Color get subtitleColor => widget.isDarkMode ? Colors.grey[400]! : const Color(0xFF718096);

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: cardColor,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      title: Text(
        widget.announcement == null ? 'Create Announcement' : 'Edit Announcement',
        style: TextStyle(color: textColor),
      ),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: _titleController,
              style: TextStyle(color: textColor),
              decoration: InputDecoration(
                labelText: 'Title',
                labelStyle: TextStyle(color: subtitleColor),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: const BorderSide(color: Color(0xFF667eea)),
                ),
              ),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _messageController,
              style: TextStyle(color: textColor),
              decoration: InputDecoration(
                labelText: 'Message',
                labelStyle: TextStyle(color: subtitleColor),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: const BorderSide(color: Color(0xFF667eea)),
                ),
              ),
              maxLines: 3,
            ),
            const SizedBox(height: 16),
            DropdownButtonFormField<String>(
              value: _selectedCourse,
              style: TextStyle(color: textColor),
              dropdownColor: cardColor,
              decoration: InputDecoration(
                labelText: 'Course',
                labelStyle: TextStyle(color: subtitleColor),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: const BorderSide(color: Color(0xFF667eea)),
                ),
              ),
              items: courses.map((course) {
                return DropdownMenuItem(
                  value: course,
                  child: Text(course),
                );
              }).toList(),
              onChanged: (value) {
                setState(() {
                  _selectedCourse = value!;
                });
              },
            ),
            const SizedBox(height: 16),
            DropdownButtonFormField<AnnouncementType>(
              value: _selectedType,
              style: TextStyle(color: textColor),
              dropdownColor: cardColor,
              decoration: InputDecoration(
                labelText: 'Type',
                labelStyle: TextStyle(color: subtitleColor),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: const BorderSide(color: Color(0xFF667eea)),
                ),
              ),
              items: AnnouncementType.values.map((type) {
                return DropdownMenuItem(
                  value: type,
                  child: Text(_getTypeDisplayName(type)),
                );
              }).toList(),
              onChanged: (value) {
                setState(() {
                  _selectedType = value!;
                });
              },
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: Text('Cancel', style: TextStyle(color: subtitleColor)),
        ),
        Container(
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Color(0xFF667eea), Color(0xFF764ba2)],
            ),
            borderRadius: BorderRadius.circular(8),
          ),
          child: TextButton(
            onPressed: _saveAnnouncement,
            child: const Text('Save', style: TextStyle(color: Colors.white)),
          ),
        ),
      ],
    );
  }

  String _getTypeDisplayName(AnnouncementType type) {
    switch (type) {
      case AnnouncementType.classCancelled:
        return 'Class Cancelled';
      case AnnouncementType.reminder:
        return 'Reminder';
      case AnnouncementType.courseMaterial:
        return 'Course Material';
      case AnnouncementType.general:
        return 'General';
    }
  }

  void _saveAnnouncement() {
    if (_titleController.text.isEmpty || _messageController.text.isEmpty) {
      return;
    }

    final announcement = Announcement(
      id: widget.announcement?.id ?? DateTime.now().millisecondsSinceEpoch.toString(),
      title: _titleController.text,
      message: _messageController.text,
      courseCode: _selectedCourse,
      timestamp: widget.announcement?.timestamp ?? DateTime.now(),
      type: _selectedType,
    );

    widget.onSave(announcement);
    Navigator.pop(context);
  }
}

// Data models
class CourseMaterial {
  final String id;
  final String title;
  final String fileName;
  final String fileSize;
  final DateTime uploadDate;
  final String courseCode;
  final MaterialType type;

  CourseMaterial({
    required this.id,
    required this.title,
    required this.fileName,
    required this.fileSize,
    required this.uploadDate,
    required this.courseCode,
    required this.type,
  });
}

enum MaterialType { lecture, assignment, reference, video }

class StudentComplaint {
  final String id;
  final String studentName;
  final String matricNo;
  final String subject;
  final String message;
  final DateTime timestamp;
  ComplaintStatus status;
  final String courseCode;

  StudentComplaint({
    required this.id,
    required this.studentName,
    required this.matricNo,
    required this.subject,
    required this.message,
    required this.timestamp,
    required this.status,
    required this.courseCode,
  });
}

enum ComplaintStatus { pending, resolved }
