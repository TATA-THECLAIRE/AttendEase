import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'dart:async';
import 'lecturer_dashboard.dart';

class RealtimeAttendanceScreen extends StatefulWidget {
  final LecturerCourse course;
  final bool isDarkMode;

  const RealtimeAttendanceScreen({
    Key? key,
    required this.course,
    required this.isDarkMode,
  }) : super(key: key);

  @override
  State<RealtimeAttendanceScreen> createState() => _RealtimeAttendanceScreenState();
}

class _RealtimeAttendanceScreenState extends State<RealtimeAttendanceScreen> {
  bool _sessionActive = false;
  DateTime? _sessionStartTime;
  Timer? _sessionTimer;
  Duration _sessionDuration = Duration.zero;
  
  final List<StudentCheckIn> _checkedInStudents = [];
  Timer? _simulationTimer;
  int _simulationIndex = 0;

  final List<Map<String, String>> _sampleStudents = [
    {'name': 'Tabe Mercy', 'matricNo': 'FE19A001', 'image': '👩🏾'},
    {'name': 'Ngozi Paul', 'matricNo': 'FE19A002', 'image': '👨🏾'},
    {'name': 'Fon Sandra', 'matricNo': 'FE19A003', 'image': '👩🏾'},
    {'name': 'Ako John', 'matricNo': 'FE19A006', 'image': '👨🏾'},
    {'name': 'Ndi Mary', 'matricNo': 'FE19A007', 'image': '👩🏾'},
    {'name': 'Kom Peter', 'matricNo': 'FE19A008', 'image': '👨🏾'},
    {'name': 'Bil Grace', 'matricNo': 'FE19A009', 'image': '👩🏾'},
    {'name': 'Che David', 'matricNo': 'FE19A010', 'image': '👨🏾'},
  ];

  Color get backgroundColor => widget.isDarkMode ? const Color(0xFF1a1a2e) : const Color(0xFFF8F9FA);
  Color get cardColor => widget.isDarkMode ? const Color(0xFF2d2d42) : Colors.white;
  Color get textColor => widget.isDarkMode ? Colors.white : const Color(0xFF2D3748);
  Color get subtitleColor => widget.isDarkMode ? Colors.grey[400]! : const Color(0xFF718096);

  LinearGradient get primaryGradient => const LinearGradient(
    colors: [Color(0xFF667eea), Color(0xFF764ba2)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  @override
  void dispose() {
    _sessionTimer?.cancel();
    _simulationTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: backgroundColor,
      body: SafeArea(
        child: Column(
          children: [
            _buildHeader(),
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    _buildSessionCard(),
                    const SizedBox(height: 20),
                    _buildStatsRow(),
                    const SizedBox(height: 20),
                    _buildStudentsList(),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        gradient: primaryGradient,
      ),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            Row(
              children: [
                // Attendease Logo
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(20),
                    child: Image.asset(
                      'assets/images/attendease_logo.png',
                      fit: BoxFit.cover,
                      errorBuilder: (context, error, stackTrace) {
                        return Container(
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [Colors.purple, Colors.teal],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: const Center(
                            child: Text(
                              'A',
                              style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 20,
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Live Attendance',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        widget.course.name,
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.9),
                          fontSize: 14,
                        ),
                      ),
                    ],
                  ),
                ),
                IconButton(
                  onPressed: () => Navigator.pop(context),
                  icon: const Icon(Icons.close, color: Colors.white),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSessionCard() {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: cardColor,
        borderRadius: BorderRadius.circular(16),
        boxShadow: widget.isDarkMode ? [] : [
          BoxShadow(
            color: Colors.black.withOpacity(0.06),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: _sessionActive ? Colors.green.withOpacity(0.1) : Colors.grey.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(
                  _sessionActive ? Icons.play_circle_filled : Icons.play_circle_outline,
                  color: _sessionActive ? Colors.green : subtitleColor,
                  size: 24,
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      _sessionActive ? 'Session Active' : 'Session Inactive',
                      style: TextStyle(
                        color: textColor,
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text(
                      _sessionActive 
                          ? 'Duration: ${_formatDuration(_sessionDuration)}'
                          : 'Ready to start attendance session',
                      style: TextStyle(
                        color: subtitleColor,
                        fontSize: 14,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          SizedBox(
            width: double.infinity,
            child: Container(
              decoration: BoxDecoration(
                gradient: _sessionActive 
                    ? LinearGradient(colors: [Colors.red.shade400, Colors.red.shade600])
                    : primaryGradient,
                borderRadius: BorderRadius.circular(12),
              ),
              child: ElevatedButton(
                onPressed: _sessionActive ? _stopSession : _startSession,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.transparent,
                  shadowColor: Colors.transparent,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                child: Text(
                  _sessionActive ? 'Stop Session' : 'Start Session',
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w600,
                    fontSize: 16,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatsRow() {
    return Row(
      children: [
        Expanded(
          child: _buildStatCard(
            'Present',
            _checkedInStudents.length.toString(),
            Colors.green,
            Icons.check_circle,
          ),
        ),
        const SizedBox(width: 16),
        Expanded(
          child: _buildStatCard(
            'Expected',
            widget.course.studentCount.toString(),
            const Color(0xFF667eea),
            Icons.people,
          ),
        ),
        const SizedBox(width: 16),
        Expanded(
          child: _buildStatCard(
            'Rate',
            '${((_checkedInStudents.length / widget.course.studentCount) * 100).toInt()}%',
            Colors.orange,
            Icons.trending_up,
          ),
        ),
      ],
    );
  }

  Widget _buildStatCard(String label, String value, Color color, IconData icon) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: cardColor,
        borderRadius: BorderRadius.circular(12),
        boxShadow: widget.isDarkMode ? [] : [
          BoxShadow(
            color: Colors.black.withOpacity(0.06),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        children: [
          Icon(icon, color: color, size: 20),
          const SizedBox(height: 8),
          Text(
            value,
            style: TextStyle(
              color: color,
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          Text(
            label,
            style: TextStyle(
              color: subtitleColor,
              fontSize: 10,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStudentsList() {
    return Container(
      decoration: BoxDecoration(
        color: cardColor,
        borderRadius: BorderRadius.circular(16),
        boxShadow: widget.isDarkMode ? [] : [
          BoxShadow(
            color: Colors.black.withOpacity(0.06),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.all(20),
            child: Row(
              children: [
                Icon(Icons.people, color: const Color(0xFF667eea), size: 24),
                const SizedBox(width: 12),
                Text(
                  'Students Checked In',
                  style: TextStyle(
                    color: textColor,
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
          if (_checkedInStudents.isEmpty)
            Padding(
              padding: const EdgeInsets.all(40),
              child: Center(
                child: Column(
                  children: [
                    Icon(
                      Icons.people_outline,
                      color: subtitleColor,
                      size: 48,
                    ),
                    const SizedBox(height: 16),
                    Text(
                      _sessionActive 
                          ? 'Waiting for students to check in...'
                          : 'Start a session to see real-time check-ins',
                      style: TextStyle(
                        color: subtitleColor,
                        fontSize: 14,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
            )
          else
            ListView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: _checkedInStudents.length,
              itemBuilder: (context, index) {
                final student = _checkedInStudents[index];
                return _buildStudentItem(student, index);
              },
            ),
        ],
      ),
    );
  }

  Widget _buildStudentItem(StudentCheckIn student, int index) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
      decoration: BoxDecoration(
        border: Border(
          bottom: BorderSide(
            color: subtitleColor.withOpacity(0.1),
            width: 1,
          ),
        ),
      ),
      child: Row(
        children: [
          // Student Avatar
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              gradient: primaryGradient,
              borderRadius: BorderRadius.circular(20),
            ),
            child: Center(
              child: Text(
                student.image,
                style: const TextStyle(fontSize: 20),
              ),
            ),
          ),
          const SizedBox(width: 16),
          // Student Info
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  student.name,
                  style: TextStyle(
                    color: textColor,
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                Text(
                  student.matricNo,
                  style: TextStyle(
                    color: subtitleColor,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
          // Check-in Time
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: Colors.green.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.check_circle, color: Colors.green, size: 12),
                    const SizedBox(width: 4),
                    const Text(
                      'Present',
                      style: TextStyle(
                        color: Colors.green,
                        fontSize: 10,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 4),
              Text(
                _formatTime(student.checkInTime),
                style: TextStyle(
                  color: subtitleColor,
                  fontSize: 10,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  void _startSession() {
    setState(() {
      _sessionActive = true;
      _sessionStartTime = DateTime.now();
      _sessionDuration = Duration.zero;
    });

    // Start session timer
    _sessionTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (_sessionStartTime != null) {
        setState(() {
          _sessionDuration = DateTime.now().difference(_sessionStartTime!);
        });
      }
    });

    // Start simulating student check-ins
    _startStudentSimulation();

    HapticFeedback.mediumImpact();
    _showSnackBar('Attendance session started for ${widget.course.name}');
  }

  void _stopSession() {
    setState(() {
      _sessionActive = false;
    });

    _sessionTimer?.cancel();
    _simulationTimer?.cancel();

    HapticFeedback.mediumImpact();
    _showSnackBar('Attendance session stopped. ${_checkedInStudents.length} students checked in.');
  }

  void _startStudentSimulation() {
    _simulationIndex = 0;
    _simulationTimer = Timer.periodic(const Duration(seconds: 3), (timer) {
      if (_simulationIndex < _sampleStudents.length && _sessionActive) {
        final studentData = _sampleStudents[_simulationIndex];
        final student = StudentCheckIn(
          name: studentData['name']!,
          matricNo: studentData['matricNo']!,
          image: studentData['image']!,
          checkInTime: DateTime.now(),
        );

        setState(() {
          _checkedInStudents.add(student);
        });

        HapticFeedback.lightImpact();
        _simulationIndex++;
      } else {
        timer.cancel();
      }
    });
  }

  String _formatDuration(Duration duration) {
    String twoDigits(int n) => n.toString().padLeft(2, '0');
    String hours = twoDigits(duration.inHours);
    String minutes = twoDigits(duration.inMinutes.remainder(60));
    String seconds = twoDigits(duration.inSeconds.remainder(60));
    return '$hours:$minutes:$seconds';
  }

  String _formatTime(DateTime time) {
    return '${time.hour.toString().padLeft(2, '0')}:${time.minute.toString().padLeft(2, '0')}';
  }

  void _showSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.green,
        duration: const Duration(seconds: 3),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }
}

class StudentCheckIn {
  final String name;
  final String matricNo;
  final String image;
  final DateTime checkInTime;

  StudentCheckIn({
    required this.name,
    required this.matricNo,
    required this.image,
    required this.checkInTime,
  });
}
