import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'lecturer_dashboard.dart';

class LecturerReportsScreen extends StatefulWidget {
  final List<LecturerCourse> courses;
  final bool isDarkMode;

  const LecturerReportsScreen({
    Key? key,
    required this.courses,
    required this.isDarkMode,
  }) : super(key: key);

  @override
  State<LecturerReportsScreen> createState() => _LecturerReportsScreenState();
}

class _LecturerReportsScreenState extends State<LecturerReportsScreen> {
  DateTime? _selectedDate;
  String? _selectedCourse;
  String? _selectedLevel;
  String? _selectedDepartment;
  bool _isEditing = false;

  final List<String> _levels = ['All Levels', 'Level 100', 'Level 200', 'Level 300', 'Level 400'];
  final List<String> _departments = ['All Departments', 'Computer Science', 'Information Technology', 'Software Engineering'];

  List<StudentAttendance> _attendanceData = [
    StudentAttendance(
      name: 'Tabe Mercy',
      matricNo: 'FE19A031',
      present: 12,
      total: 15,
      level: 'Level 300',
      department: 'Computer Science',
      isPresent: true,
    ),
    StudentAttendance(
      name: 'Ngozi Paul',
      matricNo: 'FE19A032',
      present: 14,
      total: 15,
      level: 'Level 300',
      department: 'Computer Science',
      isPresent: true,
    ),
    StudentAttendance(
      name: 'Fon Sandra',
      matricNo: 'FE19A033',
      present: 10,
      total: 15,
      level: 'Level 200',
      department: 'Information Technology',
      isPresent: false,
    ),
    StudentAttendance(
      name: 'Kom Peter',
      matricNo: 'FE19A034',
      present: 13,
      total: 15,
      level: 'Level 300',
      department: 'Computer Science',
      isPresent: true,
    ),
    StudentAttendance(
      name: 'Bil Grace',
      matricNo: 'FE19A035',
      present: 11,
      total: 15,
      level: 'Level 400',
      department: 'Software Engineering',
      isPresent: false,
    ),
  ];

  List<StudentAttendance> _filteredData = [];

  @override
  void initState() {
    super.initState();
    _filteredData = List.from(_attendanceData);
  }

  Color get backgroundColor => widget.isDarkMode ? const Color(0xFF1a1a2e) : const Color(0xFFF8F9FA);
  Color get cardColor => widget.isDarkMode ? const Color(0xFF2d2d42) : Colors.white;
  Color get textColor => widget.isDarkMode ? Colors.white : const Color(0xFF2D3748);
  Color get subtitleColor => widget.isDarkMode ? Colors.grey[400]! : const Color(0xFF718096);

  LinearGradient get primaryGradient => const LinearGradient(
    colors: [Color(0xFF667eea), Color(0xFF764ba2)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: backgroundColor,
      body: SafeArea(
        child: Column(
          children: [
            _buildHeader(),
            _buildFilters(),
            Expanded(child: _buildAttendanceTable()),
            _buildActionButtons(),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        gradient: primaryGradient,
      ),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            Row(
              children: [
                // Attendease Logo
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(20),
                    child: Image.asset(
                      'assets/images/attendease_logo.png',
                      fit: BoxFit.cover,
                      errorBuilder: (context, error, stackTrace) {
                        return Container(
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [Colors.purple, Colors.teal],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: const Center(
                            child: Text(
                              'A',
                              style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 20,
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Reports',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        'Attendance analytics and reports',
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.9),
                          fontSize: 14,
                        ),
                      ),
                    ],
                  ),
                ),
                IconButton(
                  onPressed: () => setState(() => _isEditing = !_isEditing),
                  icon: Icon(
                    _isEditing ? Icons.done : Icons.edit,
                    color: Colors.white,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Text(
                  'No Internet Connection',
                  style: TextStyle(color: Colors.white.withOpacity(0.8), fontSize: 12),
                ),
                const SizedBox(width: 8),
                Icon(Icons.wifi_off, color: Colors.white.withOpacity(0.8), size: 16),
                Spacer(),
                Icon(Icons.star, color: Colors.amber),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFilters() {
    return Container(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          // First row - Date and Course
          Row(
            children: [
              Expanded(
                child: GestureDetector(
                  onTap: () => _selectDate(),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                    decoration: BoxDecoration(
                      color: cardColor,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: subtitleColor.withOpacity(0.3)),
                    ),
                    child: Row(
                      children: [
                        Icon(Icons.calendar_today, color: subtitleColor, size: 16),
                        const SizedBox(width: 8),
                        Text(
                          _selectedDate != null 
                              ? '${_selectedDate!.day.toString().padLeft(2, '0')}/${_selectedDate!.month.toString().padLeft(2, '0')}/${_selectedDate!.year}'
                              : 'Select Date',
                          style: TextStyle(color: textColor, fontSize: 14),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _buildDropdownFilter(
                  'Course',
                  _selectedCourse,
                  ['All Courses', ...widget.courses.map((c) => c.name)],
                  (value) => setState(() => _selectedCourse = value),
                  Icons.school,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          // Second row - Level and Department
          Row(
            children: [
              Expanded(
                child: _buildDropdownFilter(
                  'Level',
                  _selectedLevel,
                  _levels,
                  (value) => setState(() => _selectedLevel = value),
                  Icons.grade,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _buildDropdownFilter(
                  'Department',
                  _selectedDepartment,
                  _departments,
                  (value) => setState(() => _selectedDepartment = value),
                  Icons.business,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: Container(
                  decoration: BoxDecoration(
                    gradient: primaryGradient,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: TextButton(
                    onPressed: _applyFilters,
                    child: const Text(
                      'Apply Filters',
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Container(
                decoration: BoxDecoration(
                  border: Border.all(color: subtitleColor),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: TextButton(
                  onPressed: _clearFilters,
                  child: Text(
                    'Clear',
                    style: TextStyle(
                      color: subtitleColor,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildDropdownFilter(
    String hint,
    String? value,
    List<String> items,
    Function(String?) onChanged,
    IconData icon,
  ) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      decoration: BoxDecoration(
        color: cardColor,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: subtitleColor.withOpacity(0.3)),
      ),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          value: value,
          hint: Row(
            children: [
              Icon(icon, color: subtitleColor, size: 16),
              const SizedBox(width: 8),
              Text(hint, style: TextStyle(color: subtitleColor, fontSize: 14)),
            ],
          ),
          isExpanded: true,
          dropdownColor: cardColor,
          style: TextStyle(color: textColor, fontSize: 14),
          items: items.map((String item) {
            return DropdownMenuItem<String>(
              value: item,
              child: Text(item),
            );
          }).toList(),
          onChanged: onChanged,
        ),
      ),
    );
  }

  Widget _buildAttendanceTable() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      decoration: BoxDecoration(
        color: cardColor,
        borderRadius: BorderRadius.circular(12),
        boxShadow: widget.isDarkMode ? [] : [
          BoxShadow(
            color: Colors.black.withOpacity(0.06),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        children: [
          // Table Header
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: subtitleColor.withOpacity(0.1),
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(12),
                topRight: Radius.circular(12),
              ),
            ),
            child: Row(
              children: [
                Expanded(
                  flex: 2,
                  child: Text(
                    'Student',
                    style: TextStyle(
                      color: textColor,
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                Expanded(
                  flex: 2,
                  child: Text(
                    'Matric#',
                    style: TextStyle(
                      color: textColor,
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                if (_isEditing)
                  Expanded(
                    child: Text(
                      'Status',
                      style: TextStyle(
                        color: textColor,
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                Expanded(
                  child: Text(
                    'Present',
                    style: TextStyle(
                      color: textColor,
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
                Expanded(
                  child: Text(
                    'Total',
                    style: TextStyle(
                      color: textColor,
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
                Expanded(
                  child: Text(
                    '%',
                    style: TextStyle(
                      color: textColor,
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
              ],
            ),
          ),
          // Table Body
          Expanded(
            child: ListView.builder(
              itemCount: _filteredData.length,
              itemBuilder: (context, index) {
                final student = _filteredData[index];
                final percentage = ((student.present / student.total) * 100).round();
                
                return Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    border: Border(
                      bottom: BorderSide(
                        color: subtitleColor.withOpacity(0.1),
                        width: 1,
                      ),
                    ),
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        flex: 2,
                        child: Text(
                          student.name,
                          style: TextStyle(
                            color: textColor,
                            fontSize: 12,
                          ),
                        ),
                      ),
                      Expanded(
                        flex: 2,
                        child: Text(
                          student.matricNo,
                          style: TextStyle(
                            color: subtitleColor,
                            fontSize: 12,
                          ),
                        ),
                      ),
                      if (_isEditing)
                        Expanded(
                          child: GestureDetector(
                            onTap: () => _toggleAttendance(index),
                            child: Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                              decoration: BoxDecoration(
                                color: student.isPresent ? Colors.green.withOpacity(0.1) : Colors.red.withOpacity(0.1),
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(
                                  color: student.isPresent ? Colors.green : Colors.red,
                                ),
                              ),
                              child: Text(
                                student.isPresent ? 'Present' : 'Absent',
                                style: TextStyle(
                                  color: student.isPresent ? Colors.green : Colors.red,
                                  fontSize: 10,
                                  fontWeight: FontWeight.bold,
                                ),
                                textAlign: TextAlign.center,
                              ),
                            ),
                          ),
                        ),
                      Expanded(
                        child: _isEditing 
                            ? _buildEditableField(student.present.toString(), (value) {
                                setState(() {
                                  student.present = int.tryParse(value) ?? student.present;
                                });
                              })
                            : Text(
                                student.present.toString(),
                                style: TextStyle(
                                  color: textColor,
                                  fontSize: 12,
                                ),
                                textAlign: TextAlign.center,
                              ),
                      ),
                      Expanded(
                        child: _isEditing 
                            ? _buildEditableField(student.total.toString(), (value) {
                                setState(() {
                                  student.total = int.tryParse(value) ?? student.total;
                                });
                              })
                            : Text(
                                student.total.toString(),
                                style: TextStyle(
                                  color: textColor,
                                  fontSize: 12,
                                ),
                                textAlign: TextAlign.center,
                              ),
                      ),
                      Expanded(
                        child: Text(
                          '$percentage%',
                          style: TextStyle(
                            color: percentage >= 75 ? Colors.green : 
                                   percentage >= 50 ? Colors.orange : Colors.red,
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEditableField(String initialValue, Function(String) onChanged) {
    return Container(
      width: 40,
      height: 30,
      child: TextFormField(
        initialValue: initialValue,
        textAlign: TextAlign.center,
        style: TextStyle(color: textColor, fontSize: 12),
        decoration: InputDecoration(
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(4),
            borderSide: BorderSide(color: subtitleColor.withOpacity(0.3)),
          ),
          contentPadding: const EdgeInsets.all(4),
        ),
        keyboardType: TextInputType.number,
        onChanged: onChanged,
      ),
    );
  }

  Widget _buildActionButtons() {
    return Container(
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          Expanded(
            child: OutlinedButton.icon(
              onPressed: _exportToCSV,
              icon: const Icon(Icons.download, size: 16),
              label: const Text(
                'Export CSV',
                style: TextStyle(fontWeight: FontWeight.w600),
              ),
              style: OutlinedButton.styleFrom(
                foregroundColor: const Color(0xFF667eea),
                side: const BorderSide(color: Color(0xFF667eea)),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
                padding: const EdgeInsets.symmetric(vertical: 12),
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                gradient: primaryGradient,
                borderRadius: BorderRadius.circular(8),
              ),
              child: TextButton.icon(
                onPressed: _exportToPDF,
                icon: const Icon(Icons.picture_as_pdf, color: Colors.white, size: 16),
                label: const Text(
                  'Export PDF',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _selectDate() async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate ?? DateTime.now(),
      firstDate: DateTime(2020),
      lastDate: DateTime.now(),
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: ColorScheme.light(
              primary: const Color(0xFF667eea),
              onPrimary: Colors.white,
              surface: cardColor,
              onSurface: textColor,
            ),
          ),
          child: child!,
        );
      },
    );
    if (picked != null && picked != _selectedDate) {
      setState(() {
        _selectedDate = picked;
      });
    }
  }

  void _applyFilters() {
    setState(() {
      _filteredData = _attendanceData.where((student) {
        bool matchesDate = _selectedDate == null; // If no date selected, show all
        bool matchesCourse = _selectedCourse == null || _selectedCourse == 'All Courses';
        bool matchesLevel = _selectedLevel == null || _selectedLevel == 'All Levels' || student.level == _selectedLevel;
        bool matchesDepartment = _selectedDepartment == null || _selectedDepartment == 'All Departments' || student.department == _selectedDepartment;
        
        return matchesDate && matchesCourse && matchesLevel && matchesDepartment;
      }).toList();
    });
    
    HapticFeedback.lightImpact();
    _showSnackBar('Filters applied - ${_filteredData.length} students found');
  }

  void _clearFilters() {
    setState(() {
      _selectedDate = null;
      _selectedCourse = null;
      _selectedLevel = null;
      _selectedDepartment = null;
      _filteredData = List.from(_attendanceData);
    });
    
    HapticFeedback.lightImpact();
    _showSnackBar('Filters cleared');
  }

  void _toggleAttendance(int index) {
    setState(() {
      _filteredData[index].isPresent = !_filteredData[index].isPresent;
      if (_filteredData[index].isPresent) {
        _filteredData[index].present++;
      } else {
        _filteredData[index].present = (_filteredData[index].present - 1).clamp(0, _filteredData[index].total);
      }
    });
    HapticFeedback.lightImpact();
  }

  void _exportToCSV() {
    _showSnackBar('Exporting attendance data to CSV...');
  }

  void _exportToPDF() {
    _showSnackBar('Exporting attendance data to PDF...');
  }

  void _showSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: const Color(0xFF667eea),
        duration: const Duration(seconds: 2),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }
}

class StudentAttendance {
  final String name;
  final String matricNo;
  int present;
  int total;
  final String level;
  final String department;
  bool isPresent;

  StudentAttendance({
    required this.name,
    required this.matricNo,
    required this.present,
    required this.total,
    required this.level,
    required this.department,
    required this.isPresent,
  });
}
