import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:file_picker/file_picker.dart';
import 'package:intl/intl.dart';
import 'dart:io';
import '../lecturer/lecturer_dashboard.dart';
import '../../models/announcement.dart';

class CourseManagementScreen extends StatefulWidget {
  final LecturerCourse course;
  final bool isDarkMode;

  const CourseManagementScreen({
    Key? key,
    required this.course,
    required this.isDarkMode,
  }) : super(key: key);

  @override
  _CourseManagementScreenState createState() => _CourseManagementScreenState();
}

class _CourseManagementScreenState extends State<CourseManagementScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  int _selectedBottomIndex = 1; // Default to courses tab
  
  // Sample data
  final List<AttendanceRecord> _attendanceRecords = [
    AttendanceRecord(
      id: '1',
      studentName: 'John Doe',
      studentId: 'STU001',
      date: DateTime.now().subtract(const Duration(days: 0)),
      status: AttendanceStatus.present,
      arrivalTime: '09:05 AM',
    ),
    AttendanceRecord(
      id: '2',
      studentName: 'Jane Smith',
      studentId: 'STU002',
      date: DateTime.now().subtract(const Duration(days: 0)),
      status: AttendanceStatus.present,
      arrivalTime: '09:00 AM',
    ),
    AttendanceRecord(
      id: '3',
      studentName: 'Michael Johnson',
      studentId: 'STU003',
      date: DateTime.now().subtract(const Duration(days: 0)),
      status: AttendanceStatus.absent,
      arrivalTime: '-',
    ),
    AttendanceRecord(
      id: '4',
      studentName: 'Emily Brown',
      studentId: 'STU004',
      date: DateTime.now().subtract(const Duration(days: 0)),
      status: AttendanceStatus.late,
      arrivalTime: '09:30 AM',
    ),
    AttendanceRecord(
      id: '5',
      studentName: 'David Wilson',
      studentId: 'STU005',
      date: DateTime.now().subtract(const Duration(days: 1)),
      status: AttendanceStatus.present,
      arrivalTime: '09:02 AM',
    ),
    AttendanceRecord(
      id: '6',
      studentName: 'Sarah Lee',
      studentId: 'STU006',
      date: DateTime.now().subtract(const Duration(days: 1)),
      status: AttendanceStatus.present,
      arrivalTime: '08:55 AM',
    ),
    AttendanceRecord(
      id: '7',
      studentName: 'James Miller',
      studentId: 'STU007',
      date: DateTime.now().subtract(const Duration(days: 1)),
      status: AttendanceStatus.absent,
      arrivalTime: '-',
    ),
    AttendanceRecord(
      id: '8',
      studentName: 'Jessica Davis',
      studentId: 'STU008',
      date: DateTime.now().subtract(const Duration(days: 2)),
      status: AttendanceStatus.present,
      arrivalTime: '09:00 AM',
    ),
    AttendanceRecord(
      id: '9',
      studentName: 'Robert Garcia',
      studentId: 'STU009',
      date: DateTime.now().subtract(const Duration(days: 2)),
      status: AttendanceStatus.late,
      arrivalTime: '09:20 AM',
    ),
    AttendanceRecord(
      id: '10',
      studentName: 'Amanda Martinez',
      studentId: 'STU010',
      date: DateTime.now().subtract(const Duration(days: 2)),
      status: AttendanceStatus.present,
      arrivalTime: '08:58 AM',
    ),
  ];

  final List<CourseMaterial> _materials = [
    CourseMaterial(
      id: '1',
      title: 'Lecture 1: Course Introduction',
      type: MaterialType.pdf,
      uploadDate: DateTime.now().subtract(const Duration(days: 14)),
      fileSize: '2.5 MB',
      downloadCount: 42,
    ),
    CourseMaterial(
      id: '2',
      title: 'Lab Assignment 1',
      type: MaterialType.doc,
      uploadDate: DateTime.now().subtract(const Duration(days: 12)),
      fileSize: '550 KB',
      downloadCount: 38,
    ),
    CourseMaterial(
      id: '3',
      title: 'Lecture 2: Fundamentals',
      type: MaterialType.pdf,
      uploadDate: DateTime.now().subtract(const Duration(days: 10)),
      fileSize: '3.2 MB',
      downloadCount: 35,
    ),
    CourseMaterial(
      id: '4',
      title: 'Tutorial Session Recording',
      type: MaterialType.video,
      uploadDate: DateTime.now().subtract(const Duration(days: 7)),
      fileSize: '125 MB',
      downloadCount: 28,
    ),
    CourseMaterial(
      id: '5',
      title: 'Practice Problems Set',
      type: MaterialType.pdf,
      uploadDate: DateTime.now().subtract(const Duration(days: 3)),
      fileSize: '1.8 MB',
      downloadCount: 25,
    ),
  ];

  final List<StudentComplaint> _complaints = [
    StudentComplaint(
      id: '1',
      studentName: 'Michael Johnson',
      studentId: 'STU003',
      date: DateTime.now().subtract(const Duration(days: 2)),
      title: 'Attendance Marking Error',
      description: 'I was present in the class on Monday but was marked absent.',
      status: ComplaintStatus.pending,
    ),
    StudentComplaint(
      id: '2',
      studentName: 'Emily Brown',
      studentId: 'STU004',
      date: DateTime.now().subtract(const Duration(days: 4)),
      title: 'Unable to Access Course Materials',
      description: 'I cannot download the PDF for Lecture 2.',
      status: ComplaintStatus.resolved,
    ),
    StudentComplaint(
      id: '3',
      studentName: 'David Wilson',
      studentId: 'STU005',
      date: DateTime.now().subtract(const Duration(days: 5)),
      title: 'Assignment Submission Issue',
      description: 'I submitted my assignment but it shows as not submitted.',
      status: ComplaintStatus.inProgress,
    ),
  ];

  final List<StudentAssignment> _assignments = [
    StudentAssignment(
      id: '1',
      studentName: 'John Doe',
      studentId: 'STU001',
      title: 'Lab Assignment 1',
      submissionDate: DateTime.now().subtract(const Duration(days: 5)),
      score: 85,
      maxScore: 100,
    ),
    StudentAssignment(
      id: '2',
      studentName: 'Jane Smith',
      studentId: 'STU002',
      title: 'Lab Assignment 1',
      submissionDate: DateTime.now().subtract(const Duration(days: 6)),
      score: 92,
      maxScore: 100,
    ),
    StudentAssignment(
      id: '3',
      studentName: 'Emily Brown',
      studentId: 'STU004',
      title: 'Lab Assignment 1',
      submissionDate: DateTime.now().subtract(const Duration(days: 4)),
      score: 78,
      maxScore: 100,
    ),
    StudentAssignment(
      id: '4',
      studentName: 'David Wilson',
      studentId: 'STU005',
      title: 'Lab Assignment 1',
      submissionDate: DateTime.now().subtract(const Duration(days: 5)),
      score: 88,
      maxScore: 100,
    ),
  ];

  List<Announcement> _announcements = [
    Announcement(
      id: '1',
      title: 'Class Canceled Tomorrow',
      message: 'Due to unforeseen circumstances, tomorrow\'s class will be canceled. We will reschedule for next week.',
      courseCode: 'CS301',
      timestamp: DateTime.now().subtract(Duration(hours: 2)),
      type: AnnouncementType.classCancelled,
    ),
    Announcement(
      id: '2',
      title: 'Assignment Deadline Extended',
      message: 'The deadline for Lab Assignment 1 has been extended to Friday, 5 PM.',
      courseCode: 'CS301',
      timestamp: DateTime.now().subtract(Duration(days: 1)),
      type: AnnouncementType.reminder,
    ),
  ];

  // Filter variables
  DateTime? _selectedDate;
  String? _selectedLevel;
  String? _selectedDepartment;
  bool _isEditMode = false;
  List<String> _levels = ['Level 100', 'Level 200', 'Level 300', 'Level 400'];
  List<String> _departments = ['Computer Science', 'Information Technology', 'Software Engineering'];

  List<AttendanceRecord> get filteredAttendanceRecords {
    return _attendanceRecords.where((record) {
      // Filter by date
      if (_selectedDate != null) {
        bool sameDate = record.date.year == _selectedDate!.year &&
            record.date.month == _selectedDate!.month &&
            record.date.day == _selectedDate!.day;
        if (!sameDate) return false;
      }
      // Filter by level - would need student level data
      // Filter by department - would need student department data
      return true;
    }).toList();
  }

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 5, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Color get backgroundColor => widget.isDarkMode ? const Color(0xFF1a1a2e) : const Color(0xFFF8F9FA);
  Color get cardColor => widget.isDarkMode ? const Color(0xFF2d2d42) : Colors.white;
  Color get textColor => widget.isDarkMode ? Colors.white : const Color(0xFF2D3748);
  Color get subtitleColor => widget.isDarkMode ? Colors.grey[400]! : const Color(0xFF718096);

  LinearGradient get primaryGradient => const LinearGradient(
    colors: [Color(0xFF667eea), Color(0xFF764ba2)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: backgroundColor,
      appBar: _buildAppBar(),
      body: Column(
        children: [
          _buildCourseInfo(),
          _buildTabBar(),
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                _buildOverviewTab(),
                _buildAttendanceTab(),
                _buildMaterialsTab(),
                _buildComplaintsTab(),
                _buildAssignmentsTab(),
              ],
            ),
          ),
        ],
      ),
      bottomNavigationBar: _buildBottomNavBar(),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: backgroundColor,
      elevation: 0,
      leading: IconButton(
        onPressed: () => Navigator.pop(context),
        icon: Icon(Icons.arrow_back, color: textColor),
      ),
      title: Row(
        children: [
          // Attendease Logo
          Container(
            width: 30,
            height: 30,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(15),
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(15),
              child: Image.asset(
                'assets/images/attendease_logo.png',
                fit: BoxFit.cover,
                errorBuilder: (context, error, stackTrace) {
                  return Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [Colors.purple, Colors.teal],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(15),
                    ),
                    child: const Center(
                      child: Text(
                        'A',
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ),
          const SizedBox(width: 8),
          Text(
            'Course Management',
            style: TextStyle(
              color: textColor,
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
      actions: [
        IconButton(
          onPressed: () {
            _showSnackBar('Course settings opened');
          },
          icon: Icon(Icons.settings, color: textColor),
        ),
      ],
    );
  }

  Widget _buildCourseInfo() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: primaryGradient,
        borderRadius: const BorderRadius.only(
          bottomLeft: Radius.circular(24),
          bottomRight: Radius.circular(24),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  widget.course.code,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: widget.course.isActive 
                      ? Colors.green.withOpacity(0.2)
                      : Colors.red.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  widget.course.isActive ? 'ACTIVE' : 'INACTIVE',
                  style: TextStyle(
                    color: widget.course.isActive ? Colors.green[100] : Colors.red[100],
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            widget.course.name,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 24,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            widget.course.level,
            style: TextStyle(
              color: Colors.white.withOpacity(0.9),
              fontSize: 14,
            ),
          ),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _buildInfoItem(Icons.people, 'Students', widget.course.studentCount.toString()),
              _buildInfoItem(Icons.calendar_today, 'Sessions', '24'),
              _buildInfoItem(Icons.assignment, 'Attendance', '87%'),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildInfoItem(IconData icon, String label, String value) {
    return Column(
      children: [
        Icon(icon, color: Colors.white, size: 24),
        const SizedBox(height: 4),
        Text(
          value,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
        Text(
          label,
          style: TextStyle(
            color: Colors.white.withOpacity(0.8),
            fontSize: 12,
          ),
        ),
      ],
    );
  }

  Widget _buildTabBar() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: cardColor,
        borderRadius: BorderRadius.circular(12),
        boxShadow: widget.isDarkMode ? [] : [
          BoxShadow(
            color: Colors.black.withOpacity(0.06),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: TabBar(
        controller: _tabController,
        isScrollable: true,
        labelColor: Colors.white,
        unselectedLabelColor: subtitleColor,
        indicator: BoxDecoration(
          gradient: primaryGradient,
          borderRadius: BorderRadius.circular(8),
        ),
        indicatorSize: TabBarIndicatorSize.tab,
        dividerColor: Colors.transparent,
        tabs: const [
          Tab(text: 'Overview'),
          Tab(text: 'Attendance'),
          Tab(text: 'Materials'),
          Tab(text: 'Complaints'),
          Tab(text: 'Assignments'),
        ],
      ),
    );
  }

  Widget _buildOverviewTab() {
    final stats = _calculateStats();
    
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildSectionHeader('Course Statistics'),
          _buildStatsCards(stats),
          const SizedBox(height: 24),
          _buildSectionHeader('Recent Announcements'),
          if (_announcements.isEmpty)
            _buildEmptyState('No announcements yet', Icons.announcement),
          ...(_announcements.isNotEmpty ? _announcements.map(_buildAnnouncementCard).toList() : []),
          const SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: () => _createAnnouncement(),
              icon: const Icon(Icons.add, size: 16),
              label: const Text('Create Announcement'),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF667eea),
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
            ),
          ),
          const SizedBox(height: 24),
          _buildSectionHeader('Recent Activity'),
          _buildRecentActivityList(),
        ],
      ),
    );
  }

  Map<String, dynamic> _calculateStats() {
    int totalStudents = widget.course.studentCount;
    int totalSessions = 8; // Sample data
    
    int presentCount = _attendanceRecords.where((r) => r.status == AttendanceStatus.present).length;
    int lateCount = _attendanceRecords.where((r) => r.status == AttendanceStatus.late).length;
    int absentCount = _attendanceRecords.where((r) => r.status == AttendanceStatus.absent).length;
    
    double attendanceRate = (presentCount + lateCount) / (presentCount + lateCount + absentCount) * 100;
    double punctualityRate = presentCount / (presentCount + lateCount) * 100;
    
    return {
      'totalStudents': totalStudents,
      'totalSessions': totalSessions,
      'attendanceRate': attendanceRate,
      'punctualityRate': punctualityRate,
      'presentCount': presentCount,
      'lateCount': lateCount,
      'absentCount': absentCount,
    };
  }

  Widget _buildStatsCards(Map<String, dynamic> stats) {
    return Column(
      children: [
        Row(
          children: [
            Expanded(
              child: _buildStatCard(
                '${stats['attendanceRate'].toStringAsFixed(1)}%',
                'Attendance Rate',
                Icons.people,
                Colors.blue,
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: _buildStatCard(
                '${stats['punctualityRate'].toStringAsFixed(1)}%',
                'Punctuality Rate',
                Icons.timer,
                Colors.green,
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(
              child: _buildStatCard(
                '${stats['presentCount']}',
                'Present',
                Icons.check_circle,
                Colors.green,
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: _buildStatCard(
                '${stats['lateCount']}',
                'Late',
                Icons.watch_later,
                Colors.orange,
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: _buildStatCard(
                '${stats['absentCount']}',
                'Absent',
                Icons.cancel,
                Colors.red,
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildStatCard(String value, String label, IconData icon, Color color) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: cardColor,
        borderRadius: BorderRadius.circular(12),
        boxShadow: widget.isDarkMode ? [] : [
          BoxShadow(
            color: Colors.black.withOpacity(0.06),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        children: [
          Icon(icon, color: color, size: 24),
          const SizedBox(height: 8),
          Text(
            value,
            style: TextStyle(
              color: textColor,
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
          Text(
            label,
            style: TextStyle(
              color: subtitleColor,
              fontSize: 12,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAnnouncementCard(Announcement announcement) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: cardColor,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: _getAnnouncementColor(announcement.type).withOpacity(0.3),
          width: 1,
        ),
        boxShadow: widget.isDarkMode ? [] : [
          BoxShadow(
            color: Colors.black.withOpacity(0.06),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: _getAnnouncementColor(announcement.type).withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Icon(
                  _getAnnouncementIcon(announcement.type),
                  color: _getAnnouncementColor(announcement.type),
                  size: 16,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  announcement.title,
                  style: TextStyle(
                    color: textColor,
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              PopupMenuButton<String>(
                onSelected: (value) {
                  if (value == 'edit') {
                    _editAnnouncement(announcement);
                  } else if (value == 'delete') {
                    _deleteAnnouncement(announcement.id);
                  }
                },
                itemBuilder: (context) => [
                  const PopupMenuItem(
                    value: 'edit',
                    child: Row(
                      children: [
                        Icon(Icons.edit, size: 18),
                        SizedBox(width: 8),
                        Text('Edit'),
                      ],
                    ),
                  ),
                  const PopupMenuItem(
                    value: 'delete',
                    child: Row(
                      children: [
                        Icon(Icons.delete, size: 18, color: Colors.red),
                        SizedBox(width: 8),
                        Text('Delete', style: TextStyle(color: Colors.red)),
                      ],
                    ),
                  ),
                ],
                icon: Icon(Icons.more_vert, color: subtitleColor),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            announcement.message,
            style: TextStyle(
              color: textColor,
              fontSize: 13,
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Icon(Icons.access_time, color: subtitleColor, size: 12),
              const SizedBox(width: 4),
              Text(
                _formatDateTime(announcement.timestamp),
                style: TextStyle(
                  color: subtitleColor,
                  fontSize: 12,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildRecentActivityList() {
    return Column(
      children: [
        _buildActivityItem(
          Icons.assignment_turned_in,
          'New Assignment Submitted',
          '3 students submitted Lab Assignment 1',
          '2 hours ago',
        ),
        _buildActivityItem(
          Icons.person_add,
          'New Student Added',
          'Amanda Martinez joined the course',
          '1 day ago',
        ),
        _buildActivityItem(
          Icons.upload_file,
          'Material Uploaded',
          'Lecture 2: Fundamentals (PDF)',
          '3 days ago',
        ),
      ],
    );
  }

  Widget _buildActivityItem(IconData icon, String title, String subtitle, String time) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: cardColor,
        borderRadius: BorderRadius.circular(12),
        boxShadow: widget.isDarkMode ? [] : [
          BoxShadow(
            color: Colors.black.withOpacity(0.06),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: const Color(0xFF667eea).withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(
              icon,
              color: const Color(0xFF667eea),
              size: 16,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    color: textColor,
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                Text(
                  subtitle,
                  style: TextStyle(
                    color: subtitleColor,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
          Text(
            time,
            style: TextStyle(
              color: subtitleColor,
              fontSize: 12,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAttendanceTab() {
    return Column(
      children: [
        _buildAttendanceFilters(),
        _buildAttendanceHeader(),
        Expanded(
          child: filteredAttendanceRecords.isEmpty
              ? _buildEmptyState('No attendance records found', Icons.event_busy)
              : SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Container(
                    width: MediaQuery.of(context).size.width,
                    child: ListView.builder(
                      itemCount: filteredAttendanceRecords.length,
                      itemBuilder: (context, index) {
                        final record = filteredAttendanceRecords[index];
                        return _buildAttendanceRow(record);
                      },
                    ),
                  ),
                ),
        ),
      ],
    );
  }

  Widget _buildAttendanceFilters() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: cardColor,
        borderRadius: const BorderRadius.only(
          bottomLeft: Radius.circular(16),
          bottomRight: Radius.circular(16),
        ),
      ),
      child: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: GestureDetector(
                  onTap: () => _selectDate(context),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    decoration: BoxDecoration(
                      border: Border.all(color: subtitleColor.withOpacity(0.3)),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Row(
                      children: [
                        Icon(Icons.calendar_today, color: subtitleColor, size: 16),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            _selectedDate == null
                                ? 'Select Date'
                                : DateFormat('dd/MM/yyyy').format(_selectedDate!),
                            style: TextStyle(color: textColor, fontSize: 14),
                          ),
                        ),
                        if (_selectedDate != null)
                          GestureDetector(
                            onTap: () {
                              setState(() => _selectedDate = null);
                            },
                            child: Icon(Icons.close, color: subtitleColor, size: 16),
                          ),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: DropdownButton<String>(
                  value: _selectedLevel,
                  hint: Text('Level', style: TextStyle(color: subtitleColor)),
                  style: TextStyle(color: textColor),
                  dropdownColor: cardColor,
                  underline: Container(),
                  icon: Icon(Icons.arrow_drop_down, color: subtitleColor),
                  isExpanded: true,
                  items: [null, ..._levels].map((level) {
                    return DropdownMenuItem(
                      value: level,
                      child: Text(level ?? 'All Levels'),
                    );
                  }).toList(),
                  onChanged: (value) {
                    setState(() => _selectedLevel = value);
                  },
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: DropdownButton<String>(
                  value: _selectedDepartment,
                  hint: Text('Dept', style: TextStyle(color: subtitleColor)),
                  style: TextStyle(color: textColor),
                  dropdownColor: cardColor,
                  underline: Container(),
                  icon: Icon(Icons.arrow_drop_down, color: subtitleColor),
                  isExpanded: true,
                  items: [null, ..._departments].map((dept) {
                    return DropdownMenuItem(
                      value: dept,
                      child: Text(dept ?? 'All Departments'),
                    );
                  }).toList(),
                  onChanged: (value) {
                    setState(() => _selectedDepartment = value);
                  },
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Text(
                '${filteredAttendanceRecords.length} records found',
                style: TextStyle(color: subtitleColor, fontSize: 12),
              ),
              const Spacer(),
              OutlinedButton.icon(
                onPressed: () {
                  setState(() {
                    _selectedDate = null;
                    _selectedLevel = null;
                    _selectedDepartment = null;
                  });
                },
                icon: Icon(Icons.filter_alt_off, size: 16),
                label: const Text('Clear Filters'),
                style: OutlinedButton.styleFrom(
                  foregroundColor: subtitleColor,
                  side: BorderSide(color: subtitleColor.withOpacity(0.5)),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                ),
              ),
              const SizedBox(width: 8),
              ElevatedButton.icon(
                onPressed: () {
                  setState(() => _isEditMode = !_isEditMode);
                  HapticFeedback.lightImpact();
                },
                icon: Icon(_isEditMode ? Icons.done : Icons.edit, size: 16),
                label: Text(_isEditMode ? 'Save' : 'Edit'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: _isEditMode ? Colors.green : const Color(0xFF667eea),
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildAttendanceHeader() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      color: widget.isDarkMode ? const Color(0xFF22223b) : const Color(0xFFf0f4f8),
      child: Row(
        children: [
          Expanded(
            flex: 3,
            child: Text(
              'Student',
              style: TextStyle(
                color: textColor,
                fontSize: 14,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          Expanded(
            flex: 2,
            child: Text(
              'ID',
              style: TextStyle(
                color: textColor,
                fontSize: 14,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          Expanded(
            flex: 2,
            child: Text(
              'Date',
              style: TextStyle(
                color: textColor,
                fontSize: 14,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          Expanded(
            flex: 2,
            child: Text(
              'Time',
              style: TextStyle(
                color: textColor,
                fontSize: 14,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          Expanded(
            flex: 2,
            child: Text(
              'Status',
              style: TextStyle(
                color: textColor,
                fontSize: 14,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAttendanceRow(AttendanceRecord record) {
    Color statusColor;
    String statusText;
    
    switch (record.status) {
      case AttendanceStatus.present:
        statusColor = Colors.green;
        statusText = 'Present';
        break;
      case AttendanceStatus.late:
        statusColor = Colors.orange;
        statusText = 'Late';
        break;
      case AttendanceStatus.absent:
        statusColor = Colors.red;
        statusText = 'Absent';
        break;
    }
    
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        border: Border(
          bottom: BorderSide(
            color: subtitleColor.withOpacity(0.2),
            width: 1,
          ),
        ),
      ),
      child: Row(
        children: [
          Expanded(
            flex: 3,
            child: Text(
              record.studentName,
              style: TextStyle(
                color: textColor,
                fontSize: 14,
              ),
              overflow: TextOverflow.ellipsis,
            ),
          ),
          Expanded(
            flex: 2,
            child: Text(
              record.studentId,
              style: TextStyle(
                color: subtitleColor,
                fontSize: 14,
              ),
              overflow: TextOverflow.ellipsis,
            ),
          ),
          Expanded(
            flex: 2,
            child: Text(
              DateFormat('dd/MM/yy').format(record.date),
              style: TextStyle(
                color: subtitleColor,
                fontSize: 14,
              ),
            ),
          ),
          Expanded(
            flex: 2,
            child: Text(
              record.arrivalTime,
              style: TextStyle(
                color: subtitleColor,
                fontSize: 14,
              ),
            ),
          ),
          Expanded(
            flex: 2,
            child: _isEditMode
                ? DropdownButton<AttendanceStatus>(
                    value: record.status,
                    isDense: true,
                    underline: Container(),
                    icon: Icon(Icons.arrow_drop_down, color: statusColor, size: 16),
                    onChanged: (AttendanceStatus? value) {
                      if (value != null) {
                        setState(() {
                          record.status = value;
                          if (value == AttendanceStatus.absent) {
                            record.arrivalTime = '-';
                          } else if (value == AttendanceStatus.late && record.arrivalTime == '-') {
                            record.arrivalTime = '09:30 AM';
                          } else if (value == AttendanceStatus.present && record.arrivalTime == '-') {
                            record.arrivalTime = '09:00 AM';
                          }
                        });
                      }
                    },
                    dropdownColor: cardColor,
                    items: AttendanceStatus.values.map((status) {
                      String label;
                      Color color;
                      
                      switch (status) {
                        case AttendanceStatus.present:
                          label = 'Present';
                          color = Colors.green;
                          break;
                        case AttendanceStatus.late:
                          label = 'Late';
                          color = Colors.orange;
                          break;
                        case AttendanceStatus.absent:
                          label = 'Absent';
                          color = Colors.red;
                          break;
                      }
                      
                      return DropdownMenuItem<AttendanceStatus>(
                        value: status,
                        child: Text(
                          label,
                          style: TextStyle(color: color, fontSize: 12),
                        ),
                      );
                    }).toList(),
                  )
                : Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: statusColor.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      statusText,
                      style: TextStyle(
                        color: statusColor,
                        fontSize: 12,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
          ),
        ],
      ),
    );
  }

  Widget _buildMaterialsTab() {
    return Column(
      children: [
        _buildMaterialsHeader(),
        Expanded(
          child: _materials.isEmpty
              ? _buildEmptyState('No materials uploaded yet', Icons.folder_open)
              : ListView.builder(
                  itemCount: _materials.length,
                  itemBuilder: (context, index) {
                    final material = _materials[index];
                    return _buildMaterialRow(material);
                  },
                ),
        ),
        Padding(
          padding: const EdgeInsets.all(16),
          child: ElevatedButton.icon(
            onPressed: () => _uploadMaterial(),
            icon: const Icon(Icons.upload_file),
            label: const Text('Upload Material'),
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF667eea),
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildMaterialsHeader() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
      color: widget.isDarkMode ? const Color(0xFF22223b) : const Color(0xFFf0f4f8),
      child: Row(
        children: [
          Expanded(
            flex: 4,
            child: Text(
              'Title',
              style: TextStyle(
                color: textColor,
                fontSize: 14,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          Expanded(
            flex: 2,
            child: Text(
              'Type',
              style: TextStyle(
                color: textColor,
                fontSize: 14,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          Expanded(
            flex: 2,
            child: Text(
              'Size',
              style: TextStyle(
                color: textColor,
                fontSize: 14,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          Expanded(
            flex: 2,
            child: Text(
              'Date',
              style: TextStyle(
                color: textColor,
                fontSize: 14,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          const SizedBox(width: 40),
        ],
      ),
    );
  }

  Widget _buildMaterialRow(CourseMaterial material) {
    IconData typeIcon;
    Color typeColor;
    
    switch (material.type) {
      case MaterialType.pdf:
        typeIcon = Icons.picture_as_pdf;
        typeColor = Colors.red;
        break;
      case MaterialType.doc:
        typeIcon = Icons.description;
        typeColor = Colors.blue;
        break;
      case MaterialType.video:
        typeIcon = Icons.video_file;
        typeColor = Colors.purple;
        break;
      case MaterialType.image:
        typeIcon = Icons.image;
        typeColor = Colors.green;
        break;
    }
    
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        border: Border(
          bottom: BorderSide(
            color: subtitleColor.withOpacity(0.2),
            width: 1,
          ),
        ),
      ),
      child: Row(
        children: [
          Expanded(
            flex: 4,
            child: Row(
              children: [
                Icon(typeIcon, color: typeColor, size: 20),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    material.title,
                    style: TextStyle(
                      color: textColor,
                      fontSize: 14,
                    ),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            flex: 2,
            child: Text(
              material.type.toString().split('.').last.toUpperCase(),
              style: TextStyle(
                color: subtitleColor,
                fontSize: 14,
              ),
            ),
          ),
          Expanded(
            flex: 2,
            child: Text(
              material.fileSize,
              style: TextStyle(
                color: subtitleColor,
                fontSize: 14,
              ),
            ),
          ),
          Expanded(
            flex: 2,
            child: Text(
              DateFormat('dd/MM/yy').format(material.uploadDate),
              style: TextStyle(
                color: subtitleColor,
                fontSize: 14,
              ),
            ),
          ),
          PopupMenuButton<String>(
            onSelected: (value) {
              if (value == 'download') {
                _downloadMaterial(material);
              } else if (value == 'delete') {
                _deleteMaterial(material.id);
              }
            },
            itemBuilder: (context) => [
              const PopupMenuItem(
                value: 'download',
                child: Row(
                  children: [
                    Icon(Icons.download, size: 18),
                    SizedBox(width: 8),
                    Text('Download'),
                  ],
                ),
              ),
              const PopupMenuItem(
                value: 'delete',
                child: Row(
                  children: [
                    Icon(Icons.delete, size: 18, color: Colors.red),
                    SizedBox(width: 8),
                    Text('Delete', style: TextStyle(color: Colors.red)),
                  ],
                ),
              ),
            ],
            icon: Icon(Icons.more_vert, color: subtitleColor),
          ),
        ],
      ),
    );
  }

  Widget _buildComplaintsTab() {
    return Column(
      children: [
        _buildComplaintsHeader(),
        Expanded(
          child: _complaints.isEmpty
              ? _buildEmptyState('No complaints yet', Icons.feedback_outlined)
              : ListView.builder(
                  itemCount: _complaints.length,
                  itemBuilder: (context, index) {
                    final complaint = _complaints[index];
                    return _buildComplaintCard(complaint);
                  },
                ),
        ),
      ],
    );
  }

  Widget _buildComplaintsHeader() {
    return Container(
      padding: const EdgeInsets.all(16),
      color: widget.isDarkMode ? const Color(0xFF22223b) : const Color(0xFFf0f4f8),
      child: Row(
        children: [
          Text(
            'Student Complaints',
            style: TextStyle(
              color: textColor,
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
          const Spacer(),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: const Color(0xFF667eea).withOpacity(0.1),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Text(
              '${_complaints.length} Total',
              style: const TextStyle(
                color: Color(0xFF667eea),
                fontSize: 12,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildComplaintCard(StudentComplaint complaint) {
    Color statusColor;
    String statusText;
    
    switch (complaint.status) {
      case ComplaintStatus.pending:
        statusColor = Colors.orange;
        statusText = 'Pending';
        break;
      case ComplaintStatus.inProgress:
        statusColor = Colors.blue;
        statusText = 'In Progress';
        break;
      case ComplaintStatus.resolved:
        statusColor = Colors.green;
        statusText = 'Resolved';
        break;
    }
    
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: cardColor,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: statusColor.withOpacity(0.3),
          width: 1,
        ),
        boxShadow: widget.isDarkMode ? [] : [
          BoxShadow(
            color: Colors.black.withOpacity(0.06),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      complaint.title,
                      style: TextStyle(
                        color: textColor,
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '${complaint.studentName} (${complaint.studentId})',
                      style: TextStyle(
                        color: subtitleColor,
                        fontSize: 14,
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: statusColor.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  statusText,
                  style: TextStyle(
                    color: statusColor,
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            complaint.description,
            style: TextStyle(
              color: textColor,
              fontSize: 14,
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Icon(Icons.access_time, color: subtitleColor, size: 16),
              const SizedBox(width: 4),
              Text(
                DateFormat('dd/MM/yyyy HH:mm').format(complaint.date),
                style: TextStyle(
                  color: subtitleColor,
                  fontSize: 12,
                ),
              ),
              const Spacer(),
              if (complaint.status != ComplaintStatus.resolved)
                TextButton(
                  onPressed: () => _updateComplaintStatus(complaint),
                  child: const Text('Update Status'),
                ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildAssignmentsTab() {
    return Column(
      children: [
        _buildAssignmentsHeader(),
        Expanded(
          child: _assignments.isEmpty
              ? _buildEmptyState('No assignments submitted yet', Icons.assignment)
              : ListView.builder(
                  itemCount: _assignments.length,
                  itemBuilder: (context, index) {
                    final assignment = _assignments[index];
                    return _buildAssignmentCard(assignment);
                  },
                ),
        ),
      ],
    );
  }

  Widget _buildAssignmentsHeader() {
    return Container(
      padding: const EdgeInsets.all(16),
      color: widget.isDarkMode ? const Color(0xFF22223b) : const Color(0xFFf0f4f8),
      child: Row(
        children: [
          Text(
            'Student Assignments',
            style: TextStyle(
              color: textColor,
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
          const Spacer(),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: const Color(0xFF667eea).withOpacity(0.1),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Text(
              '${_assignments.length} Submitted',
              style: const TextStyle(
                color: Color(0xFF667eea),
                fontSize: 12,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAssignmentCard(StudentAssignment assignment) {
    double percentage = (assignment.score / assignment.maxScore) * 100;
    Color gradeColor;
    
    if (percentage >= 80) {
      gradeColor = Colors.green;
    } else if (percentage >= 60) {
      gradeColor = Colors.orange;
    } else {
      gradeColor = Colors.red;
    }
    
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: cardColor,
        borderRadius: BorderRadius.circular(12),
        boxShadow: widget.isDarkMode ? [] : [
          BoxShadow(
            color: Colors.black.withOpacity(0.06),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      assignment.title,
                      style: TextStyle(
                        color: textColor,
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '${assignment.studentName} (${assignment.studentId})',
                      style: TextStyle(
                        color: subtitleColor,
                        fontSize: 14,
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: gradeColor.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  '${assignment.score}/${assignment.maxScore}',
                  style: TextStyle(
                    color: gradeColor,
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Icon(Icons.access_time, color: subtitleColor, size: 16),
              const SizedBox(width: 4),
              Text(
                'Submitted: ${DateFormat('dd/MM/yyyy HH:mm').format(assignment.submissionDate)}',
                style: TextStyle(
                  color: subtitleColor,
                  fontSize: 12,
                ),
              ),
              const Spacer(),
              TextButton.icon(
                onPressed: () => _viewAssignment(assignment),
                icon: const Icon(Icons.visibility, size: 16),
                label: const Text('View'),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildSectionHeader(String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Row(
        children: [
          Text(
            title,
            style: TextStyle(
              color: textColor,
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          const Spacer(),
        ],
      ),
    );
  }

  Widget _buildEmptyState(String message, IconData icon) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            icon,
            size: 64,
            color: subtitleColor.withOpacity(0.5),
          ),
          const SizedBox(height: 16),
          Text(
            message,
            style: TextStyle(
              color: subtitleColor,
              fontSize: 16,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBottomNavBar() {
    return Container(
      decoration: BoxDecoration(
        color: cardColor,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 8,
            offset: const Offset(0, -2),
          ),
        ],
      ),
      child: BottomNavigationBar(
        currentIndex: _selectedBottomIndex,
        onTap: (index) {
          setState(() => _selectedBottomIndex = index);
          HapticFeedback.lightImpact();
          
          // Navigate based on selection
          switch (index) {
            case 0:
              Navigator.pushReplacementNamed(context, '/dashboard');
              break;
            case 1:
              Navigator.pop(context);
              break;
            case 2:
              Navigator.pushReplacementNamed(context, '/reports');
              break;
            case 3:
              Navigator.pushReplacementNamed(context, '/profile');
              break;
          }
        },
        type: BottomNavigationBarType.fixed,
        backgroundColor: Colors.transparent,
        elevation: 0,
        selectedItemColor: const Color(0xFF667eea),
        unselectedItemColor: subtitleColor,
        selectedLabelStyle: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600),
        unselectedLabelStyle: const TextStyle(fontSize: 12),
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.dashboard),
            label: 'Dashboard',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.school),
            label: 'Courses',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.analytics),
            label: 'Reports',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'Profile',
          ),
        ],
      ),
    );
  }

  // Helper methods
  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate ?? DateTime.now(),
      firstDate: DateTime.now().subtract(const Duration(days: 365)),
      lastDate: DateTime.now(),
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: ColorScheme.light(
              primary: const Color(0xFF667eea),
              onPrimary: Colors.white,
              surface: cardColor,
              onSurface: textColor,
            ),
          ),
          child: child!,
        );
      },
    );
    
    if (picked != null && picked != _selectedDate) {
      setState(() {
        _selectedDate = picked;
      });
    }
  }

  void _createAnnouncement() {
    showDialog(
      context: context,
      builder: (context) => CreateAnnouncementDialog(
        courseCode: widget.course.code,
        isDarkMode: widget.isDarkMode,
        onSave: (announcement) {
          setState(() {
            _announcements.insert(0, announcement);
          });
          _showSnackBar('Announcement created successfully');
        },
      ),
    );
  }

  void _editAnnouncement(Announcement announcement) {
    showDialog(
      context: context,
      builder: (context) => CreateAnnouncementDialog(
        courseCode: widget.course.code,
        isDarkMode: widget.isDarkMode,
        announcement: announcement,
        onSave: (updatedAnnouncement) {
          setState(() {
            final index = _announcements.indexWhere((a) => a.id == announcement.id);
            if (index != -1) {
              _announcements[index] = updatedAnnouncement;
            }
          });
          _showSnackBar('Announcement updated successfully');
        },
      ),
    );
  }

  void _deleteAnnouncement(String id) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: cardColor,
        title: Text('Delete Announcement', style: TextStyle(color: textColor)),
        content: Text('Are you sure you want to delete this announcement?', style: TextStyle(color: textColor)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              setState(() {
                _announcements.removeWhere((a) => a.id == id);
              });
              Navigator.pop(context);
              _showSnackBar('Announcement deleted');
            },
            child: const Text('Delete', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  Future<void> _uploadMaterial() async {
    try {
      FilePickerResult? result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['pdf', 'doc', 'docx', 'ppt', 'pptx', 'mp4', 'avi', 'jpg', 'png'],
      );

      if (result != null) {
        PlatformFile file = result.files.first;
        
        // Determine material type based on extension
        MaterialType type;
        String extension = file.extension?.toLowerCase() ?? '';
        
        if (['pdf'].contains(extension)) {
          type = MaterialType.pdf;
        } else if (['doc', 'docx', 'ppt', 'pptx'].contains(extension)) {
          type = MaterialType.doc;
        } else if (['mp4', 'avi'].contains(extension)) {
          type = MaterialType.video;
        } else {
          type = MaterialType.image;
        }
        
        // Create new material
        final newMaterial = CourseMaterial(
          id: DateTime.now().millisecondsSinceEpoch.toString(),
          title: file.name,
          type: type,
          uploadDate: DateTime.now(),
          fileSize: _formatFileSize(file.size),
          downloadCount: 0,
        );
        
        setState(() {
          _materials.insert(0, newMaterial);
        });
        
        _showSnackBar('Material uploaded successfully');
      }
    } catch (e) {
      _showSnackBar('Error uploading file: $e');
    }
  }

  String _formatFileSize(int bytes) {
    if (bytes < 1024) return '$bytes B';
    if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(1)} KB';
    return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
  }

  void _downloadMaterial(CourseMaterial material) {
    setState(() {
      material.downloadCount++;
    });
    _showSnackBar('${material.title} downloaded');
  }

  void _deleteMaterial(String id) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: cardColor,
        title: Text('Delete Material', style: TextStyle(color: textColor)),
        content: Text('Are you sure you want to delete this material?', style: TextStyle(color: textColor)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              setState(() {
                _materials.removeWhere((m) => m.id == id);
              });
              Navigator.pop(context);
              _showSnackBar('Material deleted');
            },
            child: const Text('Delete', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  void _updateComplaintStatus(StudentComplaint complaint) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: cardColor,
        title: Text('Update Complaint Status', style: TextStyle(color: textColor)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: ComplaintStatus.values.map((status) {
            return RadioListTile<ComplaintStatus>(
              title: Text(_getComplaintStatusText(status), style: TextStyle(color: textColor)),
              value: status,
              groupValue: complaint.status,
              onChanged: (value) {
                if (value != null) {
                  setState(() {
                    complaint.status = value;
                  });
                  Navigator.pop(context);
                  _showSnackBar('Complaint status updated');
                }
              },
            );
          }).toList(),
        ),
      ),
    );
  }

  String _getComplaintStatusText(ComplaintStatus status) {
    switch (status) {
      case ComplaintStatus.pending:
        return 'Pending';
      case ComplaintStatus.inProgress:
        return 'In Progress';
      case ComplaintStatus.resolved:
        return 'Resolved';
    }
  }

  void _viewAssignment(StudentAssignment assignment) {
    _showSnackBar('Opening ${assignment.title} by ${assignment.studentName}');
  }

  IconData _getAnnouncementIcon(AnnouncementType type) {
    switch (type) {
      case AnnouncementType.classCancelled:
        return Icons.cancel;
      case AnnouncementType.reminder:
        return Icons.notifications;
      case AnnouncementType.courseMaterial:
        return Icons.folder;
      case AnnouncementType.general:
        return Icons.announcement;
    }
  }

  Color _getAnnouncementColor(AnnouncementType type) {
    switch (type) {
      case AnnouncementType.classCancelled:
        return Colors.red;
      case AnnouncementType.reminder:
        return Colors.orange;
      case AnnouncementType.courseMaterial:
        return Colors.blue;
      case AnnouncementType.general:
        return Colors.green;
    }
  }

  String _formatDateTime(DateTime dateTime) {
    final now = DateTime.now();
    final difference = now.difference(dateTime);
    
    if (difference.inDays > 0) {
      return '${difference.inDays} day${difference.inDays == 1 ? '' : 's'} ago';
    } else if (difference.inHours > 0) {
      return '${difference.inHours} hour${difference.inHours == 1 ? '' : 's'} ago';
    } else if (difference.inMinutes > 0) {
      return '${difference.inMinutes} minute${difference.inMinutes == 1 ? '' : 's'} ago';
    } else {
      return 'Just now';
    }
  }

  void _showSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: const Color(0xFF667eea),
        duration: const Duration(seconds: 2),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }
}

// Data Models
class AttendanceRecord {
  final String id;
  final String studentName;
  final String studentId;
  final DateTime date;
  AttendanceStatus status;
  String arrivalTime;

  AttendanceRecord({
    required this.id,
    required this.studentName,
    required this.studentId,
    required this.date,
    required this.status,
    required this.arrivalTime,
  });
}

enum AttendanceStatus { present, late, absent }

class CourseMaterial {
  final String id;
  final String title;
  final MaterialType type;
  final DateTime uploadDate;
  final String fileSize;
  int downloadCount;

  CourseMaterial({
    required this.id,
    required this.title,
    required this.type,
    required this.uploadDate,
    required this.fileSize,
    required this.downloadCount,
  });
}

enum MaterialType { pdf, doc, video, image }

class StudentComplaint {
  final String id;
  final String studentName;
  final String studentId;
  final DateTime date;
  final String title;
  final String description;
  ComplaintStatus status;

  StudentComplaint({
    required this.id,
    required this.studentName,
    required this.studentId,
    required this.date,
    required this.title,
    required this.description,
    required this.status,
  });
}

enum ComplaintStatus { pending, inProgress, resolved }

class StudentAssignment {
  final String id;
  final String studentName;
  final String studentId;
  final String title;
  final DateTime submissionDate;
  final int score;
  final int maxScore;

  StudentAssignment({
    required this.id,
    required this.studentName,
    required this.studentId,
    required this.title,
    required this.submissionDate,
    required this.score,
    required this.maxScore,
  });
}

// Create Announcement Dialog
class CreateAnnouncementDialog extends StatefulWidget {
  final String courseCode;
  final bool isDarkMode;
  final Announcement? announcement;
  final Function(Announcement) onSave;

  const CreateAnnouncementDialog({
    Key? key,
    required this.courseCode,
    required this.isDarkMode,
    this.announcement,
    required this.onSave,
  }) : super(key: key);

  @override
  _CreateAnnouncementDialogState createState() => _CreateAnnouncementDialogState();
}

class _CreateAnnouncementDialogState extends State<CreateAnnouncementDialog> {
  final _titleController = TextEditingController();
  final _messageController = TextEditingController();
  AnnouncementType _selectedType = AnnouncementType.general;

  @override
  void initState() {
    super.initState();
    if (widget.announcement != null) {
      _titleController.text = widget.announcement!.title;
      _messageController.text = widget.announcement!.message;
      _selectedType = widget.announcement!.type;
    }
  }

  @override
  Widget build(BuildContext context) {
    Color cardColor = widget.isDarkMode ? const Color(0xFF2d2d42) : Colors.white;
    Color textColor = widget.isDarkMode ? Colors.white : const Color(0xFF2D3748);
    Color subtitleColor = widget.isDarkMode ? Colors.grey[400]! : const Color(0xFF718096);

    return AlertDialog(
      backgroundColor: cardColor,
      title: Text(
        widget.announcement == null ? 'Create Announcement' : 'Edit Announcement',
        style: TextStyle(color: textColor),
      ),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: _titleController,
              style: TextStyle(color: textColor),
              decoration: InputDecoration(
                labelText: 'Title',
                labelStyle: TextStyle(color: subtitleColor),
                border: OutlineInputBorder(),
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: subtitleColor.withOpacity(0.3)),
                ),
                focusedBorder: const OutlineInputBorder(
                  borderSide: BorderSide(color: Color(0xFF667eea)),
                ),
              ),
            ),
            const SizedBox(height: 16),
            DropdownButtonFormField<AnnouncementType>(
              value: _selectedType,
              style: TextStyle(color: textColor),
              dropdownColor: cardColor,
              decoration: InputDecoration(
                labelText: 'Type',
                labelStyle: TextStyle(color: subtitleColor),
                border: OutlineInputBorder(),
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: subtitleColor.withOpacity(0.3)),
                ),
                focusedBorder: const OutlineInputBorder(
                  borderSide: BorderSide(color: Color(0xFF667eea)),
                ),
              ),
              items: AnnouncementType.values.map((type) {
                return DropdownMenuItem(
                  value: type,
                  child: Text(_getTypeDisplayName(type)),
                );
              }).toList(),
              onChanged: (value) {
                if (value != null) {
                  setState(() => _selectedType = value);
                }
              },
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _messageController,
              style: TextStyle(color: textColor),
              maxLines: 4,
              decoration: InputDecoration(
                labelText: 'Message',
                labelStyle: TextStyle(color: subtitleColor),
                border: OutlineInputBorder(),
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: subtitleColor.withOpacity(0.3)),
                ),
                focusedBorder: const OutlineInputBorder(
                  borderSide: BorderSide(color: Color(0xFF667eea)),
                ),
              ),
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Cancel'),
        ),
        ElevatedButton(
          onPressed: () {
            if (_titleController.text.isNotEmpty && _messageController.text.isNotEmpty) {
              final announcement = Announcement(
                id: widget.announcement?.id ?? DateTime.now().millisecondsSinceEpoch.toString(),
                title: _titleController.text,
                message: _messageController.text,
                courseCode: widget.courseCode,
                timestamp: DateTime.now(),
                type: _selectedType,
              );
              widget.onSave(announcement);
              Navigator.pop(context);
            }
          },
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xFF667eea),
            foregroundColor: Colors.white,
          ),
          child: Text(widget.announcement == null ? 'Create' : 'Update'),
        ),
      ],
    );
  }

  String _getTypeDisplayName(AnnouncementType type) {
    switch (type) {
      case AnnouncementType.classCancelled:
        return 'Class Cancelled';
      case AnnouncementType.reminder:
        return 'Reminder';
      case AnnouncementType.courseMaterial:
        return 'Course Material';
      case AnnouncementType.general:
        return 'General';
    }
  }
}
