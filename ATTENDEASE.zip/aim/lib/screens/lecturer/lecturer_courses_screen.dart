import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'lecturer_dashboard.dart';
import 'course_management_screen.dart';
import 'announcements_screen.dart';
import 'realtime_attendance_screen.dart';
import '../../models/announcement.dart';

class LecturerCoursesScreen extends StatefulWidget {
  final List<LecturerCourse> courses;
  final bool isDarkMode;

  const LecturerCoursesScreen({
    Key? key,
    required this.courses,
    required this.isDarkMode,
  }) : super(key: key);

  @override
  _LecturerCoursesScreenState createState() => _LecturerCoursesScreenState();
}

class _LecturerCoursesScreenState extends State<LecturerCoursesScreen> {
  String _searchQuery = '';
  String? _selectedLevel;
  String? _selectedDepartment;
  bool _showActiveOnly = false;

  final List<String> _levels = ['Level 100', 'Level 200', 'Level 300', 'Level 400'];
  final List<String> _departments = ['Computer Science', 'Information Technology', 'Software Engineering'];

  // Recent announcements from all courses
  final List<Announcement> _recentAnnouncements = [
    Announcement(
      id: '1',
      title: 'Class Cancelled - Software Engineering',
      message: 'Tomorrow\'s Software Engineering class is cancelled due to a faculty meeting.',
      courseCode: 'CS301',
      timestamp: DateTime.now().subtract(Duration(hours: 2)),
      type: AnnouncementType.classCancelled,
    ),
    Announcement(
      id: '2',
      title: 'Assignment Due Reminder - Database Systems',
      message: 'Database Systems assignment is due this Friday. Please submit on time.',
      courseCode: 'CS302',
      timestamp: DateTime.now().subtract(Duration(days: 1)),
      type: AnnouncementType.reminder,
    ),
    Announcement(
      id: '3',
      title: 'New Course Material - Data Structures',
      message: 'New lecture notes for Chapter 5 have been uploaded.',
      courseCode: 'CS201',
      timestamp: DateTime.now().subtract(Duration(days: 2)),
      type: AnnouncementType.courseMaterial,
    ),
  ];

  Color get backgroundColor => widget.isDarkMode ? const Color(0xFF1a1a2e) : const Color(0xFFF8F9FA);
  Color get cardColor => widget.isDarkMode ? const Color(0xFF2d2d42) : Colors.white;
  Color get textColor => widget.isDarkMode ? Colors.white : const Color(0xFF2D3748);
  Color get subtitleColor => widget.isDarkMode ? Colors.grey[400]! : const Color(0xFF718096);

  LinearGradient get primaryGradient => const LinearGradient(
    colors: [Color(0xFF667eea), Color(0xFF764ba2)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  List<LecturerCourse> get filteredCourses {
    return widget.courses.where((course) {
      // Search filter
      if (_searchQuery.isNotEmpty) {
        bool matchesSearch = course.name.toLowerCase().contains(_searchQuery.toLowerCase()) ||
            course.code.toLowerCase().contains(_searchQuery.toLowerCase());
        if (!matchesSearch) return false;
      }

      // Active filter
      if (_showActiveOnly && !course.isActive) return false;

      // Level filter
      if (_selectedLevel != null) {
        if (!course.level.contains(_selectedLevel!)) return false;
      }

      // Department filter
      if (_selectedDepartment != null) {
        if (!course.level.contains(_selectedDepartment!)) return false;
      }

      return true;
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: backgroundColor,
      body: SafeArea(
        child: Column(
          children: [
            _buildHeader(),
            _buildFilters(),
            Expanded(
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    _buildAnnouncementsSection(),
                    const SizedBox(height: 16),
                    filteredCourses.isEmpty
                        ? _buildEmptyState()
                        : _buildCoursesList(),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        gradient: primaryGradient,
      ),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                // Attendease Logo
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(20),
                    child: Image.asset(
                      'assets/images/attendease_logo.png',
                      fit: BoxFit.cover,
                      errorBuilder: (context, error, stackTrace) {
                        return Container(
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [Colors.purple, Colors.teal],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: const Center(
                            child: Text(
                              'A',
                              style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 20,
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'My Courses',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        '${widget.courses.length} courses assigned',
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.9),
                          fontSize: 14,
                        ),
                      ),
                    ],
                  ),
                ),
                IconButton(
                  onPressed: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => AnnouncementsScreen(
                        isDarkMode: widget.isDarkMode,
                      ),
                    ),
                  ),
                  icon: const Icon(Icons.campaign, color: Colors.white),
                ),
              ],
            ),
            const SizedBox(height: 16),
            // Search Bar
            Container(
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.2),
                borderRadius: BorderRadius.circular(12),
              ),
              child: TextField(
                style: const TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  hintText: 'Search courses...',
                  hintStyle: TextStyle(color: Colors.white.withOpacity(0.7)),
                  prefixIcon: Icon(Icons.search, color: Colors.white.withOpacity(0.7)),
                  border: InputBorder.none,
                  contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                ),
                onChanged: (value) {
                  setState(() => _searchQuery = value);
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFilters() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: cardColor,
        boxShadow: widget.isDarkMode ? [] : [
          BoxShadow(
            color: Colors.black.withOpacity(0.06),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: DropdownButton<String>(
                  value: _selectedLevel,
                  hint: Text('All Levels', style: TextStyle(color: subtitleColor)),
                  style: TextStyle(color: textColor),
                  dropdownColor: cardColor,
                  underline: Container(),
                  icon: Icon(Icons.arrow_drop_down, color: subtitleColor),
                  items: [null, ..._levels].map((level) {
                    return DropdownMenuItem(
                      value: level,
                      child: Text(level ?? 'All Levels'),
                    );
                  }).toList(),
                  onChanged: (value) {
                    setState(() => _selectedLevel = value);
                  },
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: DropdownButton<String>(
                  value: _selectedDepartment,
                  hint: Text('All Departments', style: TextStyle(color: subtitleColor)),
                  style: TextStyle(color: textColor),
                  dropdownColor: cardColor,
                  underline: Container(),
                  icon: Icon(Icons.arrow_drop_down, color: subtitleColor),
                  items: [null, ..._departments].map((dept) {
                    return DropdownMenuItem(
                      value: dept,
                      child: Text(dept ?? 'All Departments'),
                    );
                  }).toList(),
                  onChanged: (value) {
                    setState(() => _selectedDepartment = value);
                  },
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Text(
                '${filteredCourses.length} courses found',
                style: TextStyle(color: subtitleColor, fontSize: 12),
              ),
              const Spacer(),
              Row(
                children: [
                  Text(
                    'Active Only',
                    style: TextStyle(color: textColor, fontSize: 14),
                  ),
                  const SizedBox(width: 8),
                  Switch(
                    value: _showActiveOnly,
                    onChanged: (value) {
                      setState(() => _showActiveOnly = value);
                      HapticFeedback.lightImpact();
                    },
                    activeColor: Colors.white,
                    activeTrackColor: const Color(0xFF667eea),
                  ),
                ],
              ),
              const SizedBox(width: 16),
              OutlinedButton.icon(
                onPressed: () {
                  setState(() {
                    _selectedLevel = null;
                    _selectedDepartment = null;
                    _showActiveOnly = false;
                    _searchQuery = '';
                  });
                },
                icon: Icon(Icons.filter_alt_off, size: 16),
                label: const Text('Clear'),
                style: OutlinedButton.styleFrom(
                  foregroundColor: subtitleColor,
                  side: BorderSide(color: subtitleColor.withOpacity(0.5)),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildAnnouncementsSection() {
    return Container(
      margin: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(
                'Recent Announcements',
                style: TextStyle(
                  color: textColor,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const Spacer(),
              TextButton(
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => AnnouncementsScreen(
                      isDarkMode: widget.isDarkMode,
                    ),
                  ),
                ),
                child: const Text('View All'),
              ),
            ],
          ),
          const SizedBox(height: 12),
          if (_recentAnnouncements.isEmpty)
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: cardColor,
                borderRadius: BorderRadius.circular(12),
                boxShadow: widget.isDarkMode ? [] : [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.06),
                    blurRadius: 8,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: Center(
                child: Column(
                  children: [
                    Icon(Icons.announcement, color: subtitleColor, size: 32),
                    const SizedBox(height: 8),
                    Text(
                      'No recent announcements',
                      style: TextStyle(color: subtitleColor),
                    ),
                  ],
                ),
              ),
            )
          else
            ..._recentAnnouncements.take(3).map((announcement) => _buildAnnouncementCard(announcement)),
        ],
      ),
    );
  }

  Widget _buildAnnouncementCard(Announcement announcement) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: cardColor,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: _getAnnouncementColor(announcement.type).withOpacity(0.3),
          width: 1,
        ),
        boxShadow: widget.isDarkMode ? [] : [
          BoxShadow(
            color: Colors.black.withOpacity(0.06),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: _getAnnouncementColor(announcement.type).withOpacity(0.1),
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Icon(
                  _getAnnouncementIcon(announcement.type),
                  color: _getAnnouncementColor(announcement.type),
                  size: 14,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  announcement.title,
                  style: TextStyle(
                    color: textColor,
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: const Color(0xFF667eea).withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  announcement.courseCode,
                  style: const TextStyle(
                    color: Color(0xFF667eea),
                    fontSize: 10,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            announcement.message,
            style: TextStyle(
              color: subtitleColor,
              fontSize: 12,
            ),
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
          ),
          const SizedBox(height: 8),
          Text(
            _formatTimestamp(announcement.timestamp),
            style: TextStyle(
              color: subtitleColor.withOpacity(0.7),
              fontSize: 10,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCoursesList() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'All Courses',
            style: TextStyle(
              color: textColor,
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 16),
          ...filteredCourses.map((course) => _buildCourseCard(course)),
        ],
      ),
    );
  }

  Widget _buildCourseCard(LecturerCourse course) {
    return GestureDetector(
      onTap: () => _navigateToCourseManagement(course),
      child: Container(
        margin: const EdgeInsets.only(bottom: 16),
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: cardColor,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: course.isActive 
                ? const Color(0xFF667eea).withOpacity(0.3)
                : subtitleColor.withOpacity(0.2),
            width: 1,
          ),
          boxShadow: widget.isDarkMode ? [] : [
            BoxShadow(
              color: Colors.black.withOpacity(0.06),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: const Color(0xFF667eea).withOpacity(0.1),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    course.code,
                    style: const TextStyle(
                      color: Color(0xFF667eea),
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
                const Spacer(),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: course.isActive 
                        ? Colors.green.withOpacity(0.1)
                        : Colors.red.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    course.isActive ? 'ACTIVE' : 'INACTIVE',
                    style: TextStyle(
                      color: course.isActive ? Colors.green : Colors.red,
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Switch(
                  value: course.isActive,
                  onChanged: (value) {
                    setState(() {
                      course.isActive = value;
                    });
                    HapticFeedback.lightImpact();
                  },
                  activeColor: Colors.white,
                  activeTrackColor: const Color(0xFF667eea),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Text(
              course.name,
              style: TextStyle(
                color: textColor,
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              course.level,
              style: TextStyle(
                color: subtitleColor,
                fontSize: 14,
              ),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                _buildCourseInfo(Icons.people, '${course.studentCount} Students'),
                const SizedBox(width: 24),
                _buildCourseInfo(Icons.calendar_today, '24 Sessions'),
                const SizedBox(width: 24),
                _buildCourseInfo(Icons.assignment, '87% Attendance'),
              ],
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: course.isActive ? () => _startSession(course) : null,
                    icon: const Icon(Icons.play_arrow, size: 16),
                    label: const Text('Start Session'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF4CAF50),
                      foregroundColor: Colors.white,
                      disabledBackgroundColor: subtitleColor.withOpacity(0.3),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                      padding: const EdgeInsets.symmetric(vertical: 12),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => _navigateToCourseManagement(course),
                    icon: const Icon(Icons.settings, size: 16),
                    label: const Text('Manage'),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: const Color(0xFF667eea),
                      side: const BorderSide(color: Color(0xFF667eea)),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                      padding: const EdgeInsets.symmetric(vertical: 12),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCourseInfo(IconData icon, String text) {
    return Row(
      children: [
        Icon(icon, color: subtitleColor, size: 16),
        const SizedBox(width: 4),
        Text(
          text,
          style: TextStyle(
            color: subtitleColor,
            fontSize: 12,
          ),
        ),
      ],
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.school_outlined,
              size: 64,
              color: subtitleColor.withOpacity(0.5),
            ),
            const SizedBox(height: 16),
            Text(
              'No courses found',
              style: TextStyle(
                color: subtitleColor,
                fontSize: 18,
                fontWeight: FontWeight.w500,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Try adjusting your filters or search query',
              style: TextStyle(
                color: subtitleColor,
                fontSize: 14,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Helper methods
  IconData _getAnnouncementIcon(AnnouncementType type) {
    switch (type) {
      case AnnouncementType.classCancelled:
        return Icons.cancel;
      case AnnouncementType.reminder:
        return Icons.notifications;
      case AnnouncementType.courseMaterial:
        return Icons.folder;
      case AnnouncementType.general:
        return Icons.announcement;
    }
  }

  Color _getAnnouncementColor(AnnouncementType type) {
    switch (type) {
      case AnnouncementType.classCancelled:
        return Colors.red;
      case AnnouncementType.reminder:
        return Colors.orange;
      case AnnouncementType.courseMaterial:
        return Colors.blue;
      case AnnouncementType.general:
        return Colors.green;
    }
  }

  String _formatTimestamp(DateTime timestamp) {
    final now = DateTime.now();
    final difference = now.difference(timestamp);
    
    if (difference.inDays > 0) {
      return '${difference.inDays} day${difference.inDays == 1 ? '' : 's'} ago';
    } else if (difference.inHours > 0) {
      return '${difference.inHours} hour${difference.inHours == 1 ? '' : 's'} ago';
    } else if (difference.inMinutes > 0) {
      return '${difference.inMinutes} minute${difference.inMinutes == 1 ? '' : 's'} ago';
    } else {
      return 'Just now';
    }
  }

  void _navigateToCourseManagement(LecturerCourse course) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => CourseManagementScreen(
          course: course,
          isDarkMode: widget.isDarkMode,
        ),
      ),
    );
  }

  void _startSession(LecturerCourse course) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => RealtimeAttendanceScreen(
          course: course,
          isDarkMode: widget.isDarkMode,
        ),
      ),
    );
  }

  void _showSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: const Color(0xFF667eea),
        duration: const Duration(seconds: 2),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }
}
