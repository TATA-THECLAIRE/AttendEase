import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class LecturerSettingsScreen extends StatefulWidget {
  final bool isDarkMode;
  final Function(bool) onThemeChanged;

  const LecturerSettingsScreen({
    Key? key,
    required this.isDarkMode,
    required this.onThemeChanged,
  }) : super(key: key);

  @override
  State<LecturerSettingsScreen> createState() => _LecturerSettingsScreenState();
}

class _LecturerSettingsScreenState extends State<LecturerSettingsScreen> {
  late bool _currentDarkMode;
  String _selectedLanguage = 'English';
  String _selectedDateFormat = 'DD/MM/YYYY';
  String _selectedTimeFormat = '24 Hour';
  
  // Notification settings
  bool _pushNotifications = true;
  bool _emailNotifications = true;
  bool _attendanceAlerts = true;
  bool _assignmentReminders = true;
  bool _systemUpdates = false;
  
  // Privacy settings
  bool _biometricAuth = false;
  bool _twoFactorAuth = false;
  bool _dataCollection = true;
  bool _analyticsSharing = false;
  
  // System settings
  bool _autoBackup = true;
  bool _offlineMode = false;
  bool _dataSyncEnabled = true;

  final List<String> _languages = ['English', 'French', 'Spanish', 'German'];
  final List<String> _dateFormats = ['DD/MM/YYYY', 'MM/DD/YYYY', 'YYYY-MM-DD'];
  final List<String> _timeFormats = ['12 Hour', '24 Hour'];

  @override
  void initState() {
    super.initState();
    _currentDarkMode = widget.isDarkMode;
  }

  Color get backgroundColor => _currentDarkMode ? const Color(0xFF1a1a2e) : const Color(0xFFF8F9FA);
  Color get cardColor => _currentDarkMode ? const Color(0xFF2d2d42) : Colors.white;
  Color get textColor => _currentDarkMode ? Colors.white : const Color(0xFF2D3748);
  Color get subtitleColor => _currentDarkMode ? Colors.grey[400]! : const Color(0xFF718096);

  LinearGradient get primaryGradient => const LinearGradient(
    colors: [Color(0xFF667eea), Color(0xFF764ba2)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: backgroundColor,
      appBar: _buildAppBar(),
      body: SingleChildScrollView(
        child: Column(
          children: [
            _buildAppearanceSection(),
            _buildNotificationSection(),
            _buildPrivacySection(),
            _buildSystemSection(),
            _buildLegalSection(),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: backgroundColor,
      elevation: 0,
      leading: IconButton(
        onPressed: () => Navigator.pop(context),
        icon: Icon(Icons.arrow_back, color: textColor),
      ),
      title: Row(
        children: [
          // Attendease Logo
          Container(
            width: 30,
            height: 30,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(15),
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(15),
              child: Image.asset(
                'assets/images/attendease_logo.png',
                fit: BoxFit.cover,
                errorBuilder: (context, error, stackTrace) {
                  return Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [Colors.purple, Colors.teal],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(15),
                    ),
                    child: const Center(
                      child: Text(
                        'A',
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ),
          const SizedBox(width: 8),
          Text(
            'Settings',
            style: TextStyle(
              color: textColor,
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAppearanceSection() {
    return _buildSection(
      'Appearance',
      Icons.palette,
      [
        _buildSwitchTile(
          'Dark Mode',
          'Enable dark theme',
          _currentDarkMode,
          (value) {
            setState(() => _currentDarkMode = value);
            widget.onThemeChanged(value);
            HapticFeedback.lightImpact();
          },
        ),
        _buildDropdownTile(
          'Language',
          'Select your preferred language',
          _selectedLanguage,
          _languages,
          (value) => setState(() => _selectedLanguage = value!),
        ),
        _buildDropdownTile(
          'Date Format',
          'Choose date display format',
          _selectedDateFormat,
          _dateFormats,
          (value) => setState(() => _selectedDateFormat = value!),
        ),
        _buildDropdownTile(
          'Time Format',
          'Choose time display format',
          _selectedTimeFormat,
          _timeFormats,
          (value) => setState(() => _selectedTimeFormat = value!),
        ),
      ],
    );
  }

  Widget _buildNotificationSection() {
    return _buildSection(
      'Notifications',
      Icons.notifications,
      [
        _buildSwitchTile(
          'Push Notifications',
          'Receive push notifications on your device',
          _pushNotifications,
          (value) => setState(() => _pushNotifications = value),
        ),
        _buildSwitchTile(
          'Email Notifications',
          'Receive notifications via email',
          _emailNotifications,
          (value) => setState(() => _emailNotifications = value),
        ),
        _buildSwitchTile(
          'Attendance Alerts',
          'Get notified about attendance issues',
          _attendanceAlerts,
          (value) => setState(() => _attendanceAlerts = value),
        ),
        _buildSwitchTile(
          'Assignment Reminders',
          'Get reminded about assignment deadlines',
          _assignmentReminders,
          (value) => setState(() => _assignmentReminders = value),
        ),
        _buildSwitchTile(
          'System Updates',
          'Receive notifications about app updates',
          _systemUpdates,
          (value) => setState(() => _systemUpdates = value),
        ),
      ],
    );
  }

  Widget _buildPrivacySection() {
    return _buildSection(
      'Privacy & Security',
      Icons.security,
      [
        _buildSwitchTile(
          'Biometric Authentication',
          'Use fingerprint or face ID to unlock',
          _biometricAuth,
          (value) => setState(() => _biometricAuth = value),
        ),
        _buildSwitchTile(
          'Two-Factor Authentication',
          'Add an extra layer of security',
          _twoFactorAuth,
          (value) => setState(() => _twoFactorAuth = value),
        ),
        _buildSwitchTile(
          'Data Collection',
          'Allow collection of usage data for improvements',
          _dataCollection,
          (value) => setState(() => _dataCollection = value),
        ),
        _buildSwitchTile(
          'Analytics Sharing',
          'Share anonymous analytics data',
          _analyticsSharing,
          (value) => setState(() => _analyticsSharing = value),
        ),
        _buildActionTile(
          'Data Retention Policy',
          'View how long we keep your data',
          Icons.info_outline,
          () => _showDataRetentionDialog(),
        ),
        _buildActionTile(
          'Download My Data',
          'Export all your personal data',
          Icons.download,
          () => _exportUserData(),
        ),
        _buildActionTile(
          'Delete Account',
          'Permanently delete your account and data',
          Icons.delete_forever,
          () => _showDeleteAccountDialog(),
          isDestructive: true,
        ),
      ],
    );
  }

  Widget _buildSystemSection() {
    return _buildSection(
      'System',
      Icons.settings,
      [
        _buildSwitchTile(
          'Auto Backup',
          'Automatically backup your data',
          _autoBackup,
          (value) => setState(() => _autoBackup = value),
        ),
        _buildSwitchTile(
          'Offline Mode',
          'Enable offline functionality',
          _offlineMode,
          (value) => setState(() => _offlineMode = value),
        ),
        _buildSwitchTile(
          'Data Sync',
          'Sync data across devices',
          _dataSyncEnabled,
          (value) => setState(() => _dataSyncEnabled = value),
        ),
        _buildActionTile(
          'Clear Cache',
          'Free up storage space',
          Icons.cleaning_services,
          () => _clearCache(),
        ),
        _buildActionTile(
          'Reset Settings',
          'Reset all settings to default',
          Icons.restore,
          () => _showResetSettingsDialog(),
        ),
      ],
    );
  }

  Widget _buildLegalSection() {
    return _buildSection(
      'Legal',
      Icons.gavel,
      [
        _buildActionTile(
          'Privacy Policy',
          'Read our privacy policy',
          Icons.privacy_tip,
          () => _showPrivacyPolicy(),
        ),
        _buildActionTile(
          'Terms & Conditions',
          'View terms and conditions',
          Icons.description,
          () => _showTermsAndConditions(),
        ),
        _buildActionTile(
          'Licenses',
          'View open source licenses',
          Icons.code,
          () => _showLicenses(),
        ),
        _buildActionTile(
          'About',
          'App version and information',
          Icons.info,
          () => _showAboutDialog(),
        ),
      ],
    );
  }

  Widget _buildSection(String title, IconData icon, List<Widget> children) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: cardColor,
        borderRadius: BorderRadius.circular(16),
        boxShadow: _currentDarkMode ? [] : [
          BoxShadow(
            color: Colors.black.withOpacity(0.06),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              gradient: primaryGradient,
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(16),
                topRight: Radius.circular(16),
              ),
            ),
            child: Row(
              children: [
                Icon(icon, color: Colors.white, size: 24),
                const SizedBox(width: 12),
                Text(
                  title,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
          ...children,
        ],
      ),
    );
  }

  Widget _buildSwitchTile(String title, String subtitle, bool value, Function(bool) onChanged) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        border: Border(
          bottom: BorderSide(
            color: subtitleColor.withOpacity(0.2),
            width: 1,
          ),
        ),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    color: textColor,
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  subtitle,
                  style: TextStyle(
                    color: subtitleColor,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
          Switch(
            value: value,
            onChanged: onChanged,
            activeColor: Colors.white,
            activeTrackColor: const Color(0xFF667eea),
          ),
        ],
      ),
    );
  }

  Widget _buildDropdownTile(String title, String subtitle, String value, List<String> options, Function(String?) onChanged) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        border: Border(
          bottom: BorderSide(
            color: subtitleColor.withOpacity(0.2),
            width: 1,
          ),
        ),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    color: textColor,
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  subtitle,
                  style: TextStyle(
                    color: subtitleColor,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
          DropdownButton<String>(
            value: value,
            style: TextStyle(color: textColor),
            dropdownColor: cardColor,
            underline: Container(),
            icon: Icon(Icons.arrow_drop_down, color: subtitleColor),
            items: options.map((option) {
              return DropdownMenuItem(
                value: option,
                child: Text(option),
              );
            }).toList(),
            onChanged: onChanged,
          ),
        ],
      ),
    );
  }

  Widget _buildActionTile(String title, String subtitle, IconData icon, VoidCallback onTap, {bool isDestructive = false}) {
    return InkWell(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: BoxDecoration(
          border: Border(
            bottom: BorderSide(
              color: subtitleColor.withOpacity(0.2),
              width: 1,
            ),
          ),
        ),
        child: Row(
          children: [
            Icon(
              icon,
              color: isDestructive ? Colors.red : const Color(0xFF667eea),
              size: 24,
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                      color: isDestructive ? Colors.red : textColor,
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    subtitle,
                    style: TextStyle(
                      color: subtitleColor,
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
            ),
            Icon(
              Icons.arrow_forward_ios,
              color: subtitleColor,
              size: 16,
            ),
          ],
        ),
      ),
    );
  }

  // Action methods
  void _showDataRetentionDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: cardColor,
        title: Text('Data Retention Policy', style: TextStyle(color: textColor)),
        content: SingleChildScrollView(
          child: Text(
            'We retain your personal data for the following periods:\n\n'
            '• Account Information: Until account deletion\n'
            '• Attendance Records: 7 years for academic records\n'
            '• Course Materials: Until course completion + 2 years\n'
            '• Usage Analytics: 2 years (anonymized)\n'
            '• Support Communications: 3 years\n\n'
            'You can request deletion of your data at any time by contacting support or using the "Delete Account" option.',
            style: TextStyle(color: textColor, fontSize: 14),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }

  void _exportUserData() {
    _showSnackBar('Data export initiated. You will receive an email with your data within 24 hours.');
  }

  void _showDeleteAccountDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: cardColor,
        title: Text('Delete Account', style: TextStyle(color: Colors.red)),
        content: Text(
          'This action cannot be undone. All your data including attendance records, course materials, and account information will be permanently deleted.',
          style: TextStyle(color: textColor),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              _showSnackBar('Account deletion request submitted. Please check your email for confirmation.');
            },
            child: const Text('Delete', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  void _clearCache() {
    _showSnackBar('Cache cleared successfully');
  }

  void _showResetSettingsDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: cardColor,
        title: Text('Reset Settings', style: TextStyle(color: textColor)),
        content: Text(
          'This will reset all settings to their default values. Your data will not be affected.',
          style: TextStyle(color: textColor),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              _resetSettings();
            },
            child: const Text('Reset'),
          ),
        ],
      ),
    );
  }

  void _resetSettings() {
    setState(() {
      _selectedLanguage = 'English';
      _selectedDateFormat = 'DD/MM/YYYY';
      _selectedTimeFormat = '24 Hour';
      _pushNotifications = true;
      _emailNotifications = true;
      _attendanceAlerts = true;
      _assignmentReminders = true;
      _systemUpdates = false;
      _biometricAuth = false;
      _twoFactorAuth = false;
      _dataCollection = true;
      _analyticsSharing = false;
      _autoBackup = true;
      _offlineMode = false;
      _dataSyncEnabled = true;
    });
    _showSnackBar('Settings reset to default values');
  }

  void _showPrivacyPolicy() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: cardColor,
        title: Text('Privacy Policy', style: TextStyle(color: textColor)),
        content: SingleChildScrollView(
          child: Text(
            'ATTENDEASE PRIVACY POLICY\n\n'
            '1. INFORMATION WE COLLECT\n'
            'We collect information you provide directly to us, such as when you create an account, use our services, or contact us for support.\n\n'
            '2. HOW WE USE YOUR INFORMATION\n'
            'We use the information we collect to provide, maintain, and improve our services, process transactions, and communicate with you.\n\n'
            '3. INFORMATION SHARING\n'
            'We do not sell, trade, or otherwise transfer your personal information to third parties without your consent, except as described in this policy.\n\n'
            '4. DATA SECURITY\n'
            'We implement appropriate security measures to protect your personal information against unauthorized access, alteration, disclosure, or destruction.\n\n'
            '5. YOUR RIGHTS\n'
            'You have the right to access, update, or delete your personal information. You may also opt out of certain communications from us.\n\n'
            '6. CONTACT US\n'
            'If you have any questions about this Privacy Policy, please contact us at privacy@attendease.com',
            style: TextStyle(color: textColor, fontSize: 12),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }

  void _showTermsAndConditions() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: cardColor,
        title: Text('Terms & Conditions', style: TextStyle(color: textColor)),
        content: SingleChildScrollView(
          child: Text(
            'ATTENDEASE TERMS AND CONDITIONS\n\n'
            '1. ACCEPTANCE OF TERMS\n'
            'By accessing and using Attendease, you accept and agree to be bound by the terms and provision of this agreement.\n\n'
            '2. USE LICENSE\n'
            'Permission is granted to temporarily use Attendease for personal, non-commercial transitory viewing only.\n\n'
            '3. DISCLAIMER\n'
            'The materials on Attendease are provided on an \'as is\' basis. Attendease makes no warranties, expressed or implied.\n\n'
            '4. LIMITATIONS\n'
            'In no event shall Attendease or its suppliers be liable for any damages arising out of the use or inability to use the materials on Attendease.\n\n'
            '5. ACCURACY OF MATERIALS\n'
            'The materials appearing on Attendease could include technical, typographical, or photographic errors.\n\n'
            '6. LINKS\n'
            'Attendease has not reviewed all of the sites linked to our app and is not responsible for the contents of any such linked site.\n\n'
            '7. MODIFICATIONS\n'
            'Attendease may revise these terms of service at any time without notice.',
            style: TextStyle(color: textColor, fontSize: 12),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }

  void _showLicenses() {
    showLicensePage(
      context: context,
      applicationName: 'Attendease',
      applicationVersion: '1.0.0',
      applicationLegalese: '© 2024 Attendease. All rights reserved.',
    );
  }

  void _showAboutDialog() {
    showAboutDialog(
      context: context,
      applicationName: 'Attendease',
      applicationVersion: '1.0.0',
      applicationLegalese: '© 2024 Attendease. All rights reserved.',
      children: [
        Text(
          'Attendease is a comprehensive attendance management system designed for educational institutions.',
          style: TextStyle(color: textColor),
        ),
      ],
    );
  }

  void _showSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: const Color(0xFF667eea),
        duration: const Duration(seconds: 2),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }
}
