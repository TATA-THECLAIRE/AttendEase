import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:camera/camera.dart';
import 'package:permission_handler/permission_handler.dart';
import 'email_verification_screen.dart';

class FaceRegistrationScreen extends StatefulWidget {
  final Map<String, dynamic> userData;

  const FaceRegistrationScreen({Key? key, required this.userData}) : super(key: key);

  @override
  _FaceRegistrationScreenState createState() => _FaceRegistrationScreenState();
}

class _FaceRegistrationScreenState extends State<FaceRegistrationScreen>
    with TickerProviderStateMixin {
  bool _isLoading = false;
  bool _isCameraReady = false;
  bool _isFaceDetected = false;
  bool _permissionGranted = false;
  int _capturedImages = 0;
  final int _requiredImages = 5;
  
  late AnimationController _pulseController;
  late AnimationController _progressController;
  late Animation<double> _pulseAnimation;
  late Animation<double> _progressAnimation;

  CameraController? _cameraController;
  List<CameraDescription>? _cameras;
  
  List<String> _capturedFaceImages = [];

  @override
  void initState() {
    super.initState();
    _initializeAnimations();
    _requestCameraPermission();
  }

  void _initializeAnimations() {
    _pulseController = AnimationController(
      duration: Duration(seconds: 2),
      vsync: this,
    );
    _progressController = AnimationController(
      duration: Duration(milliseconds: 800),
      vsync: this,
    );
    
    _pulseAnimation = Tween<double>(
      begin: 1.0,
      end: 1.1,
    ).animate(CurvedAnimation(
      parent: _pulseController,
      curve: Curves.easeInOut,
    ));
    
    _progressAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _progressController,
      curve: Curves.easeInOut,
    ));

    _pulseController.repeat(reverse: true);
  }

  Future<void> _requestCameraPermission() async {
    setState(() {
      _isLoading = true;
    });

    try {
      final PermissionStatus permission = await Permission.camera.request();
      
      if (permission == PermissionStatus.granted) {
        setState(() {
          _permissionGranted = true;
        });
        await _initializeCamera();
      } else {
        setState(() {
          _isLoading = false;
          _permissionGranted = false;
        });
        
        if (permission == PermissionStatus.permanentlyDenied) {
          _showPermissionDeniedDialog();
        }
      }
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      _showErrorDialog('Failed to request camera permission: $e');
    }
  }

  Future<void> _initializeCamera() async {
    try {
      _cameras = await availableCameras();
      
      if (_cameras != null && _cameras!.isNotEmpty) {
        // Use front camera if available, otherwise use first camera
        final frontCamera = _cameras!.firstWhere(
          (camera) => camera.lensDirection == CameraLensDirection.front,
          orElse: () => _cameras!.first,
        );
        
        _cameraController = CameraController(
          frontCamera,
          ResolutionPreset.medium,
          enableAudio: false,
        );
        
        await _cameraController!.initialize();
        
        setState(() {
          _isCameraReady = true;
          _isLoading = false;
          _isFaceDetected = true; // Simulate face detection for now
        });
      } else {
        throw Exception('No cameras available');
      }
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      _showErrorDialog('Failed to initialize camera: $e');
    }
  }

  Future<void> _captureImage() async {
    if (_capturedImages >= _requiredImages || _isLoading || _cameraController == null) return;

    setState(() {
      _isLoading = true;
    });

    HapticFeedback.lightImpact();

    try {
      // Capture image
      final XFile imageFile = await _cameraController!.takePicture();
      
      // For now, just store the path - you can process the image later
      _capturedFaceImages.add(imageFile.path);
      
      setState(() {
        _capturedImages++;
        _isLoading = false;
      });

      // Animate progress
      _progressController.animateTo(_capturedImages / _requiredImages);

      // Show success feedback
      HapticFeedback.selectionClick();
      
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Image ${_capturedImages} captured successfully!'),
          backgroundColor: Colors.green,
          duration: Duration(seconds: 1),
        ),
      );

      // If we've captured all required images, complete registration
      if (_capturedImages >= _requiredImages) {
        await Future.delayed(Duration(milliseconds: 1000));
        _completeRegistration();
      }
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Failed to capture image: $e'),
          backgroundColor: Colors.orange,
          duration: Duration(seconds: 3),
        ),
      );
    }
  }

  Future<void> _completeRegistration() async {
    setState(() {
      _isLoading = true;
    });

    try {
      print('=== FACE REGISTRATION COMPLETE ===');
      print('Captured ${_capturedFaceImages.length} face images');
      print('User data: ${widget.userData}');
      
      // For now, we'll just proceed to email verification
      // You can implement face data upload to backend later
      
      // Show success message
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Row(
            children: [
              Icon(Icons.check_circle, color: Colors.white),
              SizedBox(width: 8),
              Text('Face registration completed!'),
            ],
          ),
          backgroundColor: Colors.green,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
          ),
        ),
      );

      // Navigate to email verification
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => EmailVerificationScreen(
            email: widget.userData['email'],
            role: widget.userData['role'],
          ),
        ),
      );
    } catch (e) {
      print('Face registration error: $e');
      setState(() {
        _isLoading = false;
      });
      
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Face registration failed: ${e.toString()}'),
          backgroundColor: Colors.red,
          duration: Duration(seconds: 5),
        ),
      );
    }
  }

  void _showPermissionDeniedDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Camera Permission Required'),
        content: Text(
          'Camera access is required for face registration. Please enable camera permission in your device settings.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              openAppSettings();
            },
            child: Text('Open Settings'),
          ),
        ],
      ),
    );
  }

  void _showErrorDialog(String message) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Error'),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('OK'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFF667eea),
      body: SafeArea(
        child: Column(
          children: [
            // Header
            Container(
              padding: EdgeInsets.all(20),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Container(
                      padding: EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.2),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Icon(
                        Icons.arrow_back,
                        color: Colors.white,
                        size: 20,
                      ),
                    ),
                  ),
                  Spacer(),
                  Text(
                    '${_capturedImages}/${_requiredImages}',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
            
            // Content
            Expanded(
              child: Container(
                width: double.infinity,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(30),
                    topRight: Radius.circular(30),
                  ),
                ),
                child: !_permissionGranted
                    ? _buildPermissionDeniedView()
                    : Column(
                        children: [
                          SizedBox(height: 30),
                          
                          // Title
                          Text(
                            'Face Registration',
                            style: TextStyle(
                              fontSize: 24,
                              fontWeight: FontWeight.bold,
                              color: Color(0xFF2D3436),
                            ),
                          ),
                          SizedBox(height: 10),
                          Text(
                            _capturedImages == 0
                                ? 'Position your face in the frame and stay still'
                                : _capturedImages < _requiredImages
                                    ? 'Great! Let\'s capture ${_requiredImages - _capturedImages} more angles'
                                    : 'Perfect! Processing your registration...',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: 16,
                              color: Color(0xFF636E72),
                            ),
                          ),
                          
                          SizedBox(height: 30),
                          
                          // Camera Preview
                          Expanded(
                            child: Padding(
                              padding: EdgeInsets.symmetric(horizontal: 30),
                              child: AspectRatio(
                                aspectRatio: 3/4,
                                child: AnimatedBuilder(
                                  animation: _pulseAnimation,
                                  builder: (context, child) {
                                    return Transform.scale(
                                      scale: _isFaceDetected ? _pulseAnimation.value : 1.0,
                                      child: Container(
                                        decoration: BoxDecoration(
                                          color: Color(0xFFF0F3F4),
                                          borderRadius: BorderRadius.circular(20),
                                          border: Border.all(
                                            color: _isFaceDetected 
                                                ? Colors.green 
                                                : Color(0xFF667eea).withOpacity(0.3),
                                            width: 3,
                                          ),
                                        ),
                                        child: _isCameraReady && _cameraController != null
                                            ? ClipRRect(
                                                borderRadius: BorderRadius.circular(17),
                                                child: Stack(
                                                  alignment: Alignment.center,
                                                  children: [
                                                    // Camera preview
                                                    CameraPreview(_cameraController!),
                                                    
                                                    // Face outline overlay
                                                    Container(
                                                      width: 200,
                                                      height: 250,
                                                      decoration: BoxDecoration(
                                                        border: Border.all(
                                                          color: _isFaceDetected 
                                                              ? Colors.green 
                                                              : Color(0xFF667eea),
                                                          width: 2,
                                                        ),
                                                        borderRadius: BorderRadius.circular(100),
                                                      ),
                                                    ),
                                                    
                                                    // Success checkmark
                                                    if (_capturedImages > 0)
                                                      Positioned(
                                                        top: 20,
                                                        right: 20,
                                                        child: Container(
                                                          padding: EdgeInsets.all(4),
                                                          decoration: BoxDecoration(
                                                            color: Colors.green,
                                                            shape: BoxShape.circle,
                                                          ),
                                                          child: Icon(
                                                            Icons.check,
                                                            color: Colors.white,
                                                            size: 16,
                                                          ),
                                                        ),
                                                      ),
                                                  ],
                                                ),
                                              )
                                            : Center(
                                                child: Column(
                                                  mainAxisAlignment: MainAxisAlignment.center,
                                                  children: [
                                                    CircularProgressIndicator(
                                                      color: Color(0xFF667eea),
                                                    ),
                                                    SizedBox(height: 16),
                                                    Text(
                                                      'Initializing camera...',
                                                      style: TextStyle(
                                                        color: Colors.grey[600],
                                                        fontSize: 14,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                      ),
                                    );
                                  },
                                ),
                              ),
                            ),
                          ),
                          
                          // Progress Indicator
                          Padding(
                            padding: EdgeInsets.symmetric(horizontal: 30, vertical: 20),
                            child: Column(
                              children: [
                                AnimatedBuilder(
                                  animation: _progressAnimation,
                                  builder: (context, child) {
                                    return Row(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: List.generate(
                                        _requiredImages,
                                        (index) => Container(
                                          width: 40,
                                          height: 6,
                                          margin: EdgeInsets.symmetric(horizontal: 4),
                                          decoration: BoxDecoration(
                                            color: index < _capturedImages
                                                ? Color(0xFF667eea)
                                                : Color(0xFFDFE6E9),
                                            borderRadius: BorderRadius.circular(3),
                                          ),
                                        ),
                                      ),
                                    );
                                  },
                                ),
                                SizedBox(height: 10),
                                Text(
                                  _capturedImages < _requiredImages
                                      ? 'Captured $_capturedImages of $_requiredImages'
                                      : 'All images captured successfully!',
                                  style: TextStyle(
                                    fontSize: 14,
                                    color: Color(0xFF636E72),
                                    fontWeight: _capturedImages >= _requiredImages 
                                        ? FontWeight.w600 
                                        : FontWeight.normal,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          
                          // Capture Button
                          Padding(
                            padding: EdgeInsets.only(bottom: 40, left: 30, right: 30),
                            child: SizedBox(
                              width: double.infinity,
                              height: 56,
                              child: ElevatedButton(
                                onPressed: _isLoading || !_isCameraReady || _capturedImages >= _requiredImages
                                    ? null
                                    : _captureImage,
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: Color(0xFF667eea),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(16),
                                  ),
                                  elevation: 0,
                                ),
                                child: _isLoading
                                    ? Row(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        children: [
                                          SizedBox(
                                            width: 20,
                                            height: 20,
                                            child: CircularProgressIndicator(
                                              color: Colors.white,
                                              strokeWidth: 2,
                                            ),
                                          ),
                                          SizedBox(width: 12),
                                          Text(
                                            _capturedImages >= _requiredImages
                                                ? 'Completing...'
                                                : 'Capturing...',
                                            style: TextStyle(
                                              fontSize: 18,
                                              fontWeight: FontWeight.w600,
                                              color: Colors.white,
                                            ),
                                          ),
                                        ],
                                      )
                                    : _capturedImages >= _requiredImages
                                        ? Row(
                                            mainAxisAlignment: MainAxisAlignment.center,
                                            children: [
                                              Icon(Icons.check_circle, color: Colors.white),
                                              SizedBox(width: 8),
                                              Text(
                                                'Complete Registration',
                                                style: TextStyle(
                                                  fontSize: 18,
                                                  fontWeight: FontWeight.w600,
                                                  color: Colors.white,
                                                ),
                                              ),
                                            ],
                                          )
                                        : Row(
                                            mainAxisAlignment: MainAxisAlignment.center,
                                            children: [
                                              Icon(Icons.camera_alt, color: Colors.white),
                                              SizedBox(width: 8),
                                              Text(
                                                'Capture',
                                                style: TextStyle(
                                                  fontSize: 18,
                                                  fontWeight: FontWeight.w600,
                                                  color: Colors.white,
                                                ),
                                              ),
                                            ],
                                          ),
                              ),
                            ),
                          ),
                        ],
                      ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPermissionDeniedView() {
    return Padding(
      padding: EdgeInsets.all(30),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Colors.red[50],
              shape: BoxShape.circle,
            ),
            child: Icon(
              Icons.camera_alt_outlined,
              size: 60,
              color: Colors.red[400],
            ),
          ),
          SizedBox(height: 24),
          Text(
            'Camera Permission Required',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: Color(0xFF2D3436),
            ),
          ),
          SizedBox(height: 12),
          Text(
            'To complete your registration, we need camera access to capture your face for secure attendance marking.',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 16,
              color: Color(0xFF636E72),
              height: 1.4,
            ),
          ),
          SizedBox(height: 32),
          SizedBox(
            width: double.infinity,
            height: 56,
            child: ElevatedButton.icon(
              onPressed: _requestCameraPermission,
              icon: Icon(Icons.camera_alt, color: Colors.white),
              label: Text(
                'Grant Camera Permission',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w600,
                  color: Colors.white,
                ),
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: Color(0xFF667eea),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
              ),
            ),
          ),
          SizedBox(height: 16),
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              'Skip for now',
              style: TextStyle(
                color: Colors.grey[600],
                fontSize: 16,
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _pulseController.dispose();
    _progressController.dispose();
    _cameraController?.dispose();
    super.dispose();
  }
}
