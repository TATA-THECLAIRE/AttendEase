import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../services/api_service.dart';
import 'email_verification_screen.dart';
import 'login_screen.dart';
import 'face_registration_screen.dart';

class SignupScreen extends StatefulWidget {
  final String role;

  const SignupScreen({Key? key, required this.role}) : super(key: key);

  @override
  _SignupScreenState createState() => _SignupScreenState();
}

class _SignupScreenState extends State<SignupScreen> {
  final _formKey = GlobalKey<FormState>();
  final _fullNameController = TextEditingController();
  final _emailController = TextEditingController();
  final _phoneController = TextEditingController();
  final _matriculeController = TextEditingController();
  final _lecturerIdController = TextEditingController();
  final _adminIdController = TextEditingController();
  final _employeeIdController = TextEditingController();
  final _passwordController = TextEditingController();
  final _confirmPasswordController = TextEditingController();
  
  bool _isPasswordVisible = false;
  bool _isConfirmPasswordVisible = false;
  bool _isLoading = false;
  bool _agreeToTerms = false;
  
  String? _selectedDepartment;
  String? _selectedFaculty;
  String? _selectedLevel;
  String? _selectedGender;

  final ApiService _apiService = ApiService();

  final List<String> _departments = [
    'Computer Science',
    'Software Engineering',
    'Information Technology',
    'Data Science',
    'Cybersecurity',
    'Artificial Intelligence',
    'Network Engineering',
    'Digital Marketing',
  ];

  final List<String> _faculties = [
    'Faculty of Science and Technology',
    'Faculty of Engineering',
    'Faculty of Business Administration',
    'Faculty of Arts and Humanities',
    'Faculty of Social Sciences',
    'Faculty of Medicine',
    'Faculty of Law',
    'Faculty of Education',
  ];

  final List<String> _levels = [
    'Level 100',
    'Level 200',
    'Level 300',
    'Level 400',
    'Level 500',
  ];

  final List<String> _genders = ['Male', 'Female', 'Other'];

  Color get _roleColor {
    switch (widget.role) {
      case 'student':
        return Color(0xFF667eea);
      case 'lecturer':
        return Color(0xFF28a745);
      case 'admin':
        return Color(0xFF6f42c1);
      default:
        return Color(0xFF667eea);
    }
  }

  String get _roleTitle {
    switch (widget.role) {
      case 'student':
        return 'Student Registration';
      case 'lecturer':
        return 'Lecturer Registration';
      case 'admin':
        return 'Administrator Registration';
      default:
        return 'Registration';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              _roleColor.withOpacity(0.1),
              Colors.white,
            ],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              _buildHeader(),
              Expanded(
                child: SingleChildScrollView(
                  padding: EdgeInsets.all(24.0),
                  child: Form(
                    key: _formKey,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(height: 20),
                        
                        // Welcome Section
                        Center(
                          child: Column(
                            children: [
                              Text(
                                'Create Account',
                                style: TextStyle(
                                  fontSize: 28,
                                  fontWeight: FontWeight.bold,
                                  color: _roleColor,
                                ),
                              ),
                              SizedBox(height: 8),
                              Text(
                                widget.role == 'student' 
                                    ? 'Join Attendease today and experience\nsmart attendance with face recognition'
                                    : 'Join Attendease today and experience\nsmart attendance management',
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  fontSize: 16,
                                  color: Colors.grey[600],
                                  height: 1.4,
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(height: 40),
                        
                        // Form Fields
                        _buildTextField(
                          controller: _fullNameController,
                          label: 'Full Name',
                          icon: Icons.person,
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please enter your full name';
                            }
                            if (value.length < 2) {
                              return 'Name must be at least 2 characters';
                            }
                            return null;
                          },
                        ),
                        
                        SizedBox(height: 16),
                        _buildTextField(
                          controller: _emailController,
                          label: 'Email Address',
                          icon: Icons.email,
                          keyboardType: TextInputType.emailAddress,
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please enter your email';
                            }
                            if (!RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$').hasMatch(value)) {
                              return 'Please enter a valid email';
                            }
                            return null;
                          },
                        ),
                        
                        SizedBox(height: 16),
                        _buildTextField(
                          controller: _phoneController,
                          label: 'Phone Number',
                          icon: Icons.phone,
                          keyboardType: TextInputType.phone,
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please enter your phone number';
                            }
                            if (value.length < 9) {
                              return 'Please enter a valid phone number';
                            }
                            return null;
                          },
                        ),
                        
                        SizedBox(height: 16),
                        // Role-specific fields
                        if (widget.role == 'student') ...[
                          _buildTextField(
                            controller: _matriculeController,
                            label: 'Matricule Number',
                            icon: Icons.badge,
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return 'Please enter your matricule';
                              }
                              return null;
                            },
                          ),
                          SizedBox(height: 16),
                          _buildDropdown(
                            value: _selectedDepartment,
                            label: 'Department',
                            icon: Icons.school,
                            items: _departments,
                            onChanged: (value) {
                              setState(() {
                                _selectedDepartment = value;
                              });
                            },
                            validator: (value) {
                              if (value == null) {
                                return 'Please select your department';
                              }
                              return null;
                            },
                          ),
                          SizedBox(height: 16),
                          _buildDropdown(
                            value: _selectedLevel,
                            label: 'Academic Level',
                            icon: Icons.grade,
                            items: _levels,
                            onChanged: (value) {
                              setState(() {
                                _selectedLevel = value;
                              });
                            },
                            validator: (value) {
                              if (value == null) {
                                return 'Please select your level';
                              }
                              return null;
                            },
                          ),
                          SizedBox(height: 16),
                          _buildDropdown(
                            value: _selectedGender,
                            label: 'Gender',
                            icon: Icons.person_outline,
                            items: _genders,
                            onChanged: (value) {
                              setState(() {
                                _selectedGender = value;
                              });
                            },
                            validator: (value) {
                              if (value == null) {
                                return 'Please select your gender';
                              }
                              return null;
                            },
                          ),
                        ] else if (widget.role == 'lecturer') ...[
                          _buildTextField(
                            controller: _lecturerIdController,
                            label: 'Lecturer ID',
                            icon: Icons.badge,
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return 'Please enter your lecturer ID';
                              }
                              return null;
                            },
                          ),
                          SizedBox(height: 16),
                          _buildDropdown(
                            value: _selectedDepartment,
                            label: 'Department',
                            icon: Icons.school,
                            items: _departments,
                            onChanged: (value) {
                              setState(() {
                                _selectedDepartment = value;
                              });
                            },
                            validator: (value) {
                              if (value == null) {
                                return 'Please select your department';
                              }
                              return null;
                            },
                          ),
                          SizedBox(height: 16),
                          _buildDropdown(
                            value: _selectedFaculty,
                            label: 'Faculty',
                            icon: Icons.business,
                            items: _faculties,
                            onChanged: (value) {
                              setState(() {
                                _selectedFaculty = value;
                              });
                            },
                            validator: (value) {
                              if (value == null) {
                                return 'Please select your faculty';
                              }
                              return null;
                            },
                          ),
                        ] else if (widget.role == 'admin') ...[
                          _buildTextField(
                            controller: _adminIdController,
                            label: 'Admin ID',
                            icon: Icons.admin_panel_settings,
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return 'Please enter your admin ID';
                              }
                              return null;
                            },
                          ),
                          SizedBox(height: 16),
                          _buildTextField(
                            controller: _employeeIdController,
                            label: 'Employee ID',
                            icon: Icons.work,
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return 'Please enter your employee ID';
                              }
                              return null;
                            },
                          ),
                          SizedBox(height: 16),
                          _buildDropdown(
                            value: _selectedFaculty,
                            label: 'Faculty',
                            icon: Icons.business,
                            items: _faculties,
                            onChanged: (value) {
                              setState(() {
                                _selectedFaculty = value;
                              });
                            },
                            validator: (value) {
                              if (value == null) {
                                return 'Please select your faculty';
                              }
                              return null;
                            },
                          ),
                        ],
                        
                        SizedBox(height: 16),
                        _buildTextField(
                          controller: _passwordController,
                          label: 'Password',
                          icon: Icons.lock,
                          isPassword: true,
                          isPasswordField: true,
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please enter a password';
                            }
                            if (value.length < 8) {
                              return 'Password must be at least 8 characters';
                            }
                            return null;
                          },
                        ),
                        
                        SizedBox(height: 16),
                        _buildTextField(
                          controller: _confirmPasswordController,
                          label: 'Confirm Password',
                          icon: Icons.lock_outline,
                          isPassword: true,
                          isConfirmPassword: true,
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please confirm your password';
                            }
                            if (value != _passwordController.text) {
                              return 'Passwords do not match';
                            }
                            return null;
                          },
                        ),
                        
                        SizedBox(height: 24),
                        // Terms and Conditions
                        Container(
                          padding: EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: Colors.grey[50],
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: Colors.grey[200]!),
                          ),
                          child: Row(
                            children: [
                              Checkbox(
                                value: _agreeToTerms,
                                onChanged: (value) {
                                  setState(() {
                                    _agreeToTerms = value ?? false;
                                  });
                                },
                                activeColor: _roleColor,
                              ),
                              Expanded(
                                child: GestureDetector(
                                  onTap: () {
                                    setState(() {
                                      _agreeToTerms = !_agreeToTerms;
                                    });
                                  },
                                  child: RichText(
                                    text: TextSpan(
                                      style: TextStyle(
                                        color: Colors.grey[600],
                                        fontSize: 14,
                                      ),
                                      children: [
                                        TextSpan(text: 'I agree to the '),
                                        TextSpan(
                                          text: 'Terms & Conditions',
                                          style: TextStyle(
                                            color: _roleColor,
                                            fontWeight: FontWeight.w600,
                                          ),
                                        ),
                                        TextSpan(text: ' and '),
                                        TextSpan(
                                          text: 'Privacy Policy',
                                          style: TextStyle(
                                            color: _roleColor,
                                            fontWeight: FontWeight.w600,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        
                        SizedBox(height: 32),
                        // Sign Up Button
                        SizedBox(
                          width: double.infinity,
                          height: 56,
                          child: ElevatedButton.icon(
                            onPressed: (_isLoading || !_agreeToTerms) ? null : _handleSignup,
                            icon: _isLoading 
                                ? SizedBox(
                                    width: 20,
                                    height: 20,
                                    child: CircularProgressIndicator(
                                      color: Colors.white,
                                      strokeWidth: 2,
                                    ),
                                  )
                                : Icon(Icons.person_add, color: Colors.white),
                            label: Text(
                              _isLoading 
                                  ? 'Creating Account...' 
                                  : 'Create Account',
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.w600,
                                color: Colors.white,
                              ),
                            ),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: _roleColor,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(16),
                              ),
                              elevation: 2,
                            ),
                          ),
                        ),
                        
                        SizedBox(height: 24),
                        
                        // Already have account
                        Center(
                          child: TextButton(
                            onPressed: () {
                              Navigator.pushReplacement(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => LoginScreen(role: widget.role),
                                ),
                              );
                            },
                            child: RichText(
                              text: TextSpan(
                                style: TextStyle(fontSize: 14),
                                children: [
                                  TextSpan(
                                    text: 'Already have an account? ',
                                    style: TextStyle(color: Colors.grey[600]),
                                  ),
                                  TextSpan(
                                    text: 'Sign In',
                                    style: TextStyle(
                                      color: _roleColor,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        children: [
          IconButton(
            onPressed: () => Navigator.pop(context),
            icon: Icon(Icons.arrow_back_ios, color: _roleColor),
          ),
          SizedBox(width: 8),
          Container(
            width: 50,
            height: 50,
            decoration: BoxDecoration(
              color: _roleColor,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(
              Icons.school,
              color: Colors.white,
              size: 28,
            ),
          ),
          SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Attendease',
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: _roleColor,
                  ),
                ),
                Text(
                  _roleTitle,
                  style: TextStyle(
                    fontSize: 16,
                    color: Colors.grey[600],
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String label,
    required IconData icon,
    bool isPassword = false,
    bool isPasswordField = false,
    bool isConfirmPassword = false,
    TextInputType? keyboardType,
    String? Function(String?)? validator,
  }) {
    bool obscureText = false;
    if (isPasswordField) {
      obscureText = !_isPasswordVisible;
    } else if (isConfirmPassword) {
      obscureText = !_isConfirmPasswordVisible;
    } else if (isPassword) {
      obscureText = true;
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w600,
            color: Color(0xFF2D3748),
          ),
        ),
        SizedBox(height: 8),
        TextFormField(
          controller: controller,
          obscureText: obscureText,
          keyboardType: keyboardType,
          validator: validator,
          decoration: InputDecoration(
            hintText: 'Enter your ${label.toLowerCase()}',
            prefixIcon: Icon(icon, color: _roleColor),
            suffixIcon: (isPasswordField || isConfirmPassword)
                ? IconButton(
                    icon: Icon(
                      (isPasswordField ? _isPasswordVisible : _isConfirmPasswordVisible)
                          ? Icons.visibility_off
                          : Icons.visibility,
                      color: Colors.grey[600],
                    ),
                    onPressed: () {
                      setState(() {
                        if (isPasswordField) {
                          _isPasswordVisible = !_isPasswordVisible;
                        } else {
                          _isConfirmPasswordVisible = !_isConfirmPasswordVisible;
                        }
                      });
                    },
                  )
                : null,
            filled: true,
            fillColor: Colors.grey[50],
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide.none,
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(color: _roleColor, width: 2),
            ),
            errorBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(color: Colors.red, width: 2),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildDropdown({
    required String? value,
    required String label,
    required IconData icon,
    required List<String> items,
    required void Function(String?) onChanged,
    String? Function(String?)? validator,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w600,
            color: Color(0xFF2D3748),
          ),
        ),
        SizedBox(height: 8),
        DropdownButtonFormField<String>(
          value: value,
          decoration: InputDecoration(
            hintText: 'Select your ${label.toLowerCase()}',
            prefixIcon: Icon(icon, color: _roleColor),
            filled: true,
            fillColor: Colors.grey[50],
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide.none,
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(color: _roleColor, width: 2),
            ),
            errorBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(color: Colors.red, width: 2),
            ),
          ),
          items: items.map((String item) {
            return DropdownMenuItem<String>(
              value: item,
              child: Text(item),
            );
          }).toList(),
          onChanged: onChanged,
          validator: validator,
        ),
      ],
    );
  }

  Map<String, dynamic> _getUserData() {
    return {
      'fullName': _fullNameController.text.trim(),
      'email': _emailController.text.trim(),
      'phone': _phoneController.text.trim(),
      'role': widget.role,
      'password': _passwordController.text,
      if (widget.role == 'student') ...{
        'matricule': _matriculeController.text.trim(),
        'department': _selectedDepartment,
        'level': _selectedLevel,
        'gender': _selectedGender,
      } else if (widget.role == 'lecturer') ...{
        'lecturerId': _lecturerIdController.text.trim(),
        'department': _selectedDepartment,
        'faculty': _selectedFaculty,
      } else if (widget.role == 'admin') ...{
        'adminId': _adminIdController.text.trim(),
        'employeeId': _employeeIdController.text.trim(),
        'faculty': _selectedFaculty,
      },
    };
  }

  void _handleSignup() async {
    if (!_formKey.currentState!.validate()) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Please fill in all required fields'),
          backgroundColor: Colors.orange,
        ),
      );
      return;
    }

    if (!_agreeToTerms) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Please agree to the terms and conditions'),
          backgroundColor: Colors.orange,
        ),
      );
      return;
    }

    setState(() {
      _isLoading = true;
    });

    HapticFeedback.lightImpact();

    try {
      final userData = _getUserData();
      print('=== REGISTRATION ATTEMPT ===');
      print('User Data: $userData');
      print('Role: ${widget.role}');
      
      // Check backend connectivity first
      final isHealthy = await _apiService.checkHealth();
      if (!isHealthy) {
        throw Exception('Backend server is not accessible. Please try again later.');
      }
      
      // Register user directly with API
      final response = await _apiService.register(userData);
      print('=== REGISTRATION SUCCESS ===');
      print('Response: $response');

      setState(() {
        _isLoading = false;
      });

      // Show success message
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Row(
            children: [
              Icon(Icons.check_circle, color: Colors.white),
              SizedBox(width: 8),
              Text('Account created successfully!'),
            ],
          ),
          backgroundColor: Colors.green,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
          ),
        ),
      );

      // Navigate based on role - ALL ROLES GO TO EMAIL VERIFICATION FOR NOW
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => EmailVerificationScreen(
            email: userData['email'],
            role: widget.role,
          ),
        ),
      );
      
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      
      print('=== REGISTRATION ERROR ===');
      print('Error: $e');
      
      String errorMessage = 'Registration failed';
      if (e.toString().contains('Backend server is not accessible')) {
        errorMessage = 'Cannot connect to server. Please check your internet connection.';
      } else if (e.toString().contains('Email already registered')) {
        errorMessage = 'This email is already registered. Please use a different email.';
      } else if (e.toString().contains('Student ID already exists')) {
        errorMessage = 'This student ID is already registered.';
      } else if (e.toString().contains('Employee ID already exists')) {
        errorMessage = 'This employee ID is already registered.';
      } else {
        errorMessage = e.toString().replaceAll('Exception: ', '');
      }
      
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(errorMessage),
          backgroundColor: Colors.red,
          duration: Duration(seconds: 5),
          action: SnackBarAction(
            label: 'Retry',
            textColor: Colors.white,
            onPressed: () {
              _handleSignup();
            },
          ),
        ),
      );
    }
  }

  @override
  void dispose() {
    _fullNameController.dispose();
    _emailController.dispose();
    _phoneController.dispose();
    _matriculeController.dispose();
    _lecturerIdController.dispose();
    _adminIdController.dispose();
    _employeeIdController.dispose();
    _passwordController.dispose();
    _confirmPasswordController.dispose();
    super.dispose();
  }
}
