import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../models/app_state.dart';
import '../services/data_service.dart';
import '../utils/responsive_helper.dart';

class LecturersScreen extends StatefulWidget {
  const LecturersScreen({Key? key}) : super(key: key);
  @override
  _LecturersScreenState createState() => _LecturersScreenState();
}

class _LecturersScreenState extends State<LecturersScreen> with TickerProviderStateMixin {
  final TextEditingController _searchController = TextEditingController();
  final DataService _dataService = DataService();
  
  List<Lecturer> _lecturers = [];
  List<Lecturer> _filteredLecturers = [];
  bool _isLoading = true;
  String _sortBy = 'name';
  bool _sortAscending = true;
  String _filterDepartment = 'All';
  
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 600),
      vsync: this,
    );
    _fadeAnimation = CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    );
    _loadLecturers();
    _searchController.addListener(_filterLecturers);
  }

  @override
  void dispose() {
    _searchController.dispose();
    _animationController.dispose();
    super.dispose();
  }

  Future<void> _loadLecturers() async {
    try {
      final lecturers = await _dataService.getLecturers();
      setState(() {
        _lecturers = lecturers;
        _filteredLecturers = lecturers;
        _isLoading = false;
      });
      _animationController.forward();
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      _showAlert('Error loading lecturers: $e', isError: true);
    }
  }

  void _filterLecturers() {
    final query = _searchController.text.toLowerCase();
    setState(() {
      _filteredLecturers = _lecturers.where((lecturer) {
        final matchesSearch = query.isEmpty ||
            lecturer.name.toLowerCase().contains(query) ||
            lecturer.id.toLowerCase().contains(query) ||
            lecturer.email.toLowerCase().contains(query);
        
        final matchesDepartment = _filterDepartment == 'All' || 
            lecturer.department == _filterDepartment;
        
        return matchesSearch && matchesDepartment;
      }).toList();
    });
    _sortLecturers();
  }

  void _sortLecturers() {
    setState(() {
      _filteredLecturers.sort((a, b) {
        int result;
        switch (_sortBy) {
          case 'name':
            result = a.name.compareTo(b.name);
            break;
          case 'id':
            result = a.id.compareTo(b.id);
            break;
          case 'department':
            result = a.department.compareTo(b.department);
            break;
          case 'courses':
            result = a.courseCount.compareTo(b.courseCount);
            break;
          default:
            result = a.name.compareTo(b.name);
        }
        return _sortAscending ? result : -result;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    final isSmallScreen = ResponsiveHelper.isSmallScreen(context);
    
    if (_isLoading) {
      return const Center(
        child: CircularProgressIndicator(
          valueColor: AlwaysStoppedAnimation<Color>(Color(0xFF28a745)),
        ),
      );
    }

    return Padding(
      padding: ResponsiveHelper.getResponsivePadding(context),
      child: FadeTransition(
        opacity: _fadeAnimation,
        child: Column(
          children: [
            // Header Section
            Container(
              padding: EdgeInsets.all(isSmallScreen ? 12 : 16),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color(0xFF28a745), Color(0xFF20c997)],
                ),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Icon(Icons.school, color: Colors.white, size: 24),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          'Lecturer Management',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: isSmallScreen ? 16 : 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      ElevatedButton.icon(
                        onPressed: _showBulkActions,
                        icon: const Icon(Icons.more_vert, size: 16),
                        label: const Text('Actions'),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.white.withOpacity(0.2),
                          foregroundColor: Colors.white,
                          elevation: 0,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Manage faculty members, course assignments, and academic staff',
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.9),
                      fontSize: isSmallScreen ? 12 : 14,
                    ),
                  ),
                ],
              ),
            ),
            
            SizedBox(height: ResponsiveHelper.getResponsiveSpacing(context)),
            
            // Search and Filter Section
            Container(
              padding: EdgeInsets.all(isSmallScreen ? 12 : 16),
              decoration: BoxDecoration(
                color: Theme.of(context).cardColor,
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.1),
                    blurRadius: 8,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: Column(
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: TextField(
                          controller: _searchController,
                          decoration: InputDecoration(
                            hintText: 'Search lecturers...',
                            prefixIcon: const Icon(Icons.search),
                            suffixIcon: _searchController.text.isNotEmpty
                                ? IconButton(
                                    icon: const Icon(Icons.clear),
                                    onPressed: () {
                                      _searchController.clear();
                                      _filterLecturers();
                                    },
                                  )
                                : null,
                            contentPadding: EdgeInsets.all(isSmallScreen ? 8 : 12),
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      PopupMenuButton<String>(
                        icon: const Icon(Icons.sort),
                        onSelected: (value) {
                          setState(() {
                            if (_sortBy == value) {
                              _sortAscending = !_sortAscending;
                            } else {
                              _sortBy = value;
                              _sortAscending = true;
                            }
                          });
                          _sortLecturers();
                        },
                        itemBuilder: (context) => [
                          const PopupMenuItem(value: 'name', child: Text('Sort by Name')),
                          const PopupMenuItem(value: 'id', child: Text('Sort by ID')),
                          const PopupMenuItem(value: 'department', child: Text('Sort by Department')),
                          const PopupMenuItem(value: 'courses', child: Text('Sort by Course Count')),
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: DropdownButtonFormField<String>(
                          value: _filterDepartment,
                          decoration: const InputDecoration(
                            labelText: 'Department',
                            contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                          ),
                          items: ['All', 'Computer Science', 'Electrical Engineering', 'Mechanical Engineering', 'Mathematics', 'Physics', 'Chemistry']
                              .map((dept) => DropdownMenuItem(value: dept, child: Text(dept)))
                              .toList(),
                          onChanged: (value) {
                            setState(() {
                              _filterDepartment = value ?? 'All';
                            });
                            _filterLecturers();
                          },
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: () => _showAddLecturerDialog(),
                          icon: const Icon(Icons.person_add),
                          label: const Text('Add Lecturer'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFF28a745),
                            foregroundColor: Colors.white,
                            padding: ResponsiveHelper.getResponsiveButtonPadding(context),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            
            SizedBox(height: ResponsiveHelper.getResponsiveSpacing(context)),
            
            // Stats Row
            Row(
              children: [
                Expanded(
                  child: _buildStatCard(
                    _filteredLecturers.length.toString(),
                    'Total Lecturers',
                    Icons.school,
                    const Color(0xFF28a745),
                    isSmallScreen,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _buildStatCard(
                    _getActiveDepartments().toString(),
                    'Departments',
                    Icons.business,
                    const Color(0xFF667eea),
                    isSmallScreen,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _buildStatCard(
                    _getTotalCourses().toString(),
                    'Total Courses',
                    Icons.book,
                    const Color(0xFFffc107),
                    isSmallScreen,
                  ),
                ),
              ],
            ),
            
            SizedBox(height: ResponsiveHelper.getResponsiveSpacing(context)),
            
            // Lecturers List
            Expanded(
              child: _filteredLecturers.isEmpty
                  ? _buildEmptyState()
                  : ListView.builder(
                      itemCount: _filteredLecturers.length,
                      itemBuilder: (context, index) {
                        final lecturer = _filteredLecturers[index];
                        return _buildLecturerCard(lecturer, isSmallScreen, index);
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatCard(String number, String label, IconData icon, Color color, bool isSmallScreen) {
    return Container(
      padding: EdgeInsets.all(isSmallScreen ? 10 : 12),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(8),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ],
        border: Border.all(color: color.withOpacity(0.2)),
      ),
      child: Column(
        children: [
          Icon(icon, color: color, size: isSmallScreen ? 16 : 20),
          const SizedBox(height: 4),
          Text(
            number,
            style: TextStyle(
              fontSize: isSmallScreen ? 16 : 20,
              fontWeight: FontWeight.bold,
              color: color,
            ),
          ),
          Text(
            label,
            style: TextStyle(
              fontSize: isSmallScreen ? 9 : 10,
              color: Theme.of(context).textTheme.bodyMedium?.color,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildLecturerCard(Lecturer lecturer, bool isSmallScreen, int index) {
    return Container(
      margin: EdgeInsets.only(bottom: isSmallScreen ? 8 : 12),
      child: Card(
        elevation: 2,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        child: ExpansionTile(
          leading: CircleAvatar(
            backgroundColor: _getDepartmentColor(lecturer.department),
            child: Text(
              lecturer.name.split(' ').map((n) => n[0]).take(2).join(),
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 14,
              ),
            ),
          ),
          title: Text(
            lecturer.name,
            style: TextStyle(
              fontSize: isSmallScreen ? 13 : 14,
              fontWeight: FontWeight.w600,
              color: Theme.of(context).textTheme.bodyLarge?.color,
            ),
          ),
          subtitle: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'ID: ${lecturer.id}',
                style: TextStyle(
                  fontSize: isSmallScreen ? 11 : 12,
                  color: Theme.of(context).textTheme.bodyMedium?.color,
                ),
              ),
              Text(
                '${lecturer.department} • ${lecturer.courseCount} Courses',
                style: TextStyle(
                  fontSize: isSmallScreen ? 10 : 11,
                  color: Theme.of(context).textTheme.bodyMedium?.color,
                ),
              ),
            ],
          ),
          trailing: PopupMenuButton<String>(
            onSelected: (value) => _handleLecturerAction(value, lecturer),
            itemBuilder: (context) => [
              const PopupMenuItem(value: 'edit', child: Text('Edit Lecturer')),
              const PopupMenuItem(value: 'assign', child: Text('Assign Courses')),
              const PopupMenuItem(value: 'schedule', child: Text('View Schedule')),
              const PopupMenuItem(value: 'profile', child: Text('Full Profile')),
              const PopupMenuItem(value: 'contact', child: Text('Contact Info')),
              const PopupMenuItem(value: 'delete', child: Text('Delete')),
            ],
          ),
          children: [
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: _buildDetailItem('Email', lecturer.email, Icons.email),
                      ),
                      Expanded(
                        child: _buildDetailItem('Phone', lecturer.phone, Icons.phone),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: _buildDetailItem('Department', lecturer.department, Icons.business),
                      ),
                      Expanded(
                        child: _buildDetailItem('Courses', '${lecturer.courseCount}', Icons.book),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: () => _editLecturer(lecturer),
                          icon: const Icon(Icons.edit, size: 16),
                          label: const Text('Edit'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFF28a745),
                            foregroundColor: Colors.white,
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: () => _assignCourses(lecturer),
                          icon: const Icon(Icons.assignment, size: 16),
                          label: const Text('Assign'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFF667eea),
                            foregroundColor: Colors.white,
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      ElevatedButton(
                        onPressed: () => _viewSchedule(lecturer),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFFffc107),
                          foregroundColor: Colors.black,
                          shape: const CircleBorder(),
                          padding: const EdgeInsets.all(12),
                        ),
                        child: const Icon(Icons.schedule, size: 16),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDetailItem(String label, String value, IconData icon) {
    return Row(
      children: [
        Icon(icon, size: 16, color: Theme.of(context).textTheme.bodyMedium?.color),
        const SizedBox(width: 8),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: TextStyle(
                  fontSize: 11,
                  color: Theme.of(context).textTheme.bodyMedium?.color,
                ),
              ),
              Text(
                value,
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  color: Theme.of(context).textTheme.bodyLarge?.color,
                ),
                overflow: TextOverflow.ellipsis,
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.school_outlined,
            size: 64,
            color: Colors.grey[400],
          ),
          const SizedBox(height: 16),
          Text(
            'No lecturers found',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w600,
              color: Colors.grey[600],
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Add your first lecturer to get started',
            style: TextStyle(
              fontSize: 14,
              color: Colors.grey[500],
            ),
          ),
          const SizedBox(height: 24),
          ElevatedButton.icon(
            onPressed: () => _showAddLecturerDialog(),
            icon: const Icon(Icons.person_add),
            label: const Text('Add Lecturer'),
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF28a745),
              foregroundColor: Colors.white,
            ),
          ),
        ],
      ),
    );
  }

  Color _getDepartmentColor(String department) {
    switch (department.toLowerCase()) {
      case 'computer science':
        return const Color(0xFF667eea);
      case 'mathematics':
        return const Color(0xFF28a745);
      case 'physics':
        return const Color(0xFF6f42c1);
      case 'electrical engineering':
        return const Color(0xFFffc107);
      case 'mechanical engineering':
        return const Color(0xFF17a2b8);
      case 'chemistry':
        return const Color(0xFFdc3545);
      default:
        return const Color(0xFF6c757d);
    }
  }

  int _getActiveDepartments() {
    return _filteredLecturers.map((l) => l.department).toSet().length;
  }

  int _getTotalCourses() {
    return _filteredLecturers.fold(0, (sum, lecturer) => sum + lecturer.courseCount);
  }

  void _handleLecturerAction(String action, Lecturer lecturer) {
    HapticFeedback.lightImpact();
    switch (action) {
      case 'edit':
        _editLecturer(lecturer);
        break;
      case 'assign':
        _assignCourses(lecturer);
        break;
      case 'schedule':
        _viewSchedule(lecturer);
        break;
      case 'profile':
        _viewFullProfile(lecturer);
        break;
      case 'contact':
        _viewContactInfo(lecturer);
        break;
      case 'delete':
        _deleteLecturer(lecturer.id);
        break;
    }
  }

  void _showAddLecturerDialog() {
    final _formKey = GlobalKey<FormState>();
    final _nameController = TextEditingController();
    final _emailController = TextEditingController();
    final _phoneController = TextEditingController();
    String _selectedDepartment = '';

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Add New Lecturer'),
        content: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextFormField(
                  controller: _nameController,
                  decoration: const InputDecoration(
                    labelText: 'Full Name',
                    hintText: 'e.g., Dr. John Smith',
                  ),
                  validator: (value) => value?.isEmpty ?? true ? 'Required' : null,
                ),
                const SizedBox(height: 16),
                TextFormField(
                  decoration: const InputDecoration(
                    labelText: 'Lecturer ID',
                    hintText: 'Auto-generated',
                  ),
                  enabled: false,
                ),
                const SizedBox(height: 16),
                DropdownButtonFormField<String>(
                  decoration: const InputDecoration(labelText: 'Department'),
                  items: [
                    'Computer Science',
                    'Electrical Engineering',
                    'Mechanical Engineering',
                    'Mathematics',
                    'Physics',
                    'Chemistry',
                  ].map((dept) => DropdownMenuItem(value: dept, child: Text(dept))).toList(),
                  onChanged: (value) => _selectedDepartment = value ?? '',
                  validator: (value) => value?.isEmpty ?? true ? 'Required' : null,
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _emailController,
                  decoration: const InputDecoration(
                    labelText: 'Email',
                    hintText: 'lecturer@university.edu',
                  ),
                  keyboardType: TextInputType.emailAddress,
                  validator: (value) {
                    if (value?.isEmpty ?? true) return 'Required';
                    if (!value!.contains('@')) return 'Invalid email';
                    return null;
                  },
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _phoneController,
                  decoration: const InputDecoration(
                    labelText: 'Phone Number',
                    hintText: '+237 123 456 789',
                  ),
                  keyboardType: TextInputType.phone,
                  validator: (value) => value?.isEmpty ?? true ? 'Required' : null,
                ),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () async {
              if (_formKey.currentState?.validate() ?? false) {
                try {
                  final newId = 'LEC${(_lecturers.length + 1).toString().padLeft(3, '0')}';
                  final newLecturer = Lecturer(
                    name: _nameController.text,
                    id: newId,
                    department: _selectedDepartment,
                    email: _emailController.text.toLowerCase(),
                    phone: _phoneController.text,
                  );
                  
                  await _dataService.addLecturer(newLecturer);
                  setState(() {
                    _lecturers.add(newLecturer);
                  });
                  _filterLecturers();
                  Navigator.pop(context);
                  _showAlert('Lecturer added successfully! ID: $newId');
                } catch (e) {
                  _showAlert('Error adding lecturer: $e', isError: true);
                }
              }
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF28a745),
              foregroundColor: Colors.white,
            ),
            child: const Text('Add Lecturer'),
          ),
        ],
      ),
    );
  }

  void _editLecturer(Lecturer lecturer) {
    final _formKey = GlobalKey<FormState>();
    final _nameController = TextEditingController(text: lecturer.name);
    final _emailController = TextEditingController(text: lecturer.email);
    final _phoneController = TextEditingController(text: lecturer.phone);
    String _selectedDepartment = lecturer.department;

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Edit Lecturer'),
        content: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextFormField(
                  controller: _nameController,
                  decoration: const InputDecoration(labelText: 'Full Name'),
                  validator: (value) => value?.isEmpty ?? true ? 'Required' : null,
                ),
                const SizedBox(height: 16),
                TextFormField(
                  initialValue: lecturer.id,
                  decoration: const InputDecoration(labelText: 'Lecturer ID'),
                  enabled: false, // ID shouldn't be editable
                ),
                const SizedBox(height: 16),
                DropdownButtonFormField<String>(
                  value: _selectedDepartment,
                  decoration: const InputDecoration(labelText: 'Department'),
                  items: [
                    'Computer Science',
                    'Electrical Engineering',
                    'Mechanical Engineering',
                    'Mathematics',
                    'Physics',
                    'Chemistry',
                  ].map((dept) => DropdownMenuItem(value: dept, child: Text(dept))).toList(),
                  onChanged: (value) => _selectedDepartment = value ?? '',
                  validator: (value) => value?.isEmpty ?? true ? 'Required' : null,
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _emailController,
                  decoration: const InputDecoration(labelText: 'Email'),
                  keyboardType: TextInputType.emailAddress,
                  validator: (value) {
                    if (value?.isEmpty ?? true) return 'Required';
                    if (!value!.contains('@')) return 'Invalid email';
                    return null;
                  },
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _phoneController,
                  decoration: const InputDecoration(labelText: 'Phone Number'),
                  keyboardType: TextInputType.phone,
                  validator: (value) => value?.isEmpty ?? true ? 'Required' : null,
                ),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () async {
              if (_formKey.currentState?.validate() ?? false) {
                try {
                  final updatedLecturer = Lecturer(
                    name: _nameController.text,
                    id: lecturer.id, // Keep original ID
                    department: _selectedDepartment,
                    email: _emailController.text.toLowerCase(),
                    phone: _phoneController.text,
                    courseCount: lecturer.courseCount,
                  );
                  
                  await _dataService.updateLecturer(updatedLecturer);
                  final index = _lecturers.indexWhere((l) => l.id == lecturer.id);
                  if (index != -1) {
                    setState(() {
                      _lecturers[index] = updatedLecturer;
                    });
                    _filterLecturers();
                  }
                  Navigator.pop(context);
                  _showAlert('Lecturer updated successfully!');
                } catch (e) {
                  _showAlert('Error updating lecturer: $e', isError: true);
                }
              }
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF28a745),
              foregroundColor: Colors.white,
            ),
            child: const Text('Update Lecturer'),
          ),
        ],
      ),
    );
  }

  void _assignCourses(Lecturer lecturer) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Assign Courses to ${lecturer.name}'),
        content: SizedBox(
          width: double.maxFinite,
          height: 300,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Lecturer: ${lecturer.name}', style: const TextStyle(fontWeight: FontWeight.bold)),
              Text('Department: ${lecturer.department}'),
              const SizedBox(height: 16),
              const Text('Available Courses:', style: TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              Expanded(
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      CheckboxListTile(
                        title: const Text('CS301 - Database Systems'),
                        subtitle: const Text('Level 300 • 3 Credits'),
                        value: lecturer.department == 'Computer Science',
                        onChanged: (value) {},
                      ),
                      CheckboxListTile(
                        title: const Text('CS201 - Data Structures'),
                        subtitle: const Text('Level 200 • 4 Credits'),
                        value: false,
                        onChanged: (value) {},
                      ),
                      CheckboxListTile(
                        title: const Text('CS401 - Software Engineering'),
                        subtitle: const Text('Level 400 • 4 Credits'),
                        value: lecturer.department == 'Computer Science',
                        onChanged: (value) {},
                      ),
                      CheckboxListTile(
                        title: const Text('MATH301 - Discrete Mathematics'),
                        subtitle: const Text('Level 300 • 3 Credits'),
                        value: lecturer.department == 'Mathematics',
                        onChanged: (value) {},
                      ),
                      CheckboxListTile(
                        title: const Text('PHY401 - Quantum Physics'),
                        subtitle: const Text('Level 400 • 4 Credits'),
                        value: lecturer.department == 'Physics',
                        onChanged: (value) {},
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _showAlert('Courses assigned successfully!');
            },
            child: const Text('Assign Selected Courses'),
          ),
        ],
      ),
    );
  }

  void _viewSchedule(Lecturer lecturer) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('${lecturer.name} - Schedule'),
        content: SizedBox(
          width: double.maxFinite,
          height: 300,
          child: ListView(
            children: [
              _buildScheduleItem('Monday', '08:00 - 10:00', 'CS301 - Database Systems', 'Lecture Hall A'),
              _buildScheduleItem('Monday', '14:00 - 16:00', 'CS201 - Data Structures', 'Computer Lab 1'),
              _buildScheduleItem('Wednesday', '10:00 - 12:00', 'CS301 - Database Systems', 'Lecture Hall A'),
              _buildScheduleItem('Wednesday', '16:00 - 18:00', 'Office Hours', 'Office 201'),
              _buildScheduleItem('Friday', '08:00 - 10:00', 'CS401 - Software Engineering', 'Lecture Hall B'),
              _buildScheduleItem('Friday', '14:00 - 15:00', 'Faculty Meeting', 'Conference Room'),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _showAlert('Opening schedule editor...');
            },
            child: const Text('Edit Schedule'),
          ),
        ],
      ),
    );
  }

  Widget _buildScheduleItem(String day, String time, String activity, String location) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 4),
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: const Color(0xFF28a745),
          child: Text(day.substring(0, 1), style: const TextStyle(color: Colors.white)),
        ),
        title: Text(activity),
        subtitle: Text('$time • $location'),
        trailing: const Icon(Icons.schedule),
      ),
    );
  }

  void _viewFullProfile(Lecturer lecturer) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('${lecturer.name} - Full Profile'),
        content: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Center(
                child: CircleAvatar(
                  radius: 40,
                  backgroundColor: _getDepartmentColor(lecturer.department),
                  child: Text(
                    lecturer.name.split(' ').map((n) => n[0]).take(2).join(),
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 24,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              _buildProfileRow('Full Name', lecturer.name),
              _buildProfileRow('Lecturer ID', lecturer.id),
              _buildProfileRow('Department', lecturer.department),
              _buildProfileRow('Email', lecturer.email),
              _buildProfileRow('Phone', lecturer.phone),
              _buildProfileRow('Course Count', '${lecturer.courseCount}'),
              const SizedBox(height: 16),
              const Text(
                'Academic Information',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
              ),
              const SizedBox(height: 8),
              _buildProfileRow('Employment Date', 'January 2020'),
              _buildProfileRow('Qualification', 'Ph.D. in Computer Science'),
              _buildProfileRow('Research Area', 'Machine Learning & AI'),
              _buildProfileRow('Office Location', 'Room 201, CS Building'),
              _buildProfileRow('Office Hours', 'Mon-Wed 2:00-4:00 PM'),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _editLecturer(lecturer);
            },
            child: const Text('Edit Profile'),
          ),
        ],
      ),
    );
  }

  Widget _buildProfileRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 120,
            child: Text(
              '$label:',
              style: const TextStyle(fontWeight: FontWeight.w500),
            ),
          ),
          Expanded(
            child: Text(value),
          ),
        ],
      ),
    );
  }

  void _viewContactInfo(Lecturer lecturer) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('${lecturer.name} - Contact Information'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.email),
              title: const Text('Email'),
              subtitle: Text(lecturer.email),
              trailing: IconButton(
                icon: const Icon(Icons.copy),
                onPressed: () {
                  Clipboard.setData(ClipboardData(text: lecturer.email));
                  _showAlert('Email copied to clipboard');
                },
              ),
            ),
            ListTile(
              leading: const Icon(Icons.phone),
              title: const Text('Phone'),
              subtitle: Text(lecturer.phone),
              trailing: IconButton(
                icon: const Icon(Icons.call),
                onPressed: () => _showAlert('Opening phone app...'),
              ),
            ),
            ListTile(
              leading: const Icon(Icons.location_on),
              title: const Text('Office'),
              subtitle: const Text('Room 201, Computer Science Building'),
              trailing: IconButton(
                icon: const Icon(Icons.directions),
                onPressed: () => _showAlert('Opening directions...'),
              ),
            ),
            ListTile(
              leading: const Icon(Icons.schedule),
              title: const Text('Office Hours'),
              subtitle: const Text('Monday-Wednesday 2:00-4:00 PM'),
              trailing: IconButton(
                icon: const Icon(Icons.calendar_today),
                onPressed: () => _showAlert('Adding to calendar...'),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _showAlert('Opening messaging app...');
            },
            child: const Text('Send Message'),
          ),
        ],
      ),
    );
  }

  void _deleteLecturer(String id) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Lecturer'),
        content: Text('Are you sure you want to delete lecturer $id? This action cannot be undone.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () async {
              try {
                await _dataService.deleteLecturer(id);
                setState(() {
                  _lecturers.removeWhere((lecturer) => lecturer.id == id);
                });
                _filterLecturers();
                Navigator.pop(context);
                _showAlert('Lecturer $id deleted successfully!');
              } catch (e) {
                Navigator.pop(context);
                _showAlert('Error deleting lecturer: $e', isError: true);
              }
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
  }

  void _showBulkActions() {
    showModalBottomSheet(
      context: context,
      builder: (context) => Container(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              'Bulk Actions',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 20),
            ListTile(
              leading: const Icon(Icons.file_download),
              title: const Text('Export Lecturers'),
              subtitle: const Text('Export to CSV or Excel'),
              onTap: () {
                Navigator.pop(context);
                _exportLecturers();
              },
            ),
            ListTile(
              leading: const Icon(Icons.file_upload),
              title: const Text('Import Lecturers'),
              subtitle: const Text('Import from CSV or Excel'),
              onTap: () {
                Navigator.pop(context);
                _importLecturers();
              },
            ),
            ListTile(
              leading: const Icon(Icons.assignment),
              title: const Text('Bulk Course Assignment'),
              subtitle: const Text('Assign courses to multiple lecturers'),
              onTap: () {
                Navigator.pop(context);
                _bulkCourseAssignment();
              },
            ),
            ListTile(
              leading: const Icon(Icons.schedule),
              title: const Text('Generate Schedules'),
              subtitle: const Text('Auto-generate teaching schedules'),
              onTap: () {
                Navigator.pop(context);
                _generateSchedules();
              },
            ),
            ListTile(
              leading: const Icon(Icons.analytics),
              title: const Text('Faculty Reports'),
              subtitle: const Text('Generate faculty analytics'),
              onTap: () {
                Navigator.pop(context);
                _generateFacultyReports();
              },
            ),
          ],
        ),
      ),
    );
  }

  void _exportLecturers() {
    _showAlert('Exporting ${_filteredLecturers.length} lecturers to CSV...');
    // TODO: Implement actual export functionality
  }

  void _importLecturers() {
    _showAlert('Opening file picker for lecturer import...');
    // TODO: Implement actual import functionality
  }

  void _bulkCourseAssignment() {
    _showAlert('Opening bulk course assignment interface...');
    // TODO: Implement bulk assignment functionality
  }

  void _generateSchedules() {
    _showAlert('Generating optimized teaching schedules...');
    // TODO: Implement schedule generation functionality
  }

  void _generateFacultyReports() {
    _showAlert('Generating faculty performance reports...');
    // TODO: Implement report generation functionality
  }

  void _showAlert(String message, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: isError ? Colors.red : Colors.green,
        duration: const Duration(seconds: 2),
        action: SnackBarAction(
          label: 'OK',
          textColor: Colors.white,
          onPressed: () {
            ScaffoldMessenger.of(context).hideCurrentSnackBar();
          },
        ),
      ),
    );
  }
}
