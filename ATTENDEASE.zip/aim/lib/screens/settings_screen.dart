import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class SettingsScreen extends StatefulWidget {
  final bool isDarkMode;
  final Function(bool) onThemeChanged;

  const SettingsScreen({
    Key? key,
    required this.isDarkMode,
    required this.onThemeChanged,
  }) : super(key: key);

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  // Notification Settings
  bool _notificationsEnabled = true;
  bool _classReminders = true;
  bool _attendanceAlerts = true;
  bool _announcements = true;
  bool _dueDateReminders = true;
  
  // Location Settings
  bool _locationEnabled = true;
  bool _locationNotifications = true;
  
  // Security Settings
  bool _biometricEnabled = false;
  bool _autoCheckIn = false;
  bool _twoFactorAuth = false;
  
  // Appearance Settings
  late bool _currentDarkMode;
  String _selectedLanguage = 'English';
  String _selectedTimeFormat = '12 Hour';
  String _selectedDateFormat = 'MM/DD/YYYY';
  
  // Sound & Vibration
  double _notificationVolume = 0.8;
  bool _vibrationEnabled = true;
  bool _soundEnabled = true;
  String _selectedRingtone = 'Default';
  
  // Privacy Settings
  bool _shareAnalytics = false;
  bool _shareLocation = true;
  bool _personalizedAds = false;

  @override
  void initState() {
    super.initState();
    _currentDarkMode = widget.isDarkMode;
  }

  Color get backgroundColor => _currentDarkMode ? const Color(0xFF1a1a2e) : const Color(0xFFF8F9FA);
  Color get cardColor => _currentDarkMode ? const Color(0xFF2d2d42) : Colors.white;
  Color get textColor => _currentDarkMode ? Colors.white : const Color(0xFF2D3748);
  Color get subtitleColor => _currentDarkMode ? Colors.grey[400]! : const Color(0xFF718096);

  LinearGradient get primaryGradient => const LinearGradient(
    colors: [Color(0xFF667eea), Color(0xFF764ba2)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: backgroundColor,
      appBar: AppBar(
        backgroundColor: backgroundColor,
        elevation: 0,
        leading: IconButton(
          onPressed: () => Navigator.pop(context),
          icon: Icon(Icons.arrow_back, color: textColor),
        ),
        title: Row(
          children: [
            Container(
              width: 24,
              height: 24,
              decoration: BoxDecoration(
                gradient: primaryGradient,
                borderRadius: BorderRadius.circular(6),
              ),
              child: const Center(
                child: Text(
                  'A',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                  ),
                ),
              ),
            ),
            const SizedBox(width: 8),
            Text(
              'Settings',
              style: TextStyle(color: textColor, fontSize: 18, fontWeight: FontWeight.w600),
            ),
          ],
        ),
        actions: [
          IconButton(
            onPressed: () => _showResetDialog(),
            icon: Icon(Icons.refresh, color: textColor),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 16),
            
            // Appearance Section
            _buildSectionHeader(Icons.palette, 'Appearance'),
            _buildSettingsCard([
              _buildSwitchItem(
                'Dark Mode',
                'Switch between light and dark themes',
                _currentDarkMode,
                (value) {
                  setState(() {
                    _currentDarkMode = value;
                  });
                  widget.onThemeChanged(value);
                  HapticFeedback.lightImpact();
                  _showSettingChangedSnackBar('Theme changed to ${value ? 'Dark' : 'Light'} mode');
                },
                icon: _currentDarkMode ? Icons.dark_mode : Icons.light_mode,
              ),
              _buildDropdownItem(
                'Language',
                'Select your preferred language',
                _selectedLanguage,
                ['English', 'Spanish', 'French', 'German', 'Chinese', 'Arabic'],
                (value) {
                  setState(() => _selectedLanguage = value!);
                  _showSettingChangedSnackBar('Language changed to $value');
                },
                Icons.language,
              ),
              _buildDropdownItem(
                'Time Format',
                'Choose 12 or 24 hour format',
                _selectedTimeFormat,
                ['12 Hour', '24 Hour'],
                (value) {
                  setState(() => _selectedTimeFormat = value!);
                  _showSettingChangedSnackBar('Time format changed to $value');
                },
                Icons.access_time,
              ),
              _buildDropdownItem(
                'Date Format',
                'Select date display format',
                _selectedDateFormat,
                ['MM/DD/YYYY', 'DD/MM/YYYY', 'YYYY-MM-DD'],
                (value) {
                  setState(() => _selectedDateFormat = value!);
                  _showSettingChangedSnackBar('Date format changed to $value');
                },
                Icons.calendar_today,
              ),
            ]),

            const SizedBox(height: 24),

            // Notifications Section
            _buildSectionHeader(Icons.notifications, 'Notifications'),
            _buildSettingsCard([
              _buildSwitchItem(
                'Enable Notifications',
                'Receive important alerts and reminders',
                _notificationsEnabled,
                (value) {
                  setState(() => _notificationsEnabled = value);
                  if (value) {
                    _showNotificationPermissionDialog();
                  } else {
                    _showSettingChangedSnackBar('Notifications disabled');
                  }
                },
                icon: Icons.notifications_active,
              ),
              _buildSwitchItem(
                'Class Reminders',
                'Get notified before classes start',
                _classReminders,
                (value) {
                  setState(() => _classReminders = value);
                  _showSettingChangedSnackBar('Class reminders ${value ? 'enabled' : 'disabled'}');
                },
              ),
              _buildSwitchItem(
                'Attendance Alerts',
                'Alerts for attendance requirements',
                _attendanceAlerts,
                (value) {
                  setState(() => _attendanceAlerts = value);
                  _showSettingChangedSnackBar('Attendance alerts ${value ? 'enabled' : 'disabled'}');
                },
              ),
              _buildSwitchItem(
                'Announcements',
                'Important updates from your institution',
                _announcements,
                (value) {
                  setState(() => _announcements = value);
                  _showSettingChangedSnackBar('Announcements ${value ? 'enabled' : 'disabled'}');
                },
              ),
              _buildSliderItem(
                'Notification Volume',
                'Adjust notification sound volume',
                _notificationVolume,
                (value) {
                  setState(() => _notificationVolume = value);
                },
                Icons.volume_up,
              ),
              _buildSwitchItem(
                'Vibration',
                'Enable vibration for notifications',
                _vibrationEnabled,
                (value) {
                  setState(() => _vibrationEnabled = value);
                  if (value) HapticFeedback.mediumImpact();
                  _showSettingChangedSnackBar('Vibration ${value ? 'enabled' : 'disabled'}');
                },
              ),
              _buildSwitchItem(
                'Sound',
                'Enable sound for notifications',
                _soundEnabled,
                (value) {
                  setState(() => _soundEnabled = value);
                  _showSettingChangedSnackBar('Notification sound ${value ? 'enabled' : 'disabled'}');
                },
              ),
            ]),

            const SizedBox(height: 24),

            // Location Services Section
            _buildSectionHeader(Icons.location_on, 'Location Services'),
            _buildSettingsCard([
              _buildSwitchItem(
                'Enable Location',
                'Allow app to access your location for attendance',
                _locationEnabled,
                (value) {
                  setState(() => _locationEnabled = value);
                  if (value) {
                    _showLocationPermissionDialog();
                  } else {
                    _showSettingChangedSnackBar('Location services disabled');
                  }
                },
                icon: Icons.my_location,
              ),
              _buildSwitchItem(
                'Location Notifications',
                'Get notified when near class locations',
                _locationNotifications,
                (value) {
                  setState(() => _locationNotifications = value);
                  _showSettingChangedSnackBar('Location notifications ${value ? 'enabled' : 'disabled'}');
                },
              ),
            ]),

            const SizedBox(height: 24),

            // Security Section
            _buildSectionHeader(Icons.security, 'Security & Privacy'),
            _buildSettingsCard([
              _buildSwitchItem(
                'Biometric Authentication',
                'Use fingerprint or face unlock',
                _biometricEnabled,
                (value) {
                  setState(() => _biometricEnabled = value);
                  if (value) {
                    _showBiometricSetupDialog();
                  } else {
                    _showSettingChangedSnackBar('Biometric authentication disabled');
                  }
                },
                icon: Icons.fingerprint,
              ),
              _buildSwitchItem(
                'Two-Factor Authentication',
                'Add extra security to your account',
                _twoFactorAuth,
                (value) {
                  setState(() => _twoFactorAuth = value);
                  if (value) {
                    _showTwoFactorSetupDialog();
                  } else {
                    _showSettingChangedSnackBar('Two-factor authentication disabled');
                  }
                },
                icon: Icons.security,
              ),
              _buildSwitchItem(
                'Auto Check-in',
                'Automatically check in when in range',
                _autoCheckIn,
                (value) {
                  setState(() => _autoCheckIn = value);
                  _showSettingChangedSnackBar('Auto check-in ${value ? 'enabled' : 'disabled'}');
                },
              ),
            ]),

            const SizedBox(height: 24),

            // Privacy Section
            _buildSectionHeader(Icons.privacy_tip, 'Privacy'),
            _buildSettingsCard([
              _buildSwitchItem(
                'Share Analytics',
                'Help improve the app by sharing usage data',
                _shareAnalytics,
                (value) {
                  setState(() => _shareAnalytics = value);
                  _showSettingChangedSnackBar('Analytics sharing ${value ? 'enabled' : 'disabled'}');
                },
              ),
              _buildSwitchItem(
                'Share Location Data',
                'Allow sharing location for attendance verification',
                _shareLocation,
                (value) {
                  setState(() => _shareLocation = value);
                  _showSettingChangedSnackBar('Location sharing ${value ? 'enabled' : 'disabled'}');
                },
              ),
              _buildSwitchItem(
                'Personalized Ads',
                'Show ads based on your interests',
                _personalizedAds,
                (value) {
                  setState(() => _personalizedAds = value);
                  _showSettingChangedSnackBar('Personalized ads ${value ? 'enabled' : 'disabled'}');
                },
              ),
            ]),

            const SizedBox(height: 24),

            // Account Section
            _buildSectionHeader(Icons.account_circle, 'Account'),
            _buildSettingsCard([
              _buildActionItem(
                Icons.person,
                'Edit Profile',
                'Update your personal information',
                () => _showEditProfileDialog(),
              ),
              _buildActionItem(
                Icons.lock,
                'Change Password',
                'Update your account password',
                () => _showChangePasswordDialog(),
              ),
              _buildActionItem(
                Icons.download,
                'Export Data',
                'Download your attendance data',
                () => _showExportDataDialog(),
              ),
              _buildActionItem(
                Icons.sync,
                'Sync Data',
                'Synchronize with cloud storage',
                () => _performDataSync(),
              ),
            ]),

            const SizedBox(height: 24),

            // Legal Section
            _buildSectionHeader(Icons.gavel, 'Legal'),
            _buildSettingsCard([
              _buildActionItem(
                Icons.description,
                'Terms & Conditions',
                'Read our terms of service',
                () => _showTermsDialog(),
              ),
              _buildActionItem(
                Icons.privacy_tip,
                'Privacy Policy',
                'Learn how we protect your data',
                () => _showPrivacyDialog(),
              ),
              _buildActionItem(
                Icons.security,
                'Security Policy',
                'Our commitment to your security',
                () => _showSecurityDialog(),
              ),
            ]),

            const SizedBox(height: 24),

            // Support Section
            _buildSectionHeader(Icons.help, 'Support'),
            _buildSettingsCard([
              _buildActionItem(
                Icons.help_outline,
                'Help Center',
                'Get help and find answers',
                () => _showHelpCenter(),
              ),
              _buildActionItem(
                Icons.bug_report,
                'Report Issue',
                'Report bugs or problems',
                () => _showReportIssueDialog(),
              ),
              _buildActionItem(
                Icons.info,
                'About',
                'App version and information',
                () => _showAboutDialog(),
              ),
              _buildActionItem(
                Icons.rate_review,
                'Rate App',
                'Rate Attendease on the app store',
                () => _showRateAppDialog(),
              ),
            ]),

            const SizedBox(height: 32),

            // Logout Button
            SizedBox(
              width: double.infinity,
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Colors.red.shade400, Colors.red.shade600],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: ElevatedButton.icon(
                  onPressed: () => _showLogoutDialog(),
                  icon: const Icon(Icons.logout, color: Colors.white),
                  label: const Text(
                    'Logout',
                    style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600),
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.transparent,
                    shadowColor: Colors.transparent,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionHeader(IconData icon, String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              gradient: primaryGradient,
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(icon, color: Colors.white, size: 20),
          ),
          const SizedBox(width: 12),
          Text(
            title,
            style: TextStyle(
              color: textColor,
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSettingsCard(List<Widget> children) {
    return Container(
      decoration: BoxDecoration(
        color: cardColor,
        borderRadius: BorderRadius.circular(16),
        boxShadow: _currentDarkMode ? [] : [
          BoxShadow(
            color: Colors.black.withOpacity(0.06),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        children: children.asMap().entries.map((entry) {
          int index = entry.key;
          Widget child = entry.value;
          
          return Column(
            children: [
              child,
              if (index < children.length - 1)
                Divider(
                  height: 1,
                  color: subtitleColor.withOpacity(0.1),
                  indent: 20,
                  endIndent: 20,
                ),
            ],
          );
        }).toList(),
      ),
    );
  }

  Widget _buildSwitchItem(
    String title,
    String subtitle,
    bool value,
    Function(bool) onChanged, {
    IconData? icon,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
      child: Row(
        children: [
          if (icon != null) ...[
            Icon(icon, color: const Color(0xFF667eea), size: 24),
            const SizedBox(width: 16),
          ],
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    color: textColor,
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                if (subtitle.isNotEmpty) ...[
                  const SizedBox(height: 4),
                  Text(
                    subtitle,
                    style: TextStyle(
                      color: subtitleColor,
                      fontSize: 12,
                    ),
                  ),
                ],
              ],
            ),
          ),
          Switch(
            value: value,
            onChanged: onChanged,
            activeColor: const Color(0xFF667eea),
            activeTrackColor: const Color(0xFF667eea).withOpacity(0.3),
          ),
        ],
      ),
    );
  }

  Widget _buildDropdownItem(
    String title,
    String subtitle,
    String currentValue,
    List<String> options,
    Function(String?) onChanged,
    IconData icon,
  ) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
      child: Row(
        children: [
          Icon(icon, color: const Color(0xFF667eea), size: 24),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    color: textColor,
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  subtitle,
                  style: TextStyle(
                    color: subtitleColor,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              color: backgroundColor,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: subtitleColor.withOpacity(0.3)),
            ),
            child: DropdownButton<String>(
              value: currentValue,
              onChanged: (value) {
                onChanged(value);
                HapticFeedback.lightImpact();
              },
              underline: Container(),
              style: TextStyle(color: textColor, fontSize: 14),
              dropdownColor: cardColor,
              items: options.map((String value) {
                return DropdownMenuItem<String>(
                  value: value,
                  child: Text(value),
                );
              }).toList(),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSliderItem(
    String title,
    String subtitle,
    double value,
    Function(double) onChanged,
    IconData icon,
  ) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
      child: Column(
        children: [
          Row(
            children: [
              Icon(icon, color: const Color(0xFF667eea), size: 24),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: TextStyle(
                        color: textColor,
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      subtitle,
                      style: TextStyle(
                        color: subtitleColor,
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              ),
              Text(
                '${(value * 100).round()}%',
                style: TextStyle(
                  color: const Color(0xFF667eea),
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          SliderTheme(
            data: SliderTheme.of(context).copyWith(
              activeTrackColor: const Color(0xFF667eea),
              inactiveTrackColor: const Color(0xFF667eea).withOpacity(0.3),
              thumbColor: const Color(0xFF667eea),
              overlayColor: const Color(0xFF667eea).withOpacity(0.2),
            ),
            child: Slider(
              value: value,
              onChanged: onChanged,
              min: 0.0,
              max: 1.0,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActionItem(
    IconData icon,
    String title,
    String subtitle,
    VoidCallback onTap,
  ) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
          child: Row(
            children: [
              Icon(icon, color: const Color(0xFF667eea), size: 24),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: TextStyle(
                        color: textColor,
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      subtitle,
                      style: TextStyle(
                        color: subtitleColor,
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              ),
              Icon(
                Icons.arrow_forward_ios,
                color: subtitleColor,
                size: 16,
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showSettingChangedSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.green,
        duration: const Duration(seconds: 2),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }

  // Dialog Methods
  void _showNotificationPermissionDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: cardColor,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text('Enable Notifications', style: TextStyle(color: textColor)),
        content: Text(
          'Allow notifications to receive important updates about your classes and attendance.',
          style: TextStyle(color: subtitleColor),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Later', style: TextStyle(color: subtitleColor)),
          ),
          Container(
            decoration: BoxDecoration(
              gradient: primaryGradient,
              borderRadius: BorderRadius.circular(8),
            ),
            child: TextButton(
              onPressed: () {
                Navigator.pop(context);
                _showSettingChangedSnackBar('Notifications enabled successfully');
              },
              child: const Text('Allow', style: TextStyle(color: Colors.white)),
            ),
          ),
        ],
      ),
    );
  }

  void _showLocationPermissionDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: cardColor,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text('Location Access', style: TextStyle(color: textColor)),
        content: Text(
          'Location access is required for automatic attendance tracking using geofencing technology.',
          style: TextStyle(color: subtitleColor),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Deny', style: TextStyle(color: subtitleColor)),
          ),
          Container(
            decoration: BoxDecoration(
              gradient: primaryGradient,
              borderRadius: BorderRadius.circular(8),
            ),
            child: TextButton(
              onPressed: () {
                Navigator.pop(context);
                _showSettingChangedSnackBar('Location access granted');
              },
              child: const Text('Allow', style: TextStyle(color: Colors.white)),
            ),
          ),
        ],
      ),
    );
  }

  void _showBiometricSetupDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: cardColor,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text('Biometric Authentication', style: TextStyle(color: textColor)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.fingerprint, color: const Color(0xFF667eea), size: 48),
            const SizedBox(height: 16),
            Text(
              'Use your fingerprint or face to quickly and securely access the app.',
              style: TextStyle(color: subtitleColor),
              textAlign: TextAlign.center,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Skip', style: TextStyle(color: subtitleColor)),
          ),
          Container(
            decoration: BoxDecoration(
              gradient: primaryGradient,
              borderRadius: BorderRadius.circular(8),
            ),
            child: TextButton(
              onPressed: () {
                Navigator.pop(context);
                _showSettingChangedSnackBar('Biometric authentication enabled');
              },
              child: const Text('Enable', style: TextStyle(color: Colors.white)),
            ),
          ),
        ],
      ),
    );
  }

  void _showTwoFactorSetupDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: cardColor,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text('Two-Factor Authentication', style: TextStyle(color: textColor)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.security, color: const Color(0xFF667eea), size: 48),
            const SizedBox(height: 16),
            Text(
              'Add an extra layer of security to your account with SMS or authenticator app verification.',
              style: TextStyle(color: subtitleColor),
              textAlign: TextAlign.center,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Skip', style: TextStyle(color: subtitleColor)),
          ),
          Container(
            decoration: BoxDecoration(
              gradient: primaryGradient,
              borderRadius: BorderRadius.circular(8),
            ),
            child: TextButton(
              onPressed: () {
                Navigator.pop(context);
                _showSettingChangedSnackBar('Two-factor authentication setup started');
              },
              child: const Text('Setup', style: TextStyle(color: Colors.white)),
            ),
          ),
        ],
      ),
    );
  }

  void _showEditProfileDialog() {
    final TextEditingController nameController = TextEditingController(text: 'John Doe');
    final TextEditingController emailController = TextEditingController(text: 'john.doe@university.edu');
    final TextEditingController phoneController = TextEditingController(text: '+1 (555) 123-4567');

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: cardColor,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text('Edit Profile', style: TextStyle(color: textColor)),
        content: SizedBox(
          width: double.maxFinite,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: nameController,
                style: TextStyle(color: textColor),
                decoration: InputDecoration(
                  labelText: 'Full Name',
                  labelStyle: TextStyle(color: subtitleColor),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: BorderSide(color: const Color(0xFF667eea)),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: emailController,
                style: TextStyle(color: textColor),
                decoration: InputDecoration(
                  labelText: 'Email',
                  labelStyle: TextStyle(color: subtitleColor),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: BorderSide(color: const Color(0xFF667eea)),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: phoneController,
                style: TextStyle(color: textColor),
                decoration: InputDecoration(
                  labelText: 'Phone Number',
                  labelStyle: TextStyle(color: subtitleColor),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: BorderSide(color: const Color(0xFF667eea)),
                  ),
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel', style: TextStyle(color: subtitleColor)),
          ),
          Container(
            decoration: BoxDecoration(
              gradient: primaryGradient,
              borderRadius: BorderRadius.circular(8),
            ),
            child: TextButton(
              onPressed: () {
                Navigator.pop(context);
                _showSettingChangedSnackBar('Profile updated successfully');
              },
              child: const Text('Save', style: TextStyle(color: Colors.white)),
            ),
          ),
        ],
      ),
    );
  }

  void _showChangePasswordDialog() {
    final TextEditingController currentPasswordController = TextEditingController();
    final TextEditingController newPasswordController = TextEditingController();
    final TextEditingController confirmPasswordController = TextEditingController();

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: cardColor,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text('Change Password', style: TextStyle(color: textColor)),
        content: SizedBox(
          width: double.maxFinite,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: currentPasswordController,
                obscureText: true,
                style: TextStyle(color: textColor),
                decoration: InputDecoration(
                  labelText: 'Current Password',
                  labelStyle: TextStyle(color: subtitleColor),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: BorderSide(color: const Color(0xFF667eea)),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: newPasswordController,
                obscureText: true,
                style: TextStyle(color: textColor),
                decoration: InputDecoration(
                  labelText: 'New Password',
                  labelStyle: TextStyle(color: subtitleColor),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: BorderSide(color: const Color(0xFF667eea)),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: confirmPasswordController,
                obscureText: true,
                style: TextStyle(color: textColor),
                decoration: InputDecoration(
                  labelText: 'Confirm New Password',
                  labelStyle: TextStyle(color: subtitleColor),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: BorderSide(color: const Color(0xFF667eea)),
                  ),
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel', style: TextStyle(color: subtitleColor)),
          ),
          Container(
            decoration: BoxDecoration(
              gradient: primaryGradient,
              borderRadius: BorderRadius.circular(8),
            ),
            child: TextButton(
              onPressed: () {
                Navigator.pop(context);
                _showSettingChangedSnackBar('Password changed successfully');
              },
              child: const Text('Change', style: TextStyle(color: Colors.white)),
            ),
          ),
        ],
      ),
    );
  }

  void _showExportDataDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: cardColor,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text('Export Data', style: TextStyle(color: textColor)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'Export your attendance data in various formats:',
              style: TextStyle(color: subtitleColor),
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _buildExportOption('PDF', Icons.picture_as_pdf, Colors.red),
                _buildExportOption('Excel', Icons.table_chart, Colors.green),
                _buildExportOption('CSV', Icons.description, Colors.blue),
              ],
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close', style: TextStyle(color: Color(0xFF667eea))),
          ),
        ],
      ),
    );
  }

  Widget _buildExportOption(String format, IconData icon, Color color) {
    return GestureDetector(
      onTap: () {
        Navigator.pop(context);
        _showSettingChangedSnackBar('Exporting data as $format...');
      },
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: color.withOpacity(0.3)),
            ),
            child: Icon(icon, color: color, size: 24),
          ),
          const SizedBox(height: 8),
          Text(format, style: TextStyle(color: textColor, fontSize: 12)),
        ],
      ),
    );
  }

  void _performDataSync() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        backgroundColor: cardColor,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const CircularProgressIndicator(color: Color(0xFF667eea)),
            const SizedBox(height: 16),
            Text('Syncing data...', style: TextStyle(color: textColor)),
          ],
        ),
      ),
    );

    Future.delayed(const Duration(seconds: 3), () {
      Navigator.pop(context);
      _showSettingChangedSnackBar('Data synchronized successfully');
    });
  }

  void _showTermsDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: cardColor,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text('Terms & Conditions', style: TextStyle(color: textColor)),
        content: SizedBox(
          width: double.maxFinite,
          height: 400,
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Last updated: December 6, 2024', style: TextStyle(color: subtitleColor, fontSize: 12)),
                const SizedBox(height: 16),
                Text('1. ACCEPTANCE OF TERMS', style: TextStyle(color: textColor, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Text('By accessing and using the Attendease application ("App"), you accept and agree to be bound by the terms and provisions of this agreement. If you do not agree to abide by the above, please do not use this service.', style: TextStyle(color: subtitleColor, fontSize: 12)),
                const SizedBox(height: 16),
                Text('2. USE LICENSE', style: TextStyle(color: textColor, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Text('Permission is granted to temporarily use this application for personal, non-commercial transitory viewing only. This is the grant of a license, not a transfer of title, and under this license you may not:', style: TextStyle(color: subtitleColor, fontSize: 12)),
                const SizedBox(height: 8),
                Text('• Modify or copy the materials\n• Use the materials for any commercial purpose or for any public display\n• Attempt to reverse engineer any software contained in the App\n• Remove any copyright or other proprietary notations from the materials', style: TextStyle(color: subtitleColor, fontSize: 12)),
                const SizedBox(height: 16),
                Text('3. ATTENDANCE TRACKING', style: TextStyle(color: textColor, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Text('This application uses geofencing and facial recognition technology to track attendance. By using this service, you consent to:', style: TextStyle(color: subtitleColor, fontSize: 12)),
                const SizedBox(height: 8),
                Text('• Location tracking for attendance verification purposes only\n• Biometric data processing for identity verification\n• Storage of attendance records for academic purposes\n• Sharing of attendance data with authorized educational personnel', style: TextStyle(color: subtitleColor, fontSize: 12)),
                const SizedBox(height: 16),
                Text('4. USER RESPONSIBILITIES', style: TextStyle(color: textColor, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Text('Users are responsible for:', style: TextStyle(color: subtitleColor, fontSize: 12)),
                const SizedBox(height: 8),
                Text('• Maintaining the confidentiality of their account information\n• All activities that occur under their account\n• Ensuring accurate personal information\n• Reporting any unauthorized use of their account\n• Using the App in accordance with institutional policies', style: TextStyle(color: subtitleColor, fontSize: 12)),
                const SizedBox(height: 16),
                Text('5. PRIVACY AND DATA PROTECTION', style: TextStyle(color: textColor, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Text('We are committed to protecting your privacy. All personal data collected through the App is processed in accordance with our Privacy Policy and applicable data protection laws including GDPR and CCPA.', style: TextStyle(color: subtitleColor, fontSize: 12)),
                const SizedBox(height: 16),
                Text('6. LIMITATION OF LIABILITY', style: TextStyle(color: textColor, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Text('In no event shall Attendease or its suppliers be liable for any damages (including, without limitation, damages for loss of data or profit, or due to business interruption) arising out of the use or inability to use the App, even if Attendease or an authorized representative has been notified orally or in writing of the possibility of such damage.', style: TextStyle(color: subtitleColor, fontSize: 12)),
                const SizedBox(height: 16),
                Text('7. ACCURACY OF MATERIALS', style: TextStyle(color: textColor, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Text('The materials appearing in the App could include technical, typographical, or photographic errors. Attendease does not warrant that any of the materials in the App are accurate, complete, or current.', style: TextStyle(color: subtitleColor, fontSize: 12)),
                const SizedBox(height: 16),
                Text('8. MODIFICATIONS', style: TextStyle(color: textColor, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Text('Attendease may revise these terms of service at any time without notice. By using this App, you are agreeing to be bound by the then current version of these terms of service.', style: TextStyle(color: subtitleColor, fontSize: 12)),
                const SizedBox(height: 16),
                Text('9. GOVERNING LAW', style: TextStyle(color: textColor, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Text('These terms and conditions are governed by and construed in accordance with the laws of the jurisdiction in which your educational institution is located.', style: TextStyle(color: subtitleColor, fontSize: 12)),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close', style: TextStyle(color: Color(0xFF667eea))),
          ),
        ],
      ),
    );
  }

  void _showPrivacyDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: cardColor,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text('Privacy Policy', style: TextStyle(color: textColor)),
        content: SizedBox(
          width: double.maxFinite,
          height: 400,
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Last updated: December 6, 2024', style: TextStyle(color: subtitleColor, fontSize: 12)),
                const SizedBox(height: 16),
                Text('INFORMATION WE COLLECT', style: TextStyle(color: textColor, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Text('Personal Information:', style: TextStyle(color: textColor, fontWeight: FontWeight.w600, fontSize: 13)),
                Text('• Full name and student identification number\n• Email address and phone number\n• Profile photograph\n• Academic information (courses, schedules)\n• Emergency contact information', style: TextStyle(color: subtitleColor, fontSize: 12)),
                const SizedBox(height: 12),
                Text('Location Data:', style: TextStyle(color: textColor, fontWeight: FontWeight.w600, fontSize: 13)),
                Text('• GPS coordinates for geofencing attendance verification\n• Proximity data to classroom locations\n• Time-stamped location check-ins\n• Movement patterns within campus premises', style: TextStyle(color: subtitleColor, fontSize: 12)),
                const SizedBox(height: 12),
                Text('Biometric Data:', style: TextStyle(color: textColor, fontWeight: FontWeight.w600, fontSize: 13)),
                Text('• Facial recognition templates for identity verification\n• Fingerprint data (if enabled)\n• Voice patterns for authentication (future feature)\n• Behavioral biometrics for security', style: TextStyle(color: subtitleColor, fontSize: 12)),
                const SizedBox(height: 12),
                Text('Usage Data:', style: TextStyle(color: textColor, fontWeight: FontWeight.w600, fontSize: 13)),
                Text('• App usage patterns and frequency\n• Feature interaction data\n• Performance and crash reports\n• Device information and operating system', style: TextStyle(color: subtitleColor, fontSize: 12)),
                const SizedBox(height: 16),
                Text('HOW WE USE YOUR INFORMATION', style: TextStyle(color: textColor, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Text('Primary Purposes:', style: TextStyle(color: textColor, fontWeight: FontWeight.w600, fontSize: 13)),
                Text('• Verify your identity and track attendance accurately\n• Generate personalized attendance reports and analytics\n• Send notifications about classes, schedules, and attendance\n• Ensure security and prevent unauthorized access\n• Comply with educational institution requirements', style: TextStyle(color: subtitleColor, fontSize: 12)),
                const SizedBox(height: 12),
                Text('Secondary Purposes:', style: TextStyle(color: textColor, fontWeight: FontWeight.w600, fontSize: 13)),
                Text('• Improve app functionality and user experience\n• Develop new features and services\n• Conduct research and analytics (anonymized data)\n• Provide customer support and technical assistance', style: TextStyle(color: subtitleColor, fontSize: 12)),
                const SizedBox(height: 16),
                Text('DATA SHARING AND DISCLOSURE', style: TextStyle(color: textColor, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Text('We share your information with:', style: TextStyle(color: subtitleColor, fontSize: 12)),
                Text('• Your educational institution and authorized personnel\n• Third-party service providers (cloud storage, analytics)\n• Law enforcement when legally required\n• Emergency contacts in case of safety concerns', style: TextStyle(color: subtitleColor, fontSize: 12)),
                const SizedBox(height: 12),
                Text('We do NOT sell your personal information to third parties.', style: TextStyle(color: Colors.red, fontSize: 12, fontWeight: FontWeight.bold)),
                const SizedBox(height: 16),
                Text('DATA SECURITY', style: TextStyle(color: textColor, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Text('We implement industry-standard security measures:', style: TextStyle(color: subtitleColor, fontSize: 12)),
                Text('• End-to-end encryption for all data transmission\n• Secure cloud storage with regular backups\n• Multi-factor authentication for admin access\n• Regular security audits and penetration testing\n• Biometric data is encrypted and stored separately', style: TextStyle(color: subtitleColor, fontSize: 12)),
                const SizedBox(height: 16),
                Text('YOUR RIGHTS', style: TextStyle(color: textColor, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Text('You have the right to:', style: TextStyle(color: subtitleColor, fontSize: 12)),
                Text('• Access your personal information\n• Correct inaccurate data\n• Delete your account and data\n• Opt-out of certain data collection\n• Data portability (export your data)\n• Lodge complaints with data protection authorities', style: TextStyle(color: subtitleColor, fontSize: 12)),
                const SizedBox(height: 16),
                Text('CONTACT US', style: TextStyle(color: textColor, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Text('For privacy-related questions or concerns:\nEmail: privacy@attendease.edu\nPhone: +1 (555) 123-4567\nAddress: 123 University Ave, Education City, EC 12345', style: TextStyle(color: subtitleColor, fontSize: 12)),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close', style: TextStyle(color: Color(0xFF667eea))),
          ),
        ],
      ),
    );
  }

  void _showSecurityDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: cardColor,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text('Security Policy', style: TextStyle(color: textColor)),
        content: SizedBox(
          width: double.maxFinite,
          height: 400,
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Last updated: December 6, 2024', style: TextStyle(color: subtitleColor, fontSize: 12)),
                const SizedBox(height: 16),
                Text('DATA ENCRYPTION', style: TextStyle(color: textColor, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Text('Transmission Security:', style: TextStyle(color: textColor, fontWeight: FontWeight.w600, fontSize: 13)),
                Text('• All data transmitted between your device and our servers is encrypted using TLS 1.3 encryption protocols\n• API communications use certificate pinning\n• Real-time data synchronization with end-to-end encryption', style: TextStyle(color: subtitleColor, fontSize: 12)),
                const SizedBox(height: 12),
                Text('Storage Security:', style: TextStyle(color: textColor, fontWeight: FontWeight.w600, fontSize: 13)),
                Text('• Database encryption using AES-256 encryption\n• Encrypted backups with separate key management\n• Secure cloud storage with geographic redundancy', style: TextStyle(color: subtitleColor, fontSize: 12)),
                const SizedBox(height: 16),
                Text('BIOMETRIC DATA PROTECTION', style: TextStyle(color: textColor, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Text('Processing Standards:', style: TextStyle(color: textColor, fontWeight: FontWeight.w600, fontSize: 13)),
                Text('• Facial recognition processing occurs locally on device when possible\n• Biometric templates are encrypted using military-grade AES-256 encryption\n• Raw biometric data is never stored permanently\n• Biometric matching uses secure hash algorithms', style: TextStyle(color: subtitleColor, fontSize: 12)),
                const SizedBox(height: 12),
                Text('Access Controls:', style: TextStyle(color: textColor, fontWeight: FontWeight.w600, fontSize: 13)),
                Text('• Access to biometric data is restricted to authorized personnel only\n• Multi-level authentication required for biometric data access\n• Audit logs for all biometric data interactions\n• Automatic data purging after graduation/withdrawal', style: TextStyle(color: subtitleColor, fontSize: 12)),
                const SizedBox(height: 16),
                Text('SYSTEM SECURITY', style: TextStyle(color: textColor, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Text('Infrastructure Protection:', style: TextStyle(color: textColor, fontWeight: FontWeight.w600, fontSize: 13)),
                Text('• Multi-factor authentication for all administrative access\n• Role-based access control (RBAC) for different user types\n• Network segmentation and firewall protection\n• Intrusion detection and prevention systems', style: TextStyle(color: subtitleColor, fontSize: 12)),
                const SizedBox(height: 12),
                Text('Monitoring & Auditing:', style: TextStyle(color: textColor, fontWeight: FontWeight.w600, fontSize: 13)),
                Text('• 24/7 security monitoring and alerting\n• Regular security audits and penetration testing\n• Comprehensive logging of all system activities\n• Quarterly security assessments by third parties', style: TextStyle(color: subtitleColor, fontSize: 12)),
                const SizedBox(height: 16),
                Text('INCIDENT RESPONSE', style: TextStyle(color: textColor, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Text('Response Procedures:', style: TextStyle(color: textColor, fontWeight: FontWeight.w600, fontSize: 13)),
                Text('• Immediate containment of security incidents\n• Notification to affected users within 72 hours\n• Coordination with law enforcement when necessary\n• Post-incident analysis and system improvements', style: TextStyle(color: subtitleColor, fontSize: 12)),
                const SizedBox(height: 12),
                Text('Recovery Measures:', style: TextStyle(color: textColor, fontWeight: FontWeight.w600, fontSize: 13)),
                Text('• Automated backup restoration procedures\n• Business continuity planning\n• Alternative authentication methods during outages\n• Regular disaster recovery testing', style: TextStyle(color: subtitleColor, fontSize: 12)),
                const SizedBox(height: 16),
                Text('COMPLIANCE', style: TextStyle(color: textColor, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Text('Our security practices comply with:', style: TextStyle(color: subtitleColor, fontSize: 12)),
                Text('• General Data Protection Regulation (GDPR)\n• California Consumer Privacy Act (CCPA)\n• Family Educational Rights and Privacy Act (FERPA)\n• ISO 27001 Information Security Management\n• SOC 2 Type II compliance standards', style: TextStyle(color: subtitleColor, fontSize: 12)),
                const SizedBox(height: 16),
                Text('SECURITY CONTACT', style: TextStyle(color: textColor, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Text('Report security issues to:\nEmail: security@attendease.edu\nPhone: +1 (555) 123-4567 (24/7)\nBug Bounty: security.attendease.edu/bounty', style: TextStyle(color: subtitleColor, fontSize: 12)),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close', style: TextStyle(color: Color(0xFF667eea))),
          ),
        ],
      ),
    );
  }

  void _showHelpCenter() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: cardColor,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text('Help Center', style: TextStyle(color: textColor)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Frequently Asked Questions:', style: TextStyle(color: textColor, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            Text('• How does geofencing attendance work?', style: TextStyle(color: subtitleColor)),
            Text('• What if facial recognition fails to work?', style: TextStyle(color: subtitleColor)),
            Text('• How to check my attendance history?', style: TextStyle(color: subtitleColor)),
            Text('• How to export my attendance data?', style: TextStyle(color: subtitleColor)),
            Text('• Troubleshooting camera and location issues', style: TextStyle(color: subtitleColor)),
            Text('• How to update my profile information?', style: TextStyle(color: subtitleColor)),
            const SizedBox(height: 16),
            Text('Contact Support:', style: TextStyle(color: textColor, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Text('Email: support@attendease.edu', style: TextStyle(color: subtitleColor)),
            Text('Phone: +1 (555) 123-4567', style: TextStyle(color: subtitleColor)),
            Text('Live Chat: Available 24/7 in app', style: TextStyle(color: subtitleColor)),
            Text('Help Portal: help.attendease.edu', style: TextStyle(color: subtitleColor)),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close', style: TextStyle(color: Color(0xFF667eea))),
          ),
        ],
      ),
    );
  }

  void _showReportIssueDialog() {
    final TextEditingController issueController = TextEditingController();
    String selectedIssueType = 'Bug Report';
    
    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setState) => AlertDialog(
          backgroundColor: cardColor,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          title: Text('Report Issue', style: TextStyle(color: textColor)),
          content: SizedBox(
            width: double.maxFinite,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                DropdownButtonFormField<String>(
                  value: selectedIssueType,
                  decoration: InputDecoration(
                    labelText: 'Issue Type',
                    labelStyle: TextStyle(color: subtitleColor),
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide(color: const Color(0xFF667eea)),
                    ),
                  ),
                  dropdownColor: cardColor,
                  style: TextStyle(color: textColor),
                  items: ['Bug Report', 'Feature Request', 'Performance Issue', 'Security Concern', 'Other']
                      .map((type) => DropdownMenuItem(value: type, child: Text(type)))
                      .toList(),
                  onChanged: (value) => setState(() => selectedIssueType = value!),
                ),
                const SizedBox(height: 16),
                TextField(
                  controller: issueController,
                  maxLines: 4,
                  style: TextStyle(color: textColor),
                  decoration: InputDecoration(
                    labelText: 'Describe the issue in detail',
                    labelStyle: TextStyle(color: subtitleColor),
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide(color: const Color(0xFF667eea)),
                    ),
                  ),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text('Cancel', style: TextStyle(color: subtitleColor)),
            ),
            Container(
              decoration: BoxDecoration(
                gradient: primaryGradient,
                borderRadius: BorderRadius.circular(8),
              ),
              child: TextButton(
                onPressed: () {
                  Navigator.pop(context);
                  _showSettingChangedSnackBar('Issue reported successfully. We\'ll get back to you soon!');
                },
                child: const Text('Submit', style: TextStyle(color: Colors.white)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showAboutDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: cardColor,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Row(
          children: [
            Container(
              width: 32,
              height: 32,
              decoration: BoxDecoration(
                gradient: primaryGradient,
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Center(
                child: Text(
                  'A',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 18,
                  ),
                ),
              ),
            ),
            const SizedBox(width: 12),
            Text('About Attendease', style: TextStyle(color: textColor)),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Attendease - Smart Attendance Management', style: TextStyle(color: textColor, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Text('Version: 2.1.0', style: TextStyle(color: subtitleColor)),
            Text('Build: 2024.12.6', style: TextStyle(color: subtitleColor)),
            Text('Platform: Flutter 3.16.0', style: TextStyle(color: subtitleColor)),
            const SizedBox(height: 16),
            Text('Key Features:', style: TextStyle(color: textColor, fontWeight: FontWeight.bold)),
            Text('• Geofencing-based attendance tracking', style: TextStyle(color: subtitleColor)),
            Text('• Facial recognition verification', style: TextStyle(color: subtitleColor)),
            Text('• Real-time attendance monitoring', style: TextStyle(color: subtitleColor)),
            Text('• Professional calendar and analytics', style: TextStyle(color: subtitleColor)),
            Text('• Enhanced user interface with dark mode', style: TextStyle(color: subtitleColor)),
            Text('• Comprehensive settings and customization', style: TextStyle(color: subtitleColor)),
            Text('• Data export and synchronization', style: TextStyle(color: subtitleColor)),
            const SizedBox(height: 16),
            Text('© 2024 Attendease. All rights reserved.', style: TextStyle(color: subtitleColor, fontSize: 10)),
            Text('Developed with ❤️ for educational institutions', style: TextStyle(color: subtitleColor, fontSize: 10)),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close', style: TextStyle(color: Color(0xFF667eea))),
          ),
        ],
      ),
    );
  }

  void _showRateAppDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: cardColor,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Row(
          children: [
            Container(
              width: 32,
              height: 32,
              decoration: BoxDecoration(
                gradient: primaryGradient,
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Center(
                child: Text(
                  'A',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 18,
                  ),
                ),
              ),
            ),
            const SizedBox(width: 12),
            Text('Rate Attendease', style: TextStyle(color: textColor)),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'Enjoying Attendease? Please take a moment to rate us on the app store!',
              style: TextStyle(color: subtitleColor),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(5, (index) => 
                Icon(Icons.star, color: Colors.amber, size: 32),
              ),
            ),
            const SizedBox(height: 16),
            Text(
              'Your feedback helps us improve the app for everyone!',
              style: TextStyle(color: subtitleColor, fontSize: 12),
              textAlign: TextAlign.center,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Later', style: TextStyle(color: subtitleColor)),
          ),
          Container(
            decoration: BoxDecoration(
              gradient: primaryGradient,
              borderRadius: BorderRadius.circular(8),
            ),
            child: TextButton(
              onPressed: () {
                Navigator.pop(context);
                _showSettingChangedSnackBar('Thank you for rating Attendease! ⭐');
              },
              child: const Text('Rate Now', style: TextStyle(color: Colors.white)),
            ),
          ),
        ],
      ),
    );
  }

  void _showResetDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: cardColor,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text('Reset Settings', style: TextStyle(color: textColor)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.refresh, color: Colors.orange, size: 48),
            const SizedBox(height: 16),
            Text(
              'Are you sure you want to reset all settings to default values? This action cannot be undone.',
              style: TextStyle(color: subtitleColor),
              textAlign: TextAlign.center,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel', style: TextStyle(color: subtitleColor)),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              setState(() {
                // Reset all settings to default
                _notificationsEnabled = true;
                _classReminders = true;
                _attendanceAlerts = true;
                _announcements = true;
                _dueDateReminders = true;
                _locationEnabled = true;
                _locationNotifications = true;
                _biometricEnabled = false;
                _autoCheckIn = false;
                _twoFactorAuth = false;
                _selectedLanguage = 'English';
                _selectedTimeFormat = '12 Hour';
                _selectedDateFormat = 'MM/DD/YYYY';
                _notificationVolume = 0.8;
                _vibrationEnabled = true;
                _soundEnabled = true;
                _selectedRingtone = 'Default';
                _shareAnalytics = false;
                _shareLocation = true;
                _personalizedAds = false;
              });
              _showSettingChangedSnackBar('All settings reset to default values');
            },
            child: const Text('Reset', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  void _showLogoutDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: cardColor,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text('Logout', style: TextStyle(color: textColor)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.logout, color: Colors.red, size: 48),
            const SizedBox(height: 16),
            Text(
              'Are you sure you want to logout? You will need to sign in again to access your account.',
              style: TextStyle(color: subtitleColor),
              textAlign: TextAlign.center,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel', style: TextStyle(color: subtitleColor)),
          ),
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [Colors.red.shade400, Colors.red.shade600],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(8),
            ),
            child: TextButton(
              onPressed: () {
                Navigator.pop(context);
                Navigator.pop(context);
                _showSettingChangedSnackBar('Logged out successfully');
              },
              child: const Text('Logout', style: TextStyle(color: Colors.white)),
            ),
          ),
        ],
      ),
    );
  }
}
