import 'package:flutter/material.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({Key? key}) : super(key: key);

  @override
  SettingsScreenState createState() => SettingsScreenState();
}

class SettingsScreenState extends State<SettingsScreen> {
  String _academicYear = '2024/2025';
  String _semester = 'First Semester';
  final String _facultyName = 'Faculty of Science and Technology';
  int _sessionDuration = 120;
  int _geofenceRadius = 50;
  double _confidenceThreshold = 0.85;
  String _appTheme = 'light';

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        children: [
          _buildFormGroup(
            'Academic Year',
            DropdownButtonFormField<String>(
              value: _academicYear,
              decoration: const InputDecoration(
                contentPadding: EdgeInsets.all(12),
              ),
              items: ['2024/2025', '2025/2026']
                  .map((year) => DropdownMenuItem(value: year, child: Text(year)))
                  .toList(),
              onChanged: (value) {
                setState(() {
                  _academicYear = value ?? '2024/2025';
                });
              },
            ),
          ),

          _buildFormGroup(
            'Current Semester',
            DropdownButtonFormField<String>(
              value: _semester,
              decoration: const InputDecoration(
                contentPadding: EdgeInsets.all(12),
              ),
              items: ['First Semester', 'Second Semester']
                  .map((sem) => DropdownMenuItem(value: sem, child: Text(sem)))
                  .toList(),
              onChanged: (value) {
                setState(() {
                  _semester = value ?? 'First Semester';
                });
              },
            ),
          ),

          _buildFormGroup(
            'Faculty Name',
            TextFormField(
              initialValue: _facultyName,
              decoration: const InputDecoration(
                contentPadding: EdgeInsets.all(12),
              ),
              readOnly: true,
              style: const TextStyle(color: Colors.grey),
            ),
          ),

          _buildFormGroup(
            'Default Session Duration (minutes)',
            TextFormField(
              initialValue: _sessionDuration.toString(),
              decoration: const InputDecoration(
                contentPadding: EdgeInsets.all(12),
              ),
              keyboardType: TextInputType.number,
              onChanged: (value) {
                setState(() {
                  _sessionDuration = int.tryParse(value) ?? 120;
                });
              },
            ),
          ),

          _buildFormGroup(
            'Geofence Default Radius (meters)',
            TextFormField(
              initialValue: _geofenceRadius.toString(),
              decoration: const InputDecoration(
                contentPadding: EdgeInsets.all(12),
              ),
              keyboardType: TextInputType.number,
              onChanged: (value) {
                setState(() {
                  _geofenceRadius = int.tryParse(value) ?? 50;
                });
              },
            ),
          ),

          _buildFormGroup(
            'Face Recognition Confidence Threshold',
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Slider(
                  value: _confidenceThreshold,
                  min: 0.7,
                  max: 0.99,
                  divisions: 29,
                  activeColor: const Color(0xFF667eea),
                  onChanged: (value) {
                    setState(() {
                      _confidenceThreshold = value;
                    });
                  },
                ),
                Text(
                  'Current: ${(_confidenceThreshold * 100).round()}%',
                  style: TextStyle(
                    fontSize: 12,
                    color: Theme.of(context).textTheme.bodyMedium?.color,
                  ),
                ),
              ],
            ),
          ),

          _buildFormGroup(
            'App Theme',
            DropdownButtonFormField<String>(
              value: _appTheme,
              decoration: const InputDecoration(
                contentPadding: EdgeInsets.all(12),
              ),
              items: const [
                DropdownMenuItem(value: 'light', child: Text('Light Mode')),
                DropdownMenuItem(value: 'dark', child: Text('Dark Mode')),
                DropdownMenuItem(value: 'auto', child: Text('Auto (System)')),
              ],
              onChanged: (value) {
                setState(() {
                  _appTheme = value ?? 'light';
                });
                _changeTheme(value ?? 'light');
              },
            ),
          ),

          const SizedBox(height: 30),

          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: _saveSettings,
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF28a745),
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 12),
              ),
              child: const Text('Save Settings'),
            ),
          ),

          const SizedBox(height: 100), // Bottom padding
        ],
      ),
    );
  }

  Widget _buildFormGroup(String label, Widget child) {
    return Container(
      margin: const EdgeInsets.only(bottom: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: TextStyle(
              fontWeight: FontWeight.w500,
              color: Theme.of(context).textTheme.bodyLarge?.color,
            ),
          ),
          const SizedBox(height: 8),
          child,
        ],
      ),
    );
  }

  void _changeTheme(String theme) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Theme changed to $theme mode'),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  void _saveSettings() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Settings saved successfully!'),
        backgroundColor: Colors.green,
        duration: Duration(seconds: 2),
      ),
    );
  }
}
