import 'package:flutter/material.dart';
import 'admin_dashboard_screen.dart';
import 'admin_students_screen.dart';
import 'admin_lecturers_screen.dart';
import 'admin_reports_screen.dart';
import 'admin_settings_screen.dart';

class AdminMainScreen extends StatefulWidget {
  @override
  AdminMainScreenState createState() => AdminMainScreenState();
}

class AdminMainScreenState extends State<AdminMainScreen> {
  int _currentIndex = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFF1A1A1A),
      body: _buildCurrentScreen(),
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          color: Color(0xFF2D2D2D),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.3),
              blurRadius: 10,
              offset: Offset(0, -2),
            ),
          ],
        ),
        child: BottomNavigationBar(
          currentIndex: _currentIndex,
          onTap: (index) {
            setState(() {
              _currentIndex = index;
            });
          },
          type: BottomNavigationBarType.fixed,
          backgroundColor: Color(0xFF2D2D2D),
          selectedItemColor: Color(0xFF6C5CE7),
          unselectedItemColor: Colors.white54,
          selectedFontSize: 12,
          unselectedFontSize: 12,
          items: [
            BottomNavigationBarItem(
              icon: Icon(Icons.dashboard),
              label: 'Dashboard',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.people),
              label: 'Students',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.school),
              label: 'Lecturers',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.bar_chart),
              label: 'Reports',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.settings),
              label: 'Settings',
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCurrentScreen() {
    switch (_currentIndex) {
      case 0:
        return AdminDashboardScreen(onNavigate: changeTab);
      case 1:
        return AdminStudentsScreen();
      case 2:
        return AdminLecturersScreen();
      case 3:
        return AdminReportsScreen();
      case 4:
        return AdminSettingsScreen();
      default:
        return AdminDashboardScreen(onNavigate: changeTab);
    }
  }

  void changeTab(int index) {
    setState(() {
      _currentIndex = index;
    });
  }
}
