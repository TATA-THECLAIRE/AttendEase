import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../models/app_state.dart';
import '../../services/data_service.dart';
import '../../utils/responsive_helper.dart';

class StudentsScreen extends StatefulWidget {
  const StudentsScreen({Key? key}) : super(key: key);
  @override
  _StudentsScreenState createState() => _StudentsScreenState();
}

class _StudentsScreenState extends State<StudentsScreen> with TickerProviderStateMixin {
  final TextEditingController _searchController = TextEditingController();
  final DataService _dataService = DataService();
  
  List<Student> _students = [];
  List<Student> _filteredStudents = [];
  bool _isLoading = true;
  String _sortBy = 'name';
  bool _sortAscending = true;
  String _filterDepartment = 'All';
  String _filterLevel = 'All';
  
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 600),
      vsync: this,
    );
    _fadeAnimation = CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    );
    _loadStudents();
    _searchController.addListener(_filterStudents);
  }

  @override
  void dispose() {
    _searchController.dispose();
    _animationController.dispose();
    super.dispose();
  }

  Future<void> _loadStudents() async {
    try {
      final students = await _dataService.getStudents();
      setState(() {
        _students = students;
        _filteredStudents = students;
        _isLoading = false;
      });
      _animationController.forward();
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      _showAlert('Error loading students: $e', isError: true);
    }
  }

  void _filterStudents() {
    final query = _searchController.text.toLowerCase();
    setState(() {
      _filteredStudents = _students.where((student) {
        final matchesSearch = query.isEmpty ||
            student.name.toLowerCase().contains(query) ||
            student.matricle.toLowerCase().contains(query) ||
            student.email.toLowerCase().contains(query);
        
        final matchesDepartment = _filterDepartment == 'All' || 
            student.department == _filterDepartment;
        
        final matchesLevel = _filterLevel == 'All' || 
            student.level == _filterLevel;
        
        return matchesSearch && matchesDepartment && matchesLevel;
      }).toList();
    });
    _sortStudents();
  }

  void _sortStudents() {
    setState(() {
      _filteredStudents.sort((a, b) {
        int result;
        switch (_sortBy) {
          case 'name':
            result = a.name.compareTo(b.name);
            break;
          case 'matricle':
            result = a.matricle.compareTo(b.matricle);
            break;
          case 'department':
            result = a.department.compareTo(b.department);
            break;
          case 'level':
            result = a.level.compareTo(b.level);
            break;
          default:
            result = a.name.compareTo(b.name);
        }
        return _sortAscending ? result : -result;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    final isSmallScreen = ResponsiveHelper.isSmallScreen(context);
    
    if (_isLoading) {
      return const Center(
        child: CircularProgressIndicator(
          valueColor: AlwaysStoppedAnimation<Color>(Color(0xFF667eea)),
        ),
      );
    }

    return Padding(
      padding: ResponsiveHelper.getResponsivePadding(context),
      child: FadeTransition(
        opacity: _fadeAnimation,
        child: Column(
          children: [
            // Header Section
            Container(
              padding: EdgeInsets.all(isSmallScreen ? 12 : 16),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color(0xFF667eea), Color(0xFF764ba2)],
                ),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Icon(Icons.people, color: Colors.white, size: 24),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          'Student Management',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: isSmallScreen ? 16 : 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      ElevatedButton.icon(
                        onPressed: _showBulkActions,
                        icon: const Icon(Icons.more_vert, size: 16),
                        label: const Text('Bulk'),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.white.withOpacity(0.2),
                          foregroundColor: Colors.white,
                          elevation: 0,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Manage student records, enrollment, and attendance tracking',
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.9),
                      fontSize: isSmallScreen ? 12 : 14,
                    ),
                  ),
                ],
              ),
            ),
            
            SizedBox(height: ResponsiveHelper.getResponsiveSpacing(context)),
            
            // Search and Filter Section
            Container(
              padding: EdgeInsets.all(isSmallScreen ? 12 : 16),
              decoration: BoxDecoration(
                color: Theme.of(context).cardColor,
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.1),
                    blurRadius: 8,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: Column(
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: TextField(
                          controller: _searchController,
                          decoration: InputDecoration(
                            hintText: 'Search students...',
                            prefixIcon: const Icon(Icons.search),
                            suffixIcon: _searchController.text.isNotEmpty
                                ? IconButton(
                                    icon: const Icon(Icons.clear),
                                    onPressed: () {
                                      _searchController.clear();
                                      _filterStudents();
                                    },
                                  )
                                : null,
                            contentPadding: EdgeInsets.all(isSmallScreen ? 8 : 12),
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      PopupMenuButton<String>(
                        icon: const Icon(Icons.sort),
                        onSelected: (value) {
                          setState(() {
                            if (_sortBy == value) {
                              _sortAscending = !_sortAscending;
                            } else {
                              _sortBy = value;
                              _sortAscending = true;
                            }
                          });
                          _sortStudents();
                        },
                        itemBuilder: (context) => [
                          const PopupMenuItem(value: 'name', child: Text('Sort by Name')),
                          const PopupMenuItem(value: 'matricle', child: Text('Sort by Matricle')),
                          const PopupMenuItem(value: 'department', child: Text('Sort by Department')),
                          const PopupMenuItem(value: 'level', child: Text('Sort by Level')),
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: DropdownButtonFormField<String>(
                          value: _filterDepartment,
                          decoration: const InputDecoration(
                            labelText: 'Department',
                            contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                          ),
                          items: ['All', 'Computer Science', 'Electrical Engineering', 'Mechanical Engineering', 'Mathematics', 'Physics', 'Chemistry']
                              .map((dept) => DropdownMenuItem(value: dept, child: Text(dept)))
                              .toList(),
                          onChanged: (value) {
                            setState(() {
                              _filterDepartment = value ?? 'All';
                            });
                            _filterStudents();
                          },
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: DropdownButtonFormField<String>(
                          value: _filterLevel,
                          decoration: const InputDecoration(
                            labelText: 'Level',
                            contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                          ),
                          items: ['All', 'Level 100', 'Level 200', 'Level 300', 'Level 400']
                              .map((level) => DropdownMenuItem(value: level, child: Text(level)))
                              .toList(),
                          onChanged: (value) {
                            setState(() {
                              _filterLevel = value ?? 'All';
                            });
                            _filterStudents();
                          },
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton.icon(
                      onPressed: () => _showAddStudentDialog(),
                      icon: const Icon(Icons.person_add),
                      label: const Text('Add Student'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF667eea),
                        foregroundColor: Colors.white,
                        padding: ResponsiveHelper.getResponsiveButtonPadding(context),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            
            SizedBox(height: ResponsiveHelper.getResponsiveSpacing(context)),
            
            // Stats Row
            Row(
              children: [
                Expanded(
                  child: _buildStatCard(
                    _filteredStudents.length.toString(),
                    'Total Students',
                    Icons.people,
                    const Color(0xFF667eea),
                    isSmallScreen,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _buildStatCard(
                    _getActiveDepartments().toString(),
                    'Departments',
                    Icons.business,
                    const Color(0xFF28a745),
                    isSmallScreen,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _buildStatCard(
                    _getNewStudentsThisMonth().toString(),
                    'New This Month',
                    Icons.trending_up,
                    const Color(0xFFffc107),
                    isSmallScreen,
                  ),
                ),
              ],
            ),
            
            SizedBox(height: ResponsiveHelper.getResponsiveSpacing(context)),
            
            // Students List
            Expanded(
              child: _filteredStudents.isEmpty
                  ? _buildEmptyState()
                  : ListView.builder(
                      itemCount: _filteredStudents.length,
                      itemBuilder: (context, index) {
                        final student = _filteredStudents[index];
                        return _buildStudentCard(student, isSmallScreen, index);
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatCard(String number, String label, IconData icon, Color color, bool isSmallScreen) {
    return Container(
      padding: EdgeInsets.all(isSmallScreen ? 10 : 12),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(8),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ],
        border: Border.all(color: color.withOpacity(0.2)),
      ),
      child: Column(
        children: [
          Icon(icon, color: color, size: isSmallScreen ? 16 : 20),
          const SizedBox(height: 4),
          Text(
            number,
            style: TextStyle(
              fontSize: isSmallScreen ? 16 : 20,
              fontWeight: FontWeight.bold,
              color: color,
            ),
          ),
          Text(
            label,
            style: TextStyle(
              fontSize: isSmallScreen ? 9 : 10,
              color: Theme.of(context).textTheme.bodyMedium?.color,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildStudentCard(Student student, bool isSmallScreen, int index) {
    return Container(
      margin: EdgeInsets.only(bottom: isSmallScreen ? 8 : 12),
      child: Card(
        elevation: 2,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        child: ExpansionTile(
          leading: CircleAvatar(
            backgroundColor: _getDepartmentColor(student.department),
            child: Text(
              student.name.split(' ').map((n) => n[0]).take(2).join(),
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 14,
              ),
            ),
          ),
          title: Text(
            student.name,
            style: TextStyle(
              fontSize: isSmallScreen ? 13 : 14,
              fontWeight: FontWeight.w600,
              color: Theme.of(context).textTheme.bodyLarge?.color,
            ),
          ),
          subtitle: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Matricle: ${student.matricle}',
                style: TextStyle(
                  fontSize: isSmallScreen ? 11 : 12,
                  color: Theme.of(context).textTheme.bodyMedium?.color,
                ),
              ),
              Text(
                '${student.department} • ${student.level}',
                style: TextStyle(
                  fontSize: isSmallScreen ? 10 : 11,
                  color: Theme.of(context).textTheme.bodyMedium?.color,
                ),
              ),
            ],
          ),
          trailing: PopupMenuButton<String>(
            onSelected: (value) => _handleStudentAction(value, student),
            itemBuilder: (context) => [
              const PopupMenuItem(value: 'edit', child: Text('Edit Student')),
              const PopupMenuItem(value: 'attendance', child: Text('View Attendance')),
              const PopupMenuItem(value: 'courses', child: Text('Enrolled Courses')),
              const PopupMenuItem(value: 'profile', child: Text('Full Profile')),
              const PopupMenuItem(value: 'contact', child: Text('Contact Info')),
              const PopupMenuItem(value: 'delete', child: Text('Delete')),
            ],
          ),
          children: [
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: _buildDetailItem('Email', student.email, Icons.email),
                      ),
                      Expanded(
                        child: _buildDetailItem('Gender', student.gender, Icons.person),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: _buildDetailItem('Department', student.department, Icons.business),
                      ),
                      Expanded(
                        child: _buildDetailItem('Level', student.level, Icons.school),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: () => _editStudent(student),
                          icon: const Icon(Icons.edit, size: 16),
                          label: const Text('Edit'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFF667eea),
                            foregroundColor: Colors.white,
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: () => _viewAttendance(student),
                          icon: const Icon(Icons.analytics, size: 16),
                          label: const Text('Attendance'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFF28a745),
                            foregroundColor: Colors.white,
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      ElevatedButton(
                        onPressed: () => _deleteStudent(student.matricle),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFFdc3545),
                          foregroundColor: Colors.white,
                          shape: const CircleBorder(),
                          padding: const EdgeInsets.all(12),
                        ),
                        child: const Icon(Icons.delete, size: 16),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDetailItem(String label, String value, IconData icon) {
    return Row(
      children: [
        Icon(icon, size: 16, color: Theme.of(context).textTheme.bodyMedium?.color),
        const SizedBox(width: 8),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: TextStyle(
                  fontSize: 11,
                  color: Theme.of(context).textTheme.bodyMedium?.color,
                ),
              ),
              Text(
                value,
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  color: Theme.of(context).textTheme.bodyLarge?.color,
                ),
                overflow: TextOverflow.ellipsis,
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.people_outline,
            size: 64,
            color: Colors.grey[400],
          ),
          const SizedBox(height: 16),
          Text(
            'No students found',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w600,
              color: Colors.grey[600],
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Add your first student to get started',
            style: TextStyle(
              fontSize: 14,
              color: Colors.grey[500],
            ),
          ),
          const SizedBox(height: 24),
          ElevatedButton.icon(
            onPressed: () => _showAddStudentDialog(),
            icon: const Icon(Icons.person_add),
            label: const Text('Add Student'),
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF667eea),
              foregroundColor: Colors.white,
            ),
          ),
        ],
      ),
    );
  }

  Color _getDepartmentColor(String department) {
    switch (department.toLowerCase()) {
      case 'computer science':
        return const Color(0xFF667eea);
      case 'mathematics':
        return const Color(0xFF28a745);
      case 'physics':
        return const Color(0xFF6f42c1);
      case 'electrical engineering':
        return const Color(0xFFffc107);
      case 'mechanical engineering':
        return const Color(0xFF17a2b8);
      case 'chemistry':
        return const Color(0xFFdc3545);
      default:
        return const Color(0xFF6c757d);
    }
  }

  int _getActiveDepartments() {
    return _filteredStudents.map((s) => s.department).toSet().length;
  }

  int _getNewStudentsThisMonth() {
    // Simulate new students this month
    return (_filteredStudents.length * 0.1).round();
  }

  void _handleStudentAction(String action, Student student) {
    HapticFeedback.lightImpact();
    switch (action) {
      case 'edit':
        _editStudent(student);
        break;
      case 'attendance':
        _viewAttendance(student);
        break;
      case 'courses':
        _viewEnrolledCourses(student);
        break;
      case 'profile':
        _viewFullProfile(student);
        break;
      case 'contact':
        _viewContactInfo(student);
        break;
      case 'delete':
        _deleteStudent(student.matricle);
        break;
    }
  }

  void _showAddStudentDialog() {
    final _formKey = GlobalKey<FormState>();
    final _nameController = TextEditingController();
    final _matricleController = TextEditingController();
    final _emailController = TextEditingController();
    String _selectedDepartment = '';
    String _selectedLevel = '';
    String _selectedGender = '';

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Add New Student'),
        content: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextFormField(
                  controller: _nameController,
                  decoration: const InputDecoration(
                    labelText: 'Full Name',
                    hintText: 'e.g., John Doe',
                  ),
                  validator: (value) => value?.isEmpty ?? true ? 'Required' : null,
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _matricleController,
                  decoration: const InputDecoration(
                    labelText: 'Matricle Number',
                    hintText: 'e.g., CS2024001',
                  ),
                  validator: (value) => value?.isEmpty ?? true ? 'Required' : null,
                ),
                const SizedBox(height: 16),
                DropdownButtonFormField<String>(
                  decoration: const InputDecoration(labelText: 'Department'),
                  items: [
                    'Computer Science',
                    'Electrical Engineering',
                    'Mechanical Engineering',
                    'Mathematics',
                    'Physics',
                    'Chemistry',
                  ].map((dept) => DropdownMenuItem(value: dept, child: Text(dept))).toList(),
                  onChanged: (value) => _selectedDepartment = value ?? '',
                  validator: (value) => value?.isEmpty ?? true ? 'Required' : null,
                ),
                const SizedBox(height: 16),
                DropdownButtonFormField<String>(
                  decoration: const InputDecoration(labelText: 'Level'),
                  items: ['Level 100', 'Level 200', 'Level 300', 'Level 400']
                      .map((level) => DropdownMenuItem(value: level, child: Text(level)))
                      .toList(),
                  onChanged: (value) => _selectedLevel = value ?? '',
                  validator: (value) => value?.isEmpty ?? true ? 'Required' : null,
                ),
                const SizedBox(height: 16),
                DropdownButtonFormField<String>(
                  decoration: const InputDecoration(labelText: 'Gender'),
                  items: ['Male', 'Female', 'Other']
                      .map((gender) => DropdownMenuItem(value: gender, child: Text(gender)))
                      .toList(),
                  onChanged: (value) => _selectedGender = value ?? '',
                  validator: (value) => value?.isEmpty ?? true ? 'Required' : null,
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _emailController,
                  decoration: const InputDecoration(
                    labelText: 'Email',
                    hintText: 'student@university.edu',
                  ),
                  keyboardType: TextInputType.emailAddress,
                  validator: (value) {
                    if (value?.isEmpty ?? true) return 'Required';
                    if (!value!.contains('@')) return 'Invalid email';
                    return null;
                  },
                ),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () async {
              if (_formKey.currentState?.validate() ?? false) {
                try {
                  final newStudent = Student(
                    name: _nameController.text,
                    matricle: _matricleController.text.toUpperCase(),
                    department: _selectedDepartment,
                    level: _selectedLevel,
                    gender: _selectedGender,
                    email: _emailController.text.toLowerCase(),
                  );
                  
                  await _dataService.addStudent(newStudent);
                  setState(() {
                    _students.add(newStudent);
                  });
                  _filterStudents();
                  Navigator.pop(context);
                  _showAlert('Student added successfully!');
                } catch (e) {
                  _showAlert('Error adding student: $e', isError: true);
                }
              }
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF667eea),
              foregroundColor: Colors.white,
            ),
            child: const Text('Add Student'),
          ),
        ],
      ),
    );
  }

  void _editStudent(Student student) {
    final _formKey = GlobalKey<FormState>();
    final _nameController = TextEditingController(text: student.name);
    final _matricleController = TextEditingController(text: student.matricle);
    final _emailController = TextEditingController(text: student.email);
    String _selectedDepartment = student.department;
    String _selectedLevel = student.level;
    String _selectedGender = student.gender;

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Edit Student'),
        content: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextFormField(
                  controller: _nameController,
                  decoration: const InputDecoration(labelText: 'Full Name'),
                  validator: (value) => value?.isEmpty ?? true ? 'Required' : null,
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _matricleController,
                  decoration: const InputDecoration(labelText: 'Matricle Number'),
                  enabled: false, // Matricle shouldn't be editable
                ),
                const SizedBox(height: 16),
                DropdownButtonFormField<String>(
                  value: _selectedDepartment,
                  decoration: const InputDecoration(labelText: 'Department'),
                  items: [
                    'Computer Science',
                    'Electrical Engineering',
                    'Mechanical Engineering',
                    'Mathematics',
                    'Physics',
                    'Chemistry',
                  ].map((dept) => DropdownMenuItem(value: dept, child: Text(dept))).toList(),
                  onChanged: (value) => _selectedDepartment = value ?? '',
                  validator: (value) => value?.isEmpty ?? true ? 'Required' : null,
                ),
                const SizedBox(height: 16),
                DropdownButtonFormField<String>(
                  value: _selectedLevel,
                  decoration: const InputDecoration(labelText: 'Level'),
                  items: ['Level 100', 'Level 200', 'Level 300', 'Level 400']
                      .map((level) => DropdownMenuItem(value: level, child: Text(level)))
                      .toList(),
                  onChanged: (value) => _selectedLevel = value ?? '',
                  validator: (value) => value?.isEmpty ?? true ? 'Required' : null,
                ),
                const SizedBox(height: 16),
                DropdownButtonFormField<String>(
                  value: _selectedGender,
                  decoration: const InputDecoration(labelText: 'Gender'),
                  items: ['Male', 'Female', 'Other']
                      .map((gender) => DropdownMenuItem(value: gender, child: Text(gender)))
                      .toList(),
                  onChanged: (value) => _selectedGender = value ?? '',
                  validator: (value) => value?.isEmpty ?? true ? 'Required' : null,
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _emailController,
                  decoration: const InputDecoration(labelText: 'Email'),
                  keyboardType: TextInputType.emailAddress,
                  validator: (value) {
                    if (value?.isEmpty ?? true) return 'Required';
                    if (!value!.contains('@')) return 'Invalid email';
                    return null;
                  },
                ),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () async {
              if (_formKey.currentState?.validate() ?? false) {
                try {
                  final updatedStudent = Student(
                    name: _nameController.text,
                    matricle: student.matricle, // Keep original matricle
                    department: _selectedDepartment,
                    level: _selectedLevel,
                    gender: _selectedGender,
                    email: _emailController.text.toLowerCase(),
                  );
                  
                  await _dataService.updateStudent(updatedStudent);
                  final index = _students.indexWhere((s) => s.matricle == student.matricle);
                  if (index != -1) {
                    setState(() {
                      _students[index] = updatedStudent;
                    });
                    _filterStudents();
                  }
                  Navigator.pop(context);
                  _showAlert('Student updated successfully!');
                } catch (e) {
                  _showAlert('Error updating student: $e', isError: true);
                }
              }
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF667eea),
              foregroundColor: Colors.white,
            ),
            child: const Text('Update Student'),
          ),
        ],
      ),
    );
  }

  void _deleteStudent(String matricle) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Student'),
        content: Text('Are you sure you want to delete student $matricle? This action cannot be undone.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () async {
              try {
                await _dataService.deleteStudent(matricle);
                setState(() {
                  _students.removeWhere((student) => student.matricle == matricle);
                });
                _filterStudents();
                Navigator.pop(context);
                _showAlert('Student $matricle deleted successfully!');
              } catch (e) {
                Navigator.pop(context);
                _showAlert('Error deleting student: $e', isError: true);
              }
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
  }

  void _viewAttendance(Student student) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('${student.name} - Attendance'),
        content: SizedBox(
          width: double.maxFinite,
          height: 300,
          child: Column(
            children: [
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: const Color(0xFF667eea).withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    Column(
                      children: [
                        Text(
                          '87%',
                          style: TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                            color: const Color(0xFF667eea),
                          ),
                        ),
                        const Text('Overall'),
                      ],
                    ),
                    Column(
                      children: [
                        Text(
                          '23/25',
                          style: TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                            color: const Color(0xFF28a745),
                          ),
                        ),
                        const Text('Sessions'),
                      ],
                    ),
                    Column(
                      children: [
                        Text(
                          '2',
                          style: TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                            color: const Color(0xFFffc107),
                          ),
                        ),
                        const Text('Absences'),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              Expanded(
                child: ListView(
                  children: [
                    ListTile(
                      leading: const Icon(Icons.check_circle, color: Colors.green),
                      title: const Text('CS301 - Database Systems'),
                      subtitle: const Text('Today 10:00 AM'),
                      trailing: const Text('Present'),
                    ),
                    ListTile(
                      leading: const Icon(Icons.check_circle, color: Colors.green),
                      title: const Text('MATH201 - Linear Algebra'),
                      subtitle: const Text('Yesterday 2:00 PM'),
                      trailing: const Text('Present'),
                    ),
                    ListTile(
                      leading: const Icon(Icons.cancel, color: Colors.red),
                      title: const Text('PHY401 - Quantum Physics'),
                      subtitle: const Text('2 days ago 8:00 AM'),
                      trailing: const Text('Absent'),
                    ),
                    ListTile(
                      leading: const Icon(Icons.check_circle, color: Colors.green),
                      title: const Text('CS201 - Data Structures'),
                      subtitle: const Text('3 days ago 11:00 AM'),
                      trailing: const Text('Present'),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _showAlert('Generating attendance report...');
            },
            child: const Text('Generate Report'),
          ),
        ],
      ),
    );
  }

  void _viewEnrolledCourses(Student student) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('${student.name} - Enrolled Courses'),
        content: SizedBox(
          width: double.maxFinite,
          height: 300,
          child: ListView(
            children: [
              ListTile(
                leading: const CircleAvatar(
                  backgroundColor: Color(0xFF667eea),
                  child: Text('CS', style: TextStyle(color: Colors.white)),
                ),
                title: const Text('CS301 - Database Systems'),
                subtitle: const Text('Dr. Sarah Wilson • 3 Credits'),
                trailing: const Icon(Icons.arrow_forward_ios),
                onTap: () => _showAlert('Opening course details...'),
              ),
              ListTile(
                leading: const CircleAvatar(
                  backgroundColor: Color(0xFF28a745),
                  child: Text('MA', style: TextStyle(color: Colors.white)),
                ),
                title: const Text('MATH201 - Linear Algebra'),
                subtitle: const Text('Prof. Christopher Lee • 3 Credits'),
                trailing: const Icon(Icons.arrow_forward_ios),
                onTap: () => _showAlert('Opening course details...'),
              ),
              ListTile(
                leading: const CircleAvatar(
                  backgroundColor: Color(0xFF6f42c1),
                  child: Text('PH', style: TextStyle(color: Colors.white)),
                ),
                title: const Text('PHY401 - Quantum Physics'),
                subtitle: const Text('Dr. Amanda Garcia • 4 Credits'),
                trailing: const Icon(Icons.arrow_forward_ios),
                onTap: () => _showAlert('Opening course details...'),
              ),
              ListTile(
                leading: const CircleAvatar(
                  backgroundColor: Color(0xFF667eea),
                  child: Text('CS', style: TextStyle(color: Colors.white)),
                ),
                title: const Text('CS201 - Data Structures'),
                subtitle: const Text('Dr. Jennifer Martinez • 4 Credits'),
                trailing: const Icon(Icons.arrow_forward_ios),
                onTap: () => _showAlert('Opening course details...'),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _showAlert('Opening course enrollment...');
            },
            child: const Text('Manage Enrollment'),
          ),
        ],
      ),
    );
  }

  void _viewFullProfile(Student student) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('${student.name} - Full Profile'),
        content: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Center(
                child: CircleAvatar(
                  radius: 40,
                  backgroundColor: _getDepartmentColor(student.department),
                  child: Text(
                    student.name.split(' ').map((n) => n[0]).take(2).join(),
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 24,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              _buildProfileRow('Full Name', student.name),
              _buildProfileRow('Matricle Number', student.matricle),
              _buildProfileRow('Department', student.department),
              _buildProfileRow('Level', student.level),
              _buildProfileRow('Gender', student.gender),
              _buildProfileRow('Email', student.email),
              const SizedBox(height: 16),
              const Text(
                'Academic Information',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
              ),
              const SizedBox(height: 8),
              _buildProfileRow('Enrollment Date', 'September 2021'),
              _buildProfileRow('Expected Graduation', 'June 2025'),
              _buildProfileRow('Current GPA', '3.45'),
              _buildProfileRow('Credits Completed', '78/120'),
              _buildProfileRow('Academic Status', 'Good Standing'),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _editStudent(student);
            },
            child: const Text('Edit Profile'),
          ),
        ],
      ),
    );
  }

  Widget _buildProfileRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 120,
            child: Text(
              '$label:',
              style: const TextStyle(fontWeight: FontWeight.w500),
            ),
          ),
          Expanded(
            child: Text(value),
          ),
        ],
      ),
    );
  }

  void _viewContactInfo(Student student) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('${student.name} - Contact Information'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.email),
              title: const Text('Email'),
              subtitle: Text(student.email),
              trailing: IconButton(
                icon: const Icon(Icons.copy),
                onPressed: () {
                  Clipboard.setData(ClipboardData(text: student.email));
                  _showAlert('Email copied to clipboard');
                },
              ),
            ),
            ListTile(
              leading: const Icon(Icons.phone),
              title: const Text('Phone'),
              subtitle: const Text('+237 123 456 789'),
              trailing: IconButton(
                icon: const Icon(Icons.call),
                onPressed: () => _showAlert('Opening phone app...'),
              ),
            ),
            ListTile(
              leading: const Icon(Icons.home),
              title: const Text('Address'),
              subtitle: const Text('123 University Street, Douala, Cameroon'),
              trailing: IconButton(
                icon: const Icon(Icons.map),
                onPressed: () => _showAlert('Opening maps...'),
              ),
            ),
            ListTile(
              leading: const Icon(Icons.person),
              title: const Text('Emergency Contact'),
              subtitle: const Text('Parent: +237 987 654 321'),
              trailing: IconButton(
                icon: const Icon(Icons.call),
                onPressed: () => _showAlert('Calling emergency contact...'),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _showAlert('Opening messaging app...');
            },
            child: const Text('Send Message'),
          ),
        ],
      ),
    );
  }

  void _showBulkActions() {
    showModalBottomSheet(
      context: context,
      builder: (context) => Container(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              'Bulk Actions',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 20),
            ListTile(
              leading: const Icon(Icons.file_download),
              title: const Text('Export Students'),
              subtitle: const Text('Export to CSV or Excel'),
              onTap: () {
                Navigator.pop(context);
                _exportStudents();
              },
            ),
            ListTile(
              leading: const Icon(Icons.file_upload),
              title: const Text('Import Students'),
              subtitle: const Text('Import from CSV or Excel'),
              onTap: () {
                Navigator.pop(context);
                _importStudents();
              },
            ),
            ListTile(
              leading: const Icon(Icons.email),
              title: const Text('Send Bulk Email'),
              subtitle: const Text('Send notifications to all students'),
              onTap: () {
                Navigator.pop(context);
                _sendBulkEmail();
              },
            ),
            ListTile(
              leading: const Icon(Icons.assignment),
              title: const Text('Bulk Enrollment'),
              subtitle: const Text('Enroll students in courses'),
              onTap: () {
                Navigator.pop(context);
                _bulkEnrollment();
              },
            ),
            ListTile(
              leading: const Icon(Icons.analytics),
              title: const Text('Generate Reports'),
              subtitle: const Text('Student analytics and reports'),
              onTap: () {
                Navigator.pop(context);
                _generateReports();
              },
            ),
          ],
        ),
      ),
    );
  }

  void _exportStudents() {
    _showAlert('Exporting ${_filteredStudents.length} students to CSV...');
    // TODO: Implement actual export functionality
  }

  void _importStudents() {
    _showAlert('Opening file picker for student import...');
    // TODO: Implement actual import functionality
  }

  void _sendBulkEmail() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Send Bulk Email'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextFormField(
              decoration: const InputDecoration(
                labelText: 'Subject',
                hintText: 'Important Announcement',
              ),
            ),
            const SizedBox(height: 16),
            TextFormField(
              decoration: const InputDecoration(
                labelText: 'Message',
                hintText: 'Enter your message here...',
              ),
              maxLines: 4,
            ),
            const SizedBox(height: 16),
            Text('Recipients: ${_filteredStudents.length} students'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _showAlert('Sending email to ${_filteredStudents.length} students...');
            },
            child: const Text('Send Email'),
          ),
        ],
      ),
    );
  }

  void _bulkEnrollment() {
    _showAlert('Opening bulk enrollment interface...');
    // TODO: Implement bulk enrollment functionality
  }

  void _generateReports() {
    _showAlert('Generating student reports...');
    // TODO: Implement report generation functionality
  }

  void _showAlert(String message, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: isError ? Colors.red : Colors.green,
        duration: const Duration(seconds: 2),
        action: SnackBarAction(
          label: 'OK',
          textColor: Colors.white,
          onPressed: () {
            ScaffoldMessenger.of(context).hideCurrentSnackBar();
          },
        ),
      ),
    );
  }
}
