import 'package:flutter/material.dart';

class AdminLecturersScreen extends StatefulWidget {
  @override
  _AdminLecturersScreenState createState() => _AdminLecturersScreenState();
}

class _AdminLecturersScreenState extends State<AdminLecturersScreen> {
  final TextEditingController _searchController = TextEditingController();
  List<Map<String, dynamic>> _lecturers = [
    {
      'name': 'Dr. Robert Smith',
      'id': 'LECT001',
      'department': 'Computer Science',
      'courses': ['Introduction to Programming', 'Data Structures'],
    },
    {
      'name': 'Prof. Mary Johnson',
      'id': 'LECT002',
      'department': 'Electrical Engineering',
      'courses': ['Circuit Theory', 'Digital Electronics'],
    },
    {
      'name': 'Dr. James Wilson',
      'id': 'LECT003',
      'department': 'Mechanical Engineering',
      'courses': ['Thermodynamics', 'Fluid Mechanics'],
    },
  ];
  
  List<Map<String, dynamic>> _filteredLecturers = [];
  
  @override
  void initState() {
    super.initState();
    _filteredLecturers = List.from(_lecturers);
  }
  
  void _filterLecturers(String query) {
    setState(() {
      if (query.isEmpty) {
        _filteredLecturers = List.from(_lecturers);
      } else {
        _filteredLecturers = _lecturers
            .where((lecturer) =>
                lecturer['name'].toLowerCase().contains(query.toLowerCase()) ||
                lecturer['id'].toLowerCase().contains(query.toLowerCase()) ||
                lecturer['department'].toLowerCase().contains(query.toLowerCase()))
            .toList();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFF1A1A1A),
      body: SafeArea(
        child: Column(
          children: [
            // Header
            Container(
              padding: EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color(0xFF6C5CE7), Color(0xFF8B5CF6)],
                ),
              ),
              child: Row(
                children: [
                  Icon(Icons.menu, color: Colors.white, size: 24),
                  SizedBox(width: 16),
                  Expanded(
                    child: Text(
                      'Manage Lecturers',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  Icon(Icons.wb_sunny, color: Colors.white, size: 24),
                  SizedBox(width: 12),
                  CircleAvatar(
                    radius: 16,
                    backgroundColor: Colors.white.withOpacity(0.2),
                    child: Icon(Icons.person, color: Colors.white, size: 20),
                  ),
                ],
              ),
            ),
            
            // Search and Add
            Padding(
              padding: EdgeInsets.all(20),
              child: Row(
                children: [
                  Expanded(
                    child: Container(
                      decoration: BoxDecoration(
                        color: Color(0xFF2D2D2D),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: TextField(
                        controller: _searchController,
                        onChanged: _filterLecturers,
                        style: TextStyle(color: Colors.white),
                        decoration: InputDecoration(
                          hintText: 'Search lecturers...',
                          hintStyle: TextStyle(color: Colors.white54),
                          prefixIcon: Icon(Icons.search, color: Colors.white54),
                          border: InputBorder.none,
                          contentPadding: EdgeInsets.symmetric(vertical: 15),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(width: 12),
                  Container(
                    decoration: BoxDecoration(
                      color: Color(0xFF6C5CE7),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: IconButton(
                      icon: Icon(Icons.add, color: Colors.white),
                      onPressed: () => _showAddLecturerDialog(),
                    ),
                  ),
                ],
              ),
            ),
            
            // Lecturer List
            Expanded(
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 20),
                child: ListView.builder(
                  itemCount: _filteredLecturers.length,
                  itemBuilder: (context, index) {
                    final lecturer = _filteredLecturers[index];
                    return Container(
                      margin: EdgeInsets.only(bottom: 16),
                      decoration: BoxDecoration(
                        color: Color(0xFF2D2D2D),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Padding(
                        padding: EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        lecturer['name'],
                                        style: TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.bold,
                                          color: Colors.white,
                                        ),
                                      ),
                                      SizedBox(height: 4),
                                      Text(
                                        'ID: ${lecturer['id']} • ${lecturer['department']}',
                                        style: TextStyle(
                                          fontSize: 12,
                                          color: Colors.white70,
                                        ),
                                      ),
                                      SizedBox(height: 8),
                                      Text(
                                        'Courses: ${(lecturer['courses'] as List).join(", ")}',
                                        style: TextStyle(
                                          fontSize: 12,
                                          color: Colors.white70,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Row(
                                  children: [
                                    ElevatedButton(
                                      onPressed: () => _showEditLecturerDialog(lecturer, index),
                                      style: ElevatedButton.styleFrom(
                                        backgroundColor: Color(0xFF10B981),
                                        foregroundColor: Colors.white,
                                        minimumSize: Size(60, 36),
                                        shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(8),
                                        ),
                                      ),
                                      child: Text('Edit'),
                                    ),
                                    SizedBox(width: 8),
                                    ElevatedButton(
                                      onPressed: () => _deleteLecturer(index),
                                      style: ElevatedButton.styleFrom(
                                        backgroundColor: Color(0xFFEF4444),
                                        foregroundColor: Colors.white,
                                        minimumSize: Size(60, 36),
                                        shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(8),
                                        ),
                                      ),
                                      child: Text('Delete'),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showAddLecturerDialog() {
    final nameController = TextEditingController();
    final idController = TextEditingController();
    final departmentController = TextEditingController();
    final coursesController = TextEditingController();

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Color(0xFF2D2D2D),
        title: Text('Add Lecturer', style: TextStyle(color: Colors.white)),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: nameController,
                style: TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  labelText: 'Full Name',
                  labelStyle: TextStyle(color: Colors.white70),
                  enabledBorder: UnderlineInputBorder(
                    borderSide: BorderSide(color: Colors.white30),
                  ),
                  focusedBorder: UnderlineInputBorder(
                    borderSide: BorderSide(color: Color(0xFF6C5CE7)),
                  ),
                ),
              ),
              SizedBox(height: 16),
              TextField(
                controller: idController,
                style: TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  labelText: 'Lecturer ID',
                  labelStyle: TextStyle(color: Colors.white70),
                  enabledBorder: UnderlineInputBorder(
                    borderSide: BorderSide(color: Colors.white30),
                  ),
                  focusedBorder: UnderlineInputBorder(
                    borderSide: BorderSide(color: Color(0xFF6C5CE7)),
                  ),
                ),
              ),
              SizedBox(height: 16),
              TextField(
                controller: departmentController,
                style: TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  labelText: 'Department',
                  labelStyle: TextStyle(color: Colors.white70),
                  enabledBorder: UnderlineInputBorder(
                    borderSide: BorderSide(color: Colors.white30),
                  ),
                  focusedBorder: UnderlineInputBorder(
                    borderSide: BorderSide(color: Color(0xFF6C5CE7)),
                  ),
                ),
              ),
              SizedBox(height: 16),
              TextField(
                controller: coursesController,
                style: TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  labelText: 'Courses (comma separated)',
                  labelStyle: TextStyle(color: Colors.white70),
                  enabledBorder: UnderlineInputBorder(
                    borderSide: BorderSide(color: Colors.white30),
                  ),
                  focusedBorder: UnderlineInputBorder(
                    borderSide: BorderSide(color: Color(0xFF6C5CE7)),
                  ),
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel', style: TextStyle(color: Colors.white70)),
          ),
          ElevatedButton(
            onPressed: () {
              if (nameController.text.isNotEmpty &&
                  idController.text.isNotEmpty &&
                  departmentController.text.isNotEmpty) {
                setState(() {
                  _lecturers.add({
                    'name': nameController.text,
                    'id': idController.text,
                    'department': departmentController.text,
                    'courses': coursesController.text.split(',').map((e) => e.trim()).toList(),
                  });
                  _filteredLecturers = List.from(_lecturers);
                });
                Navigator.pop(context);
              }
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Color(0xFF6C5CE7),
            ),
            child: Text('Add'),
          ),
        ],
      ),
    );
  }

  void _showEditLecturerDialog(Map<String, dynamic> lecturer, int index) {
    final nameController = TextEditingController(text: lecturer['name']);
    final idController = TextEditingController(text: lecturer['id']);
    final departmentController = TextEditingController(text: lecturer['department']);
    final coursesController = TextEditingController(text: (lecturer['courses'] as List).join(', '));

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Color(0xFF2D2D2D),
        title: Text('Edit Lecturer', style: TextStyle(color: Colors.white)),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: nameController,
                style: TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  labelText: 'Full Name',
                  labelStyle: TextStyle(color: Colors.white70),
                  enabledBorder: UnderlineInputBorder(
                    borderSide: BorderSide(color: Colors.white30),
                  ),
                  focusedBorder: UnderlineInputBorder(
                    borderSide: BorderSide(color: Color(0xFF6C5CE7)),
                  ),
                ),
              ),
              SizedBox(height: 16),
              TextField(
                controller: idController,
                style: TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  labelText: 'Lecturer ID',
                  labelStyle: TextStyle(color: Colors.white70),
                  enabledBorder: UnderlineInputBorder(
                    borderSide: BorderSide(color: Colors.white30),
                  ),
                  focusedBorder: UnderlineInputBorder(
                    borderSide: BorderSide(color: Color(0xFF6C5CE7)),
                  ),
                ),
              ),
              SizedBox(height: 16),
              TextField(
                controller: departmentController,
                style: TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  labelText: 'Department',
                  labelStyle: TextStyle(color: Colors.white70),
                  enabledBorder: UnderlineInputBorder(
                    borderSide: BorderSide(color: Colors.white30),
                  ),
                  focusedBorder: UnderlineInputBorder(
                    borderSide: BorderSide(color: Color(0xFF6C5CE7)),
                  ),
                ),
              ),
              SizedBox(height: 16),
              TextField(
                controller: coursesController,
                style: TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  labelText: 'Courses (comma separated)',
                  labelStyle: TextStyle(color: Colors.white70),
                  enabledBorder: UnderlineInputBorder(
                    borderSide: BorderSide(color: Colors.white30),
                  ),
                  focusedBorder: UnderlineInputBorder(
                    borderSide: BorderSide(color: Color(0xFF6C5CE7)),
                  ),
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel', style: TextStyle(color: Colors.white70)),
          ),
          ElevatedButton(
            onPressed: () {
              if (nameController.text.isNotEmpty &&
                  idController.text.isNotEmpty &&
                  departmentController.text.isNotEmpty) {
                setState(() {
                  _lecturers[index] = {
                    'name': nameController.text,
                    'id': idController.text,
                    'department': departmentController.text,
                    'courses': coursesController.text.split(',').map((e) => e.trim()).toList(),
                  };
                  _filteredLecturers = List.from(_lecturers);
                });
                Navigator.pop(context);
              }
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Color(0xFF6C5CE7),
            ),
            child: Text('Save'),
          ),
        ],
      ),
    );
  }

  void _deleteLecturer(int index) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Color(0xFF2D2D2D),
        title: Text('Delete Lecturer', style: TextStyle(color: Colors.white)),
        content: Text(
          'Are you sure you want to delete this lecturer?',
          style: TextStyle(color: Colors.white70),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel', style: TextStyle(color: Colors.white70)),
          ),
          ElevatedButton(
            onPressed: () {
              setState(() {
                _lecturers.removeAt(index);
                _filteredLecturers = List.from(_lecturers);
              });
              Navigator.pop(context);
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Color(0xFFEF4444),
            ),
            child: Text('Delete'),
          ),
        ],
      ),
    );
  }
}
