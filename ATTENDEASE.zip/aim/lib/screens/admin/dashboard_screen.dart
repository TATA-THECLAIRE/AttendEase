import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../services/data_service.dart';

class DashboardScreen extends StatefulWidget {
  final Function(int) onNavigate;
  
  const DashboardScreen({Key? key, required this.onNavigate}) : super(key: key);

  @override
  _DashboardScreenState createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> with TickerProviderStateMixin {
  final DataService _dataService = DataService();
  Map<String, dynamic> _stats = {};
  bool _isLoading = true;
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );
    _fadeAnimation = CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    );
    _loadDashboardData();
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  Future<void> _loadDashboardData() async {
    try {
      final stats = await _dataService.getDashboardStats();
      setState(() {
        _stats = stats;
        _isLoading = false;
      });
      _animationController.forward();
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      _showAlert('Error loading dashboard data: $e', isError: true);
    }
  }

  Future<void> _refreshData() async {
    HapticFeedback.lightImpact();
    setState(() {
      _isLoading = true;
    });
    await _loadDashboardData();
    _showAlert('Dashboard refreshed successfully!');
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final screenHeight = MediaQuery.of(context).size.height;
    final isSmallScreen = screenWidth < 360;
    final isMediumScreen = screenWidth >= 360 && screenWidth < 600;
    
    if (_isLoading) {
      return const Center(
        child: CircularProgressIndicator(
          valueColor: AlwaysStoppedAnimation<Color>(Color(0xFF667eea)),
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: _refreshData,
      color: const Color(0xFF667eea),
      child: SingleChildScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: EdgeInsets.all(isSmallScreen ? 12 : 20),
        child: FadeTransition(
          opacity: _fadeAnimation,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Welcome Section
              Container(
                width: double.infinity,
                padding: EdgeInsets.all(isSmallScreen ? 15 : 20),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [Color(0xFF667eea), Color(0xFF764ba2)],
                  ),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Welcome back, Admin!',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: isSmallScreen ? 18 : 22,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 5),
                    Text(
                      'Here\'s what\'s happening with your attendance system today.',
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.9),
                        fontSize: isSmallScreen ? 12 : 14,
                      ),
                    ),
                    const SizedBox(height: 15),
                    Row(
                      children: [
                        Expanded(
                          child: ElevatedButton.icon(
                            onPressed: () => _showSystemStatus(),
                            icon: const Icon(Icons.health_and_safety, size: 16),
                            label: const Text('System Status'),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.white.withOpacity(0.2),
                              foregroundColor: Colors.white,
                              elevation: 0,
                            ),
                          ),
                        ),
                        const SizedBox(width: 10),
                        ElevatedButton(
                          onPressed: _refreshData,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.white.withOpacity(0.2),
                            foregroundColor: Colors.white,
                            elevation: 0,
                            shape: const CircleBorder(),
                            padding: const EdgeInsets.all(12),
                          ),
                          child: const Icon(Icons.refresh, size: 20),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              
              SizedBox(height: isSmallScreen ? 20 : 30),
              
              // Stats Row - Responsive
              Row(
                children: [
                  Expanded(child: _buildStatCard(
                    _stats['totalStudents']?.toString() ?? '0', 
                    'Total Students', 
                    Icons.people,
                    const Color(0xFF667eea),
                    isSmallScreen,
                    () => widget.onNavigate(1),
                  )),
                  SizedBox(width: isSmallScreen ? 8 : 12),
                  Expanded(child: _buildStatCard(
                    _stats['totalLecturers']?.toString() ?? '0', 
                    'Lecturers', 
                    Icons.school,
                    const Color(0xFF28a745),
                    isSmallScreen,
                    () => widget.onNavigate(2),
                  )),
                  SizedBox(width: isSmallScreen ? 8 : 12),
                  Expanded(child: _buildStatCard(
                    _stats['activeSessions']?.toString() ?? '0', 
                    'Active Sessions', 
                    Icons.play_circle,
                    const Color(0xFFffc107),
                    isSmallScreen,
                    () => widget.onNavigate(5),
                  )),
                ],
              ),
              
              SizedBox(height: isSmallScreen ? 20 : 30),
              
              // Quick Actions Section
              Text(
                'Quick Actions',
                style: TextStyle(
                  fontSize: isSmallScreen ? 16 : 18,
                  fontWeight: FontWeight.bold,
                  color: Theme.of(context).textTheme.bodyLarge?.color,
                ),
              ),
              
              SizedBox(height: isSmallScreen ? 15 : 20),
              
              // Dashboard Grid - Responsive
              GridView.count(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                crossAxisCount: isSmallScreen ? 1 : 2,
                crossAxisSpacing: isSmallScreen ? 10 : 15,
                mainAxisSpacing: isSmallScreen ? 10 : 15,
                childAspectRatio: isSmallScreen ? 3 : 1,
                children: [
                  _buildDashboardCard(
                    context,
                    Icons.people_alt,
                    'Manage Students',
                    'Add, edit, view students',
                    const Color(0xFF667eea),
                    () => widget.onNavigate(1),
                    isSmallScreen,
                  ),
                  _buildDashboardCard(
                    context,
                    Icons.school,
                    'Manage Lecturers',
                    'Add, assign lecturers',
                    const Color(0xFF28a745),
                    () => widget.onNavigate(2),
                    isSmallScreen,
                  ),
                  _buildDashboardCard(
                    context,
                    Icons.book,
                    'Manage Courses',
                    'Create, edit courses',
                    const Color(0xFFffc107),
                    () => widget.onNavigate(3),
                    isSmallScreen,
                  ),
                  _buildDashboardCard(
                    context,
                    Icons.location_on,
                    'Geofence Areas',
                    'Define class locations',
                    const Color(0xFF17a2b8),
                    () => widget.onNavigate(4),
                    isSmallScreen,
                  ),
                  _buildDashboardCard(
                    context,
                    Icons.analytics,
                    'Reports',
                    'View attendance data',
                    const Color(0xFF6f42c1),
                    () => widget.onNavigate(5),
                    isSmallScreen,
                  ),
                  _buildDashboardCard(
                    context,
                    Icons.settings,
                    'Settings',
                    'System configuration',
                    const Color(0xFF6c757d),
                    () => widget.onNavigate(6),
                    isSmallScreen,
                  ),
                ],
              ),
              
              SizedBox(height: isSmallScreen ? 20 : 30),
              
              // Recent Activity Section
              Text(
                'Recent Activity',
                style: TextStyle(
                  fontSize: isSmallScreen ? 16 : 18,
                  fontWeight: FontWeight.bold,
                  color: Theme.of(context).textTheme.bodyLarge?.color,
                ),
              ),
              
              SizedBox(height: isSmallScreen ? 15 : 20),
              
              _buildRecentActivityCard(isSmallScreen),
              
              SizedBox(height: screenHeight * 0.15), // Responsive bottom padding
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStatCard(String number, String label, IconData icon, Color color, bool isSmallScreen, VoidCallback onTap) {
    return GestureDetector(
      onTap: () {
        HapticFeedback.lightImpact();
        onTap();
      },
      child: Container(
        padding: EdgeInsets.all(isSmallScreen ? 10 : 15),
        decoration: BoxDecoration(
          color: Theme.of(context).cardColor,
          borderRadius: BorderRadius.circular(10),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.1),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
          border: Border.all(color: color.withOpacity(0.2), width: 1),
        ),
        child: Column(
          children: [
            Icon(icon, color: color, size: isSmallScreen ? 20 : 24),
            const SizedBox(height: 5),
            Text(
              number,
              style: TextStyle(
                fontSize: isSmallScreen ? 18 : 24,
                fontWeight: FontWeight.bold,
                color: color,
              ),
            ),
            SizedBox(height: isSmallScreen ? 3 : 5),
            Text(
              label,
              style: TextStyle(
                fontSize: isSmallScreen ? 10 : 12,
                color: Theme.of(context).textTheme.bodyMedium?.color,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDashboardCard(
    BuildContext context,
    IconData icon,
    String title,
    String subtitle,
    Color color,
    VoidCallback onTap,
    bool isSmallScreen,
  ) {
    return GestureDetector(
      onTap: () {
        HapticFeedback.lightImpact();
        onTap();
      },
      child: Container(
        padding: EdgeInsets.all(isSmallScreen ? 15 : 20),
        decoration: BoxDecoration(
          color: Theme.of(context).cardColor,
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.1),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
          border: Border.all(color: color.withOpacity(0.2), width: 2),
        ),
        child: isSmallScreen ? Row(
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: color.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(icon, color: color, size: 24),
            ),
            const SizedBox(width: 15),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                      color: Theme.of(context).textTheme.bodyLarge?.color,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    subtitle,
                    style: TextStyle(
                      fontSize: 11,
                      color: Theme.of(context).textTheme.bodyMedium?.color,
                    ),
                  ),
                ],
              ),
            ),
            Icon(Icons.arrow_forward_ios, color: color, size: 16),
          ],
        ) : Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: color.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(icon, color: color, size: 32),
            ),
            const SizedBox(height: 10),
            Text(
              title,
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w600,
                color: Theme.of(context).textTheme.bodyLarge?.color,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 5),
            Text(
              subtitle,
              style: TextStyle(
                fontSize: 12,
                color: Theme.of(context).textTheme.bodyMedium?.color,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRecentActivityCard(bool isSmallScreen) {
    return Container(
      padding: EdgeInsets.all(isSmallScreen ? 12 : 16),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Recent Activity',
                style: TextStyle(
                  fontSize: isSmallScreen ? 14 : 16,
                  fontWeight: FontWeight.bold,
                  color: Theme.of(context).textTheme.bodyLarge?.color,
                ),
              ),
              TextButton(
                onPressed: () => widget.onNavigate(5),
                child: const Text('View All'),
              ),
            ],
          ),
          const SizedBox(height: 10),
          _buildActivityItem(
            Icons.person_add,
            'New student registered',
            'John Doe - CS2024001',
            '2 hours ago',
            const Color(0xFF28a745),
            isSmallScreen,
          ),
          _buildActivityItem(
            Icons.check_circle,
            'Attendance session completed',
            'CS301 - Data Structures',
            '4 hours ago',
            const Color(0xFF667eea),
            isSmallScreen,
          ),
          _buildActivityItem(
            Icons.warning,
            'Low attendance alert',
            'MATH201 - 65% attendance',
            '1 day ago',
            const Color(0xFFffc107),
            isSmallScreen,
          ),
        ],
      ),
    );
  }

  Widget _buildActivityItem(IconData icon, String title, String subtitle, String time, Color color, bool isSmallScreen) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(icon, color: color, size: isSmallScreen ? 16 : 20),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    fontSize: isSmallScreen ? 12 : 14,
                    fontWeight: FontWeight.w600,
                    color: Theme.of(context).textTheme.bodyLarge?.color,
                  ),
                ),
                Text(
                  subtitle,
                  style: TextStyle(
                    fontSize: isSmallScreen ? 10 : 12,
                    color: Theme.of(context).textTheme.bodyMedium?.color,
                  ),
                ),
              ],
            ),
          ),
          Text(
            time,
            style: TextStyle(
              fontSize: isSmallScreen ? 10 : 12,
              color: Theme.of(context).textTheme.bodySmall?.color,
            ),
          ),
        ],
      ),
    );
  }

  void _showSystemStatus() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('System Status'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _buildStatusItem('Database', 'Online', Colors.green),
            _buildStatusItem('Face Recognition', 'Active', Colors.green),
            _buildStatusItem('Geofencing', 'Active', Colors.green),
            _buildStatusItem('Backup System', 'Running', Colors.green),
            _buildStatusItem('Storage', '85% Used', Colors.orange),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _showAlert('Running system diagnostics...');
            },
            child: const Text('Run Diagnostics'),
          ),
        ],
      ),
    );
  }

  Widget _buildStatusItem(String service, String status, Color color) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(service),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Text(
              status,
              style: TextStyle(
                color: color,
                fontSize: 12,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _showAlert(String message, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: isError ? Colors.red : Colors.green,
        duration: const Duration(seconds: 2),
      ),
    );
  }
}
