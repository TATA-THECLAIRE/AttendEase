import 'package:flutter/material.dart';

class AdminSettingsScreen extends StatefulWidget {
  @override
  _AdminSettingsScreenState createState() => _AdminSettingsScreenState();
}

class _AdminSettingsScreenState extends State<AdminSettingsScreen> {
  String _selectedSemester = 'First Semester';
  String _selectedTheme = 'Light Mode';
  double _faceRecognitionThreshold = 85;
  
  final TextEditingController _facultyNameController = TextEditingController(
    text: 'Faculty of Science and Technology'
  );
  
  final TextEditingController _sessionDurationController = TextEditingController(
    text: '120'
  );
  
  final TextEditingController _geofenceRadiusController = TextEditingController(
    text: '50'
  );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFF1A1A1A),
      body: SafeArea(
        child: Column(
          children: [
            // Header
            Container(
              padding: EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color(0xFF6C5CE7), Color(0xFF8B5CF6)],
                ),
              ),
              child: Row(
                children: [
                  Icon(Icons.menu, color: Colors.white, size: 24),
                  SizedBox(width: 16),
                  Expanded(
                    child: Text(
                      'System Settings',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  Icon(Icons.wb_sunny, color: Colors.white, size: 24),
                  SizedBox(width: 12),
                  CircleAvatar(
                    radius: 16,
                    backgroundColor: Colors.white.withOpacity(0.2),
                    child: Icon(Icons.person, color: Colors.white, size: 20),
                  ),
                ],
              ),
            ),
            
            // Settings Content
            Expanded(
              child: SingleChildScrollView(
                padding: EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildSettingLabel('Current Semester'),
                    _buildDropdownSetting(
                      value: _selectedSemester,
                      items: ['First Semester', 'Second Semester', 'Summer Semester'],
                      onChanged: (value) {
                        setState(() {
                          _selectedSemester = value!;
                        });
                      },
                    ),
                    
                    SizedBox(height: 20),
                    _buildSettingLabel('Faculty Name'),
                    _buildTextFieldSetting(_facultyNameController),
                    
                    SizedBox(height: 20),
                    _buildSettingLabel('Default Session Duration (minutes)'),
                    _buildTextFieldSetting(
                      _sessionDurationController,
                      keyboardType: TextInputType.number,
                    ),
                    
                    SizedBox(height: 20),
                    _buildSettingLabel('Geofence Default Radius (meters)'),
                    _buildTextFieldSetting(
                      _geofenceRadiusController,
                      keyboardType: TextInputType.number,
                    ),
                    
                    SizedBox(height: 20),
                    _buildSettingLabel('Face Recognition Confidence Threshold'),
                    Row(
                      children: [
                        Expanded(
                          child: Slider(
                            value: _faceRecognitionThreshold,
                            min: 50,
                            max: 100,
                            divisions: 50,
                            activeColor: Color(0xFF6C5CE7),
                            inactiveColor: Color(0xFF6C5CE7).withOpacity(0.3),
                            onChanged: (value) {
                              setState(() {
                                _faceRecognitionThreshold = value;
                              });
                            },
                          ),
                        ),
                        SizedBox(width: 12),
                        Text(
                          '${_faceRecognitionThreshold.toInt()}%',
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                    
                    SizedBox(height: 20),
                    _buildSettingLabel('App Theme'),
                    _buildDropdownSetting(
                      value: _selectedTheme,
                      items: ['Light Mode', 'Dark Mode', 'System Default'],
                      onChanged: (value) {
                        setState(() {
                          _selectedTheme = value!;
                        });
                      },
                    ),
                    
                    SizedBox(height: 32),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: _saveSettings,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Color(0xFF10B981),
                          padding: EdgeInsets.symmetric(vertical: 16),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                        child: Text(
                          'Save Settings',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSettingLabel(String label) {
    return Padding(
      padding: EdgeInsets.only(bottom: 8),
      child: Text(
        label,
        style: TextStyle(
          color: Colors.white,
          fontSize: 16,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  Widget _buildDropdownSetting({
    required String value,
    required List<String> items,
    required void Function(String?) onChanged,
  }) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 16),
      decoration: BoxDecoration(
        color: Color(0xFF2D2D2D),
        borderRadius: BorderRadius.circular(12),
      ),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          value: value,
          isExpanded: true,
          dropdownColor: Color(0xFF2D2D2D),
          style: TextStyle(color: Colors.white),
          icon: Icon(Icons.arrow_drop_down, color: Colors.white),
          items: items.map((String value) {
            return DropdownMenuItem<String>(
              value: value,
              child: Text(value),
            );
          }).toList(),
          onChanged: onChanged,
        ),
      ),
    );
  }

  Widget _buildTextFieldSetting(
    TextEditingController controller, {
    TextInputType keyboardType = TextInputType.text,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: Color(0xFF2D2D2D),
        borderRadius: BorderRadius.circular(12),
      ),
      child: TextField(
        controller: controller,
        keyboardType: keyboardType,
        style: TextStyle(color: Colors.white),
        decoration: InputDecoration(
          border: InputBorder.none,
          contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        ),
      ),
    );
  }

  void _saveSettings() {
    // Validate inputs
    if (_facultyNameController.text.isEmpty ||
        _sessionDurationController.text.isEmpty ||
        _geofenceRadiusController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Please fill in all fields'),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    // Show success message
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Settings saved successfully!'),
        backgroundColor: Color(0xFF10B981),
      ),
    );
  }
}
