import 'package:flutter/material.dart';

class AdminDashboardScreen extends StatefulWidget {
  final Function(int) onNavigate;
  
  AdminDashboardScreen({required this.onNavigate});
  
  @override
  _AdminDashboardScreenState createState() => _AdminDashboardScreenState();
}

class _AdminDashboardScreenState extends State<AdminDashboardScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFF1A1A1A),
      body: SafeArea(
        child: Column(
          children: [
            // Header
            Container(
              padding: EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color(0xFF6C5CE7), Color(0xFF8B5CF6)],
                ),
              ),
              child: Row(
                children: [
                  Icon(Icons.menu, color: Colors.white, size: 24),
                  SizedBox(width: 16),
                  Expanded(
                    child: Text(
                      'Admin Dashboard',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  Icon(Icons.wb_sunny, color: Colors.white, size: 24),
                  SizedBox(width: 12),
                  CircleAvatar(
                    radius: 16,
                    backgroundColor: Colors.white.withOpacity(0.2),
                    child: Icon(Icons.person, color: Colors.white, size: 20),
                  ),
                ],
              ),
            ),
            
            // Content
            Expanded(
              child: Padding(
                padding: EdgeInsets.all(20),
                child: Column(
                  children: [
                    // Stats Row
                    Row(
                      children: [
                        Expanded(
                          child: _buildStatCard('156', 'Total Students', Color(0xFF6C5CE7)),
                        ),
                        SizedBox(width: 12),
                        Expanded(
                          child: _buildStatCard('12', 'Lecturers', Color(0xFF10B981)),
                        ),
                        SizedBox(width: 12),
                        Expanded(
                          child: _buildStatCard('8', 'Active Sessions', Color(0xFFF59E0B)),
                        ),
                      ],
                    ),
                    
                    SizedBox(height: 24),
                    
                    // Action Cards Grid
                    Expanded(
                      child: GridView.count(
                        crossAxisCount: 2,
                        crossAxisSpacing: 16,
                        mainAxisSpacing: 16,
                        childAspectRatio: 1.2,
                        children: [
                          _buildActionCard(
                            'Manage Students',
                            'Add, edit, view students',
                            Icons.people,
                            Color(0xFF6C5CE7),
                            () => widget.onNavigate(1),
                          ),
                          _buildActionCard(
                            'Manage Lecturers',
                            'Add, assign lecturers',
                            Icons.school,
                            Color(0xFF10B981),
                            () => widget.onNavigate(2),
                          ),
                          _buildActionCard(
                            'Manage Courses',
                            'Create, edit courses',
                            Icons.book,
                            Color(0xFFF59E0B),
                            () => _showComingSoon(),
                          ),
                          _buildActionCard(
                            'Geofence Areas',
                            'Define class locations',
                            Icons.location_on,
                            Color(0xFF06B6D4),
                            () => _showComingSoon(),
                          ),
                          _buildActionCard(
                            'Reports',
                            'View attendance data',
                            Icons.bar_chart,
                            Color(0xFF8B5CF6),
                            () => widget.onNavigate(3),
                          ),
                          _buildActionCard(
                            'Settings',
                            'System configuration',
                            Icons.settings,
                            Color(0xFF6B7280),
                            () => widget.onNavigate(4),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatCard(String number, String label, Color color) {
    return Container(
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Color(0xFF2D2D2D),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Column(
        children: [
          Text(
            number,
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: color,
            ),
          ),
          SizedBox(height: 4),
          Text(
            label,
            style: TextStyle(
              fontSize: 12,
              color: Colors.white70,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildActionCard(String title, String subtitle, IconData icon, Color color, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Color(0xFF2D2D2D),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: color.withOpacity(0.3)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: color.withOpacity(0.2),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(icon, color: color, size: 24),
            ),
            SizedBox(height: 12),
            Text(
              title,
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
            SizedBox(height: 4),
            Text(
              subtitle,
              style: TextStyle(
                fontSize: 12,
                color: Colors.white70,
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showComingSoon() {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Feature coming soon!'),
        backgroundColor: Color(0xFF6C5CE7),
      ),
    );
  }
}
