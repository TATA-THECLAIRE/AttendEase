import 'package:flutter/material.dart';
import 'auth/welcome_screen.dart';

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // Redirect to welcome screen for authentication flow
    return WelcomeScreen();
  }
}
