import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../models/app_state.dart';
import '../services/data_service.dart';
import '../utils/responsive_helper.dart';

class GeofenceScreen extends StatefulWidget {
  const GeofenceScreen({Key? key}) : super(key: key);
  
  @override
  _GeofenceScreenState createState() => _GeofenceScreenState();
}

class _GeofenceScreenState extends State<GeofenceScreen> with TickerProviderStateMixin {
  final TextEditingController _searchController = TextEditingController();
  final DataService _dataService = DataService();
  
  List<GeofenceLocation> _locations = [];
  List<GeofenceLocation> _filteredLocations = [];
  bool _isLoading = true;
  
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 600),
      vsync: this,
    );
    _fadeAnimation = CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    );
    _loadGeofenceLocations();
    _searchController.addListener(_filterLocations);
  }

  @override
  void dispose() {
    _searchController.dispose();
    _animationController.dispose();
    super.dispose();
  }

  Future<void> _loadGeofenceLocations() async {
    try {
      final locations = await _dataService.getGeofenceLocations();
      setState(() {
        _locations = locations;
        _filteredLocations = locations;
        _isLoading = false;
      });
      _animationController.forward();
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      _showAlert('Error loading geofence locations: $e', isError: true);
    }
  }

  void _filterLocations() {
    final query = _searchController.text.toLowerCase();
    setState(() {
      _filteredLocations = _locations.where((location) {
        return location.name.toLowerCase().contains(query) ||
               location.description.toLowerCase().contains(query);
      }).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    final isSmallScreen = ResponsiveHelper.isSmallScreen(context);
    
    if (_isLoading) {
      return const Center(
        child: CircularProgressIndicator(
          valueColor: AlwaysStoppedAnimation<Color>(Color(0xFF667eea)),
        ),
      );
    }

    return Padding(
      padding: ResponsiveHelper.getResponsivePadding(context),
      child: FadeTransition(
        opacity: _fadeAnimation,
        child: Column(
          children: [
            // Header Section
            Container(
              padding: EdgeInsets.all(isSmallScreen ? 12 : 16),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color(0xFF17a2b8), Color(0xFF138496)],
                ),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Icon(Icons.location_on, color: Colors.white, size: 24),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          'Geofence Management',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: isSmallScreen ? 16 : 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      ElevatedButton.icon(
                        onPressed: _showMapView,
                        icon: const Icon(Icons.map, size: 16),
                        label: const Text('Map'),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.white.withOpacity(0.2),
                          foregroundColor: Colors.white,
                          elevation: 0,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Define and manage classroom locations for attendance tracking',
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.9),
                      fontSize: isSmallScreen ? 12 : 14,
                    ),
                  ),
                ],
              ),
            ),
            
            SizedBox(height: ResponsiveHelper.getResponsiveSpacing(context)),
            
            // Search and Actions
            Container(
              padding: EdgeInsets.all(isSmallScreen ? 12 : 16),
              decoration: BoxDecoration(
                color: Theme.of(context).cardColor,
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.1),
                    blurRadius: 8,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: Column(
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: TextField(
                          controller: _searchController,
                          decoration: InputDecoration(
                            hintText: 'Search locations...',
                            prefixIcon: const Icon(Icons.search),
                            suffixIcon: _searchController.text.isNotEmpty
                                ? IconButton(
                                    icon: const Icon(Icons.clear),
                                    onPressed: () {
                                      _searchController.clear();
                                      _filterLocations();
                                    },
                                  )
                                : null,
                            contentPadding: EdgeInsets.all(isSmallScreen ? 8 : 12),
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      PopupMenuButton<String>(
                        icon: const Icon(Icons.filter_list),
                        onSelected: _handleFilter,
                        itemBuilder: (context) => [
                          const PopupMenuItem(value: 'all', child: Text('All Locations')),
                          const PopupMenuItem(value: 'active', child: Text('Active Only')),
                          const PopupMenuItem(value: 'inactive', child: Text('Inactive Only')),
                          const PopupMenuItem(value: 'large', child: Text('Large Radius')),
                          const PopupMenuItem(value: 'small', child: Text('Small Radius')),
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: () => _showAddGeofenceDialog(),
                          icon: const Icon(Icons.add_location),
                          label: const Text('Add Location'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFF17a2b8),
                            foregroundColor: Colors.white,
                            padding: ResponsiveHelper.getResponsiveButtonPadding(context),
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      ElevatedButton.icon(
                        onPressed: _getCurrentLocation,
                        icon: const Icon(Icons.my_location),
                        label: const Text('Current'),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF28a745),
                          foregroundColor: Colors.white,
                          padding: ResponsiveHelper.getResponsiveButtonPadding(context),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            
            SizedBox(height: ResponsiveHelper.getResponsiveSpacing(context)),
            
            // Stats Row
            Row(
              children: [
                Expanded(
                  child: _buildStatCard(
                    _filteredLocations.length.toString(),
                    'Total Locations',
                    Icons.location_on,
                    const Color(0xFF17a2b8),
                    isSmallScreen,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _buildStatCard(
                    _filteredLocations.where((l) => l.isActive).length.toString(),
                    'Active',
                    Icons.check_circle,
                    const Color(0xFF28a745),
                    isSmallScreen,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _buildStatCard(
                    _filteredLocations.where((l) => !l.isActive).length.toString(),
                    'Inactive',
                    Icons.cancel,
                    const Color(0xFFdc3545),
                    isSmallScreen,
                  ),
                ),
              ],
            ),
            
            SizedBox(height: ResponsiveHelper.getResponsiveSpacing(context)),
            
            // Locations List
            Expanded(
              child: _filteredLocations.isEmpty
                  ? _buildEmptyState()
                  : ListView.builder(
                      itemCount: _filteredLocations.length,
                      itemBuilder: (context, index) {
                        final location = _filteredLocations[index];
                        return _buildLocationCard(location, isSmallScreen, index);
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatCard(String number, String label, IconData icon, Color color, bool isSmallScreen) {
    return Container(
      padding: EdgeInsets.all(isSmallScreen ? 10 : 12),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(8),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ],
        border: Border.all(color: color.withOpacity(0.2)),
      ),
      child: Column(
        children: [
          Icon(icon, color: color, size: isSmallScreen ? 16 : 20),
          const SizedBox(height: 4),
          Text(
            number,
            style: TextStyle(
              fontSize: isSmallScreen ? 16 : 20,
              fontWeight: FontWeight.bold,
              color: color,
            ),
          ),
          Text(
            label,
            style: TextStyle(
              fontSize: isSmallScreen ? 9 : 10,
              color: Theme.of(context).textTheme.bodyMedium?.color,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildLocationCard(GeofenceLocation location, bool isSmallScreen, int index) {
    return Container(
      margin: EdgeInsets.only(bottom: isSmallScreen ? 8 : 12),
      child: Card(
        elevation: 2,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        child: ExpansionTile(
          leading: Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: location.isActive 
                  ? const Color(0xFF28a745).withOpacity(0.1)
                  : const Color(0xFFdc3545).withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(
              Icons.location_on,
              color: location.isActive 
                  ? const Color(0xFF28a745)
                  : const Color(0xFFdc3545),
              size: isSmallScreen ? 20 : 24,
            ),
          ),
          title: Text(
            location.name,
            style: TextStyle(
              fontSize: isSmallScreen ? 13 : 14,
              fontWeight: FontWeight.w600,
              color: Theme.of(context).textTheme.bodyLarge?.color,
            ),
          ),
          subtitle: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                location.description,
                style: TextStyle(
                  fontSize: isSmallScreen ? 11 : 12,
                  color: Theme.of(context).textTheme.bodyMedium?.color,
                ),
              ),
              const SizedBox(height: 4),
              Row(
                children: [
                  Text(
                    'Radius: ${location.radius}m',
                    style: TextStyle(
                      fontSize: isSmallScreen ? 10 : 11,
                      color: Theme.of(context).textTheme.bodyMedium?.color,
                    ),
                  ),
                  const SizedBox(width: 10),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: location.isActive 
                          ? const Color(0xFFd4edda) 
                          : const Color(0xFFf8d7da),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      location.isActive ? 'Active' : 'Inactive',
                      style: TextStyle(
                        fontSize: 10,
                        fontWeight: FontWeight.w500,
                        color: location.isActive 
                            ? const Color(0xFF155724) 
                            : const Color(0xFF721c24),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
          trailing: PopupMenuButton<String>(
            onSelected: (value) => _handleLocationAction(value, location),
            itemBuilder: (context) => [
              const PopupMenuItem(value: 'edit', child: Text('Edit Location')),
              const PopupMenuItem(value: 'test', child: Text('Test Geofence')),
              const PopupMenuItem(value: 'toggle', child: Text('Toggle Status')),
              const PopupMenuItem(value: 'view', child: Text('View on Map')),
              const PopupMenuItem(value: 'duplicate', child: Text('Duplicate')),
              const PopupMenuItem(value: 'delete', child: Text('Delete')),
            ],
          ),
          children: [
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: _buildDetailItem('Latitude', location.latitude.toStringAsFixed(6), Icons.place),
                      ),
                      Expanded(
                        child: _buildDetailItem('Longitude', location.longitude.toStringAsFixed(6), Icons.place),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: _buildDetailItem('Radius', '${location.radius}m', Icons.radio_button_unchecked),
                      ),
                      Expanded(
                        child: _buildDetailItem('Status', location.isActive ? 'Active' : 'Inactive', Icons.info),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: () => _editGeofence(location),
                          icon: const Icon(Icons.edit, size: 16),
                          label: const Text('Edit'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFF17a2b8),
                            foregroundColor: Colors.white,
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: () => _testGeofence(location),
                          icon: const Icon(Icons.wifi_tethering, size: 16),
                          label: const Text('Test'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFF28a745),
                            foregroundColor: Colors.white,
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      ElevatedButton(
                        onPressed: () => _toggleLocationStatus(location),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: location.isActive 
                              ? const Color(0xFFffc107)
                              : const Color(0xFF28a745),
                          foregroundColor: Colors.white,
                          shape: const CircleBorder(),
                          padding: const EdgeInsets.all(12),
                        ),
                        child: Icon(
                          location.isActive ? Icons.pause : Icons.play_arrow,
                          size: 16,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDetailItem(String label, String value, IconData icon) {
    return Row(
      children: [
        Icon(icon, size: 16, color: Theme.of(context).textTheme.bodyMedium?.color),
        const SizedBox(width: 8),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              label,
              style: TextStyle(
                fontSize: 11,
                color: Theme.of(context).textTheme.bodyMedium?.color,
              ),
            ),
            Text(
              value,
              style: TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w600,
                color: Theme.of(context).textTheme.bodyLarge?.color,
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.location_off,
            size: 64,
            color: Colors.grey[400],
          ),
          const SizedBox(height: 16),
          Text(
            'No geofence locations found',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w600,
              color: Colors.grey[600],
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Add your first location to get started',
            style: TextStyle(
              fontSize: 14,
              color: Colors.grey[500],
            ),
          ),
          const SizedBox(height: 24),
          ElevatedButton.icon(
            onPressed: () => _showAddGeofenceDialog(),
            icon: const Icon(Icons.add_location),
            label: const Text('Add Location'),
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF17a2b8),
              foregroundColor: Colors.white,
            ),
          ),
        ],
      ),
    );
  }

  void _handleFilter(String filter) {
    setState(() {
      switch (filter) {
        case 'all':
          _filteredLocations = _locations;
          break;
        case 'active':
          _filteredLocations = _locations.where((l) => l.isActive).toList();
          break;
        case 'inactive':
          _filteredLocations = _locations.where((l) => !l.isActive).toList();
          break;
        case 'large':
          _filteredLocations = _locations.where((l) => l.radius > 50).toList();
          break;
        case 'small':
          _filteredLocations = _locations.where((l) => l.radius <= 50).toList();
          break;
      }
    });
    _showAlert('Filter applied: $filter');
  }

  void _handleLocationAction(String action, GeofenceLocation location) {
    HapticFeedback.lightImpact();
    switch (action) {
      case 'edit':
        _editGeofence(location);
        break;
      case 'test':
        _testGeofence(location);
        break;
      case 'toggle':
        _toggleLocationStatus(location);
        break;
      case 'view':
        _viewOnMap(location);
        break;
      case 'duplicate':
        _duplicateLocation(location);
        break;
      case 'delete':
        _deleteGeofence(location.name);
        break;
    }
  }

  void _showAddGeofenceDialog() {
    final _formKey = GlobalKey<FormState>();
    final _nameController = TextEditingController();
    final _latController = TextEditingController();
    final _lngController = TextEditingController();
    final _radiusController = TextEditingController(text: '50');
    final _descController = TextEditingController();

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Add Geofence Location'),
        content: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextFormField(
                  controller: _nameController,
                  decoration: const InputDecoration(
                    labelText: 'Location Name',
                    hintText: 'e.g., Lecture Hall A',
                  ),
                  validator: (value) => value?.isEmpty ?? true ? 'Required' : null,
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: TextFormField(
                        controller: _latController,
                        decoration: const InputDecoration(
                          labelText: 'Latitude',
                          hintText: '5.9547',
                        ),
                        keyboardType: const TextInputType.numberWithOptions(decimal: true),
                        validator: (value) {
                          if (value?.isEmpty ?? true) return 'Required';
                          final lat = double.tryParse(value!);
                          if (lat == null || lat < -90 || lat > 90) {
                            return 'Invalid latitude';
                          }
                          return null;
                        },
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: TextFormField(
                        controller: _lngController,
                        decoration: const InputDecoration(
                          labelText: 'Longitude',
                          hintText: '10.1697',
                        ),
                        keyboardType: const TextInputType.numberWithOptions(decimal: true),
                        validator: (value) {
                          if (value?.isEmpty ?? true) return 'Required';
                          final lng = double.tryParse(value!);
                          if (lng == null || lng < -180 || lng > 180) {
                            return 'Invalid longitude';
                          }
                          return null;
                        },
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _radiusController,
                  decoration: const InputDecoration(
                    labelText: 'Radius (meters)',
                    hintText: '50',
                  ),
                  keyboardType: TextInputType.number,
                  validator: (value) {
                    if (value?.isEmpty ?? true) return 'Required';
                    final radius = int.tryParse(value!);
                    if (radius == null || radius < 10 || radius > 1000) {
                      return 'Must be between 10-1000 meters';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _descController,
                  decoration: const InputDecoration(
                    labelText: 'Description',
                    hintText: 'Main lecture hall for CS courses',
                  ),
                  maxLines: 2,
                ),
                const SizedBox(height: 16),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    onPressed: () => _getCurrentLocationCoordinates(_latController, _lngController),
                    icon: const Icon(Icons.my_location),
                    label: const Text('Use Current Location'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF6c757d),
                      foregroundColor: Colors.white,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () async {
              if (_formKey.currentState?.validate() ?? false) {
                try {
                  final newLocation = GeofenceLocation(
                    name: _nameController.text,
                    latitude: double.parse(_latController.text),
                    longitude: double.parse(_lngController.text),
                    radius: int.parse(_radiusController.text),
                    description: _descController.text.isEmpty 
                        ? 'No description provided' 
                        : _descController.text,
                  );
                  
                  await _dataService.addGeofenceLocation(newLocation);
                  setState(() {
                    _locations.add(newLocation);
                  });
                  _filterLocations();
                  Navigator.pop(context);
                  _showAlert('Geofence location added successfully!');
                } catch (e) {
                  _showAlert('Error adding location: $e', isError: true);
                }
              }
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF17a2b8),
              foregroundColor: Colors.white,
            ),
            child: const Text('Add Location'),
          ),
        ],
      ),
    );
  }

  void _getCurrentLocationCoordinates(TextEditingController latController, TextEditingController lngController) {
    // Simulate getting current location
    latController.text = '5.9547';
    lngController.text = '10.1697';
    _showAlert('Current location captured!');
  }

  void _getCurrentLocation() {
    _showAlert('Getting current location...');
    // TODO: Implement actual location services
  }

  void _editGeofence(GeofenceLocation location) {
    final _formKey = GlobalKey<FormState>();
    final _nameController = TextEditingController(text: location.name);
    final _latController = TextEditingController(text: location.latitude.toString());
    final _lngController = TextEditingController(text: location.longitude.toString());
    final _radiusController = TextEditingController(text: location.radius.toString());
    final _descController = TextEditingController(text: location.description);

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Edit Geofence Location'),
        content: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextFormField(
                  controller: _nameController,
                  decoration: const InputDecoration(labelText: 'Location Name'),
                  validator: (value) => value?.isEmpty ?? true ? 'Required' : null,
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: TextFormField(
                        controller: _latController,
                        decoration: const InputDecoration(labelText: 'Latitude'),
                        keyboardType: const TextInputType.numberWithOptions(decimal: true),
                        validator: (value) {
                          if (value?.isEmpty ?? true) return 'Required';
                          final lat = double.tryParse(value!);
                          if (lat == null || lat < -90 || lat > 90) {
                            return 'Invalid latitude';
                          }
                          return null;
                        },
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: TextFormField(
                        controller: _lngController,
                        decoration: const InputDecoration(labelText: 'Longitude'),
                        keyboardType: const TextInputType.numberWithOptions(decimal: true),
                        validator: (value) {
                          if (value?.isEmpty ?? true) return 'Required';
                          final lng = double.tryParse(value!);
                          if (lng == null || lng < -180 || lng > 180) {
                            return 'Invalid longitude';
                          }
                          return null;
                        },
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _radiusController,
                  decoration: const InputDecoration(labelText: 'Radius (meters)'),
                  keyboardType: TextInputType.number,
                  validator: (value) {
                    if (value?.isEmpty ?? true) return 'Required';
                    final radius = int.tryParse(value!);
                    if (radius == null || radius < 10 || radius > 1000) {
                      return 'Must be between 10-1000 meters';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _descController,
                  decoration: const InputDecoration(labelText: 'Description'),
                  maxLines: 2,
                ),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () async {
              if (_formKey.currentState?.validate() ?? false) {
                try {
                  final updatedLocation = GeofenceLocation(
                    name: _nameController.text,
                    latitude: double.parse(_latController.text),
                    longitude: double.parse(_lngController.text),
                    radius: int.parse(_radiusController.text),
                    description: _descController.text,
                    isActive: location.isActive,
                  );
                  
                  await _dataService.updateGeofenceLocation(updatedLocation);
                  final index = _locations.indexWhere((l) => l.name == location.name);
                  if (index != -1) {
                    setState(() {
                      _locations[index] = updatedLocation;
                    });
                    _filterLocations();
                  }
                  Navigator.pop(context);
                  _showAlert('Location updated successfully!');
                } catch (e) {
                  _showAlert('Error updating location: $e', isError: true);
                }
              }
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF17a2b8),
              foregroundColor: Colors.white,
            ),
            child: const Text('Update Location'),
          ),
        ],
      ),
    );
  }

  void _testGeofence(GeofenceLocation location) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Testing ${location.name}'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const CircularProgressIndicator(),
            const SizedBox(height: 16),
            const Text('Testing geofence signal...'),
            const SizedBox(height: 16),
            Text('Location: ${location.name}'),
            Text('Radius: ${location.radius}m'),
            Text('Coordinates: ${location.latitude.toStringAsFixed(4)}, ${location.longitude.toStringAsFixed(4)}'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
        ],
      ),
    );
    
    // Simulate test completion
    Future.delayed(const Duration(seconds: 3), () {
      Navigator.pop(context);
      _showTestResults(location);
    });
  }

  void _showTestResults(GeofenceLocation location) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Test Results'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildTestResultItem('Signal Strength', 'Excellent', Colors.green),
            _buildTestResultItem('GPS Accuracy', '±3 meters', Colors.green),
            _buildTestResultItem('Geofence Status', 'Active', Colors.green),
            _buildTestResultItem('Response Time', '0.8 seconds', Colors.green),
            _buildTestResultItem('Coverage Area', '${location.radius}m radius', Colors.blue),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _showAlert('Test report saved to system logs');
            },
            child: const Text('Save Report'),
          ),
        ],
      ),
    );
  }

  Widget _buildTestResultItem(String label, String value, Color color) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Text(
              value,
              style: TextStyle(
                color: color,
                fontSize: 12,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _toggleLocationStatus(GeofenceLocation location) {
    setState(() {
      final index = _locations.indexWhere((l) => l.name == location.name);
      if (index != -1) {
        _locations[index] = GeofenceLocation(
          name: location.name,
          latitude: location.latitude,
          longitude: location.longitude,
          radius: location.radius,
          description: location.description,
          isActive: !location.isActive,
        );
      }
    });
    _filterLocations();
    _showAlert('${location.name} ${location.isActive ? 'deactivated' : 'activated'}');
  }

  void _viewOnMap(GeofenceLocation location) {
    _showAlert('Opening ${location.name} on map...');
    // TODO: Implement map view
  }

  void _duplicateLocation(GeofenceLocation location) {
    final duplicatedLocation = GeofenceLocation(
      name: '${location.name} (Copy)',
      latitude: location.latitude + 0.001, // Slight offset
      longitude: location.longitude + 0.001,
      radius: location.radius,
      description: '${location.description} (Duplicate)',
      isActive: false,
    );
    
    setState(() {
      _locations.add(duplicatedLocation);
    });
    _filterLocations();
    _showAlert('Location duplicated successfully');
  }

  void _deleteGeofence(String locationName) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Location'),
        content: Text('Are you sure you want to delete "$locationName"? This action cannot be undone.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () async {
              try {
                await _dataService.deleteGeofenceLocation(locationName);
                setState(() {
                  _locations.removeWhere((location) => location.name == locationName);
                });
                _filterLocations();
                Navigator.pop(context);
                _showAlert('Location "$locationName" deleted successfully!');
              } catch (e) {
                Navigator.pop(context);
                _showAlert('Error deleting location: $e', isError: true);
              }
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
  }

  void _showMapView() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Map View'),
        content: Container(
          width: double.maxFinite,
          height: 300,
          decoration: BoxDecoration(
            color: Colors.grey[200],
            borderRadius: BorderRadius.circular(8),
          ),
          child: const Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.map, size: 64, color: Colors.grey),
                SizedBox(height: 16),
                Text('Interactive Map View'),
                Text('(Map integration coming soon)'),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _showAlert('Opening full-screen map...');
            },
            child: const Text('Full Screen'),
          ),
        ],
      ),
    );
  }

  void _showAlert(String message, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: isError ? Colors.red : Colors.green,
        duration: const Duration(seconds: 2),
        action: SnackBarAction(
          label: 'OK',
          textColor: Colors.white,
          onPressed: () {
            ScaffoldMessenger.of(context).hideCurrentSnackBar();
          },
        ),
      ),
    );
  }
}
