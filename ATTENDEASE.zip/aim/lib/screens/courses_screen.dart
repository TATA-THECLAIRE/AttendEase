import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../models/app_state.dart';
import '../services/data_service.dart';
import '../utils/responsive_helper.dart';

class CoursesScreen extends StatefulWidget {
  const CoursesScreen({Key? key}) : super(key: key);
  
  @override
  _CoursesScreenState createState() => _CoursesScreenState();
}

class _CoursesScreenState extends State<CoursesScreen> with TickerProviderStateMixin {
  final TextEditingController _searchController = TextEditingController();
  final DataService _dataService = DataService();
  
  List<Course> _courses = [];
  List<Course> _filteredCourses = [];
  bool _isLoading = true;
  String _sortBy = 'code';
  bool _sortAscending = true;
  
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 600),
      vsync: this,
    );
    _fadeAnimation = CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    );
    _loadCourses();
    _searchController.addListener(_filterCourses);
  }

  @override
  void dispose() {
    _searchController.dispose();
    _animationController.dispose();
    super.dispose();
  }

  Future<void> _loadCourses() async {
    try {
      final courses = await _dataService.getCourses();
      setState(() {
        _courses = courses;
        _filteredCourses = courses;
        _isLoading = false;
      });
      _animationController.forward();
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      _showAlert('Error loading courses: $e', isError: true);
    }
  }

  void _filterCourses() {
    final query = _searchController.text.toLowerCase();
    setState(() {
      _filteredCourses = _courses.where((course) {
        return course.title.toLowerCase().contains(query) ||
               course.code.toLowerCase().contains(query) ||
               course.department.toLowerCase().contains(query) ||
               course.lecturer.toLowerCase().contains(query);
      }).toList();
    });
    _sortCourses();
  }

  void _sortCourses() {
    setState(() {
      _filteredCourses.sort((a, b) {
        int result;
        switch (_sortBy) {
          case 'code':
            result = a.code.compareTo(b.code);
            break;
          case 'title':
            result = a.title.compareTo(b.title);
            break;
          case 'department':
            result = a.department.compareTo(b.department);
            break;
          case 'level':
            result = a.level.compareTo(b.level);
            break;
          default:
            result = a.code.compareTo(b.code);
        }
        return _sortAscending ? result : -result;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    final isSmallScreen = ResponsiveHelper.isSmallScreen(context);
    
    if (_isLoading) {
      return const Center(
        child: CircularProgressIndicator(
          valueColor: AlwaysStoppedAnimation<Color>(Color(0xFF667eea)),
        ),
      );
    }

    return Padding(
      padding: ResponsiveHelper.getResponsivePadding(context),
      child: FadeTransition(
        opacity: _fadeAnimation,
        child: Column(
          children: [
            // Search and Filter Section
            Container(
              padding: EdgeInsets.all(isSmallScreen ? 12 : 16),
              decoration: BoxDecoration(
                color: Theme.of(context).cardColor,
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.1),
                    blurRadius: 8,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: Column(
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: TextField(
                          controller: _searchController,
                          decoration: InputDecoration(
                            hintText: 'Search courses...',
                            prefixIcon: const Icon(Icons.search),
                            suffixIcon: _searchController.text.isNotEmpty
                                ? IconButton(
                                    icon: const Icon(Icons.clear),
                                    onPressed: () {
                                      _searchController.clear();
                                      _filterCourses();
                                    },
                                  )
                                : null,
                            contentPadding: EdgeInsets.all(isSmallScreen ? 8 : 12),
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      PopupMenuButton<String>(
                        icon: const Icon(Icons.sort),
                        onSelected: (value) {
                          setState(() {
                            if (_sortBy == value) {
                              _sortAscending = !_sortAscending;
                            } else {
                              _sortBy = value;
                              _sortAscending = true;
                            }
                          });
                          _sortCourses();
                        },
                        itemBuilder: (context) => [
                          const PopupMenuItem(value: 'code', child: Text('Sort by Code')),
                          const PopupMenuItem(value: 'title', child: Text('Sort by Title')),
                          const PopupMenuItem(value: 'department', child: Text('Sort by Department')),
                          const PopupMenuItem(value: 'level', child: Text('Sort by Level')),
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: () => _showAddCourseDialog(),
                          icon: const Icon(Icons.add),
                          label: const Text('Add Course'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFF667eea),
                            foregroundColor: Colors.white,
                            padding: ResponsiveHelper.getResponsiveButtonPadding(context),
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      ElevatedButton.icon(
                        onPressed: _showBulkActions,
                        icon: const Icon(Icons.more_vert),
                        label: const Text('Bulk'),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF6c757d),
                          foregroundColor: Colors.white,
                          padding: ResponsiveHelper.getResponsiveButtonPadding(context),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            
            SizedBox(height: ResponsiveHelper.getResponsiveSpacing(context)),
            
            // Stats Row
            Row(
              children: [
                Expanded(
                  child: _buildStatCard(
                    _filteredCourses.length.toString(),
                    'Total Courses',
                    Icons.book,
                    const Color(0xFF667eea),
                    isSmallScreen,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _buildStatCard(
                    _filteredCourses.where((c) => c.semester == 'First Semester').length.toString(),
                    'First Semester',
                    Icons.calendar_today,
                    const Color(0xFF28a745),
                    isSmallScreen,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _buildStatCard(
                    _filteredCourses.where((c) => c.semester == 'Second Semester').length.toString(),
                    'Second Semester',
                    Icons.calendar_month,
                    const Color(0xFFffc107),
                    isSmallScreen,
                  ),
                ),
              ],
            ),
            
            SizedBox(height: ResponsiveHelper.getResponsiveSpacing(context)),
            
            // Courses List
            Expanded(
              child: _filteredCourses.isEmpty
                  ? _buildEmptyState()
                  : ListView.builder(
                      itemCount: _filteredCourses.length,
                      itemBuilder: (context, index) {
                        final course = _filteredCourses[index];
                        return _buildCourseCard(course, isSmallScreen, index);
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatCard(String number, String label, IconData icon, Color color, bool isSmallScreen) {
    return Container(
      padding: EdgeInsets.all(isSmallScreen ? 10 : 12),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(8),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ],
        border: Border.all(color: color.withOpacity(0.2)),
      ),
      child: Column(
        children: [
          Icon(icon, color: color, size: isSmallScreen ? 16 : 20),
          const SizedBox(height: 4),
          Text(
            number,
            style: TextStyle(
              fontSize: isSmallScreen ? 16 : 20,
              fontWeight: FontWeight.bold,
              color: color,
            ),
          ),
          Text(
            label,
            style: TextStyle(
              fontSize: isSmallScreen ? 9 : 10,
              color: Theme.of(context).textTheme.bodyMedium?.color,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildCourseCard(Course course, bool isSmallScreen, int index) {
    return Container(
      margin: EdgeInsets.only(bottom: isSmallScreen ? 8 : 12),
      child: Card(
        elevation: 2,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        child: ExpansionTile(
          leading: Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: _getCourseColor(course.department).withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(
              Icons.book,
              color: _getCourseColor(course.department),
              size: isSmallScreen ? 20 : 24,
            ),
          ),
          title: Text(
            course.title,
            style: TextStyle(
              fontSize: isSmallScreen ? 13 : 14,
              fontWeight: FontWeight.w600,
              color: Theme.of(context).textTheme.bodyLarge?.color,
            ),
          ),
          subtitle: Text(
            '${course.code} • ${course.department} • ${course.level}',
            style: TextStyle(
              fontSize: isSmallScreen ? 11 : 12,
              color: Theme.of(context).textTheme.bodyMedium?.color,
            ),
          ),
          trailing: PopupMenuButton<String>(
            onSelected: (value) => _handleCourseAction(value, course),
            itemBuilder: (context) => [
              const PopupMenuItem(value: 'edit', child: Text('Edit Course')),
              const PopupMenuItem(value: 'assign', child: Text('Assign Lecturer')),
              const PopupMenuItem(value: 'students', child: Text('View Students')),
              const PopupMenuItem(value: 'schedule', child: Text('Set Schedule')),
              const PopupMenuItem(value: 'duplicate', child: Text('Duplicate')),
              const PopupMenuItem(value: 'delete', child: Text('Delete')),
            ],
          ),
          children: [
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: _buildDetailItem('Credit Units', '${course.creditUnits}', Icons.credit_card),
                      ),
                      Expanded(
                        child: _buildDetailItem('Semester', course.semester, Icons.calendar_today),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  _buildDetailItem('Lecturer', course.lecturer, Icons.person),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: () => _editCourse(course),
                          icon: const Icon(Icons.edit, size: 16),
                          label: const Text('Edit'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFF667eea),
                            foregroundColor: Colors.white,
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: () => _viewCourseDetails(course),
                          icon: const Icon(Icons.visibility, size: 16),
                          label: const Text('Details'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFF28a745),
                            foregroundColor: Colors.white,
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      ElevatedButton(
                        onPressed: () => _deleteCourse(course.code),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFFdc3545),
                          foregroundColor: Colors.white,
                          shape: const CircleBorder(),
                          padding: const EdgeInsets.all(12),
                        ),
                        child: const Icon(Icons.delete, size: 16),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDetailItem(String label, String value, IconData icon) {
    return Row(
      children: [
        Icon(icon, size: 16, color: Theme.of(context).textTheme.bodyMedium?.color),
        const SizedBox(width: 8),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              label,
              style: TextStyle(
                fontSize: 11,
                color: Theme.of(context).textTheme.bodyMedium?.color,
              ),
            ),
            Text(
              value,
              style: TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w600,
                color: Theme.of(context).textTheme.bodyLarge?.color,
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.book_outlined,
            size: 64,
            color: Colors.grey[400],
          ),
          const SizedBox(height: 16),
          Text(
            'No courses found',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w600,
              color: Colors.grey[600],
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Add your first course to get started',
            style: TextStyle(
              fontSize: 14,
              color: Colors.grey[500],
            ),
          ),
          const SizedBox(height: 24),
          ElevatedButton.icon(
            onPressed: () => _showAddCourseDialog(),
            icon: const Icon(Icons.add),
            label: const Text('Add Course'),
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF667eea),
              foregroundColor: Colors.white,
            ),
          ),
        ],
      ),
    );
  }

  Color _getCourseColor(String department) {
    switch (department.toLowerCase()) {
      case 'computer science':
        return const Color(0xFF667eea);
      case 'mathematics':
        return const Color(0xFF28a745);
      case 'physics':
        return const Color(0xFF6f42c1);
      case 'electrical engineering':
        return const Color(0xFFffc107);
      case 'mechanical engineering':
        return const Color(0xFF17a2b8);
      default:
        return const Color(0xFF6c757d);
    }
  }

  void _handleCourseAction(String action, Course course) {
    HapticFeedback.lightImpact();
    switch (action) {
      case 'edit':
        _editCourse(course);
        break;
      case 'assign':
        _assignLecturer(course);
        break;
      case 'students':
        _viewEnrolledStudents(course);
        break;
      case 'schedule':
        _setCourseSchedule(course);
        break;
      case 'duplicate':
        _duplicateCourse(course);
        break;
      case 'delete':
        _deleteCourse(course.code);
        break;
    }
  }

  void _showAddCourseDialog() {
    final _formKey = GlobalKey<FormState>();
    final _codeController = TextEditingController();
    final _titleController = TextEditingController();
    final _creditController = TextEditingController();
    String _selectedDepartment = '';
    String _selectedLevel = '';
    String _selectedSemester = '';

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Add New Course'),
        content: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextFormField(
                  controller: _codeController,
                  decoration: const InputDecoration(
                    labelText: 'Course Code',
                    hintText: 'e.g., CS301',
                  ),
                  validator: (value) => value?.isEmpty ?? true ? 'Required' : null,
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _titleController,
                  decoration: const InputDecoration(
                    labelText: 'Course Title',
                    hintText: 'e.g., Data Structures & Algorithms',
                  ),
                  validator: (value) => value?.isEmpty ?? true ? 'Required' : null,
                ),
                const SizedBox(height: 16),
                DropdownButtonFormField<String>(
                  decoration: const InputDecoration(labelText: 'Department'),
                  items: [
                    'Computer Science',
                    'Electrical Engineering',
                    'Mechanical Engineering',
                    'Mathematics',
                    'Physics',
                    'Chemistry',
                  ].map((dept) => DropdownMenuItem(value: dept, child: Text(dept))).toList(),
                  onChanged: (value) => _selectedDepartment = value ?? '',
                  validator: (value) => value?.isEmpty ?? true ? 'Required' : null,
                ),
                const SizedBox(height: 16),
                DropdownButtonFormField<String>(
                  decoration: const InputDecoration(labelText: 'Level'),
                  items: ['Level 100', 'Level 200', 'Level 300', 'Level 400']
                      .map((level) => DropdownMenuItem(value: level, child: Text(level)))
                      .toList(),
                  onChanged: (value) => _selectedLevel = value ?? '',
                  validator: (value) => value?.isEmpty ?? true ? 'Required' : null,
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _creditController,
                  decoration: const InputDecoration(
                    labelText: 'Credit Units',
                    hintText: '1-6',
                  ),
                  keyboardType: TextInputType.number,
                  validator: (value) {
                    if (value?.isEmpty ?? true) return 'Required';
                    final credit = int.tryParse(value!);
                    if (credit == null || credit < 1 || credit > 6) {
                      return 'Must be between 1-6';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16),
                DropdownButtonFormField<String>(
                  decoration: const InputDecoration(labelText: 'Semester'),
                  items: ['First Semester', 'Second Semester']
                      .map((sem) => DropdownMenuItem(value: sem, child: Text(sem)))
                      .toList(),
                  onChanged: (value) => _selectedSemester = value ?? '',
                  validator: (value) => value?.isEmpty ?? true ? 'Required' : null,
                ),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () async {
              if (_formKey.currentState?.validate() ?? false) {
                try {
                  final newCourse = Course(
                    code: _codeController.text.toUpperCase(),
                    title: _titleController.text,
                    department: _selectedDepartment,
                    level: _selectedLevel,
                    creditUnits: int.parse(_creditController.text),
                    semester: _selectedSemester,
                    lecturer: 'Unassigned',
                  );
                  
                  await _dataService.addCourse(newCourse);
                  setState(() {
                    _courses.add(newCourse);
                  });
                  _filterCourses();
                  Navigator.pop(context);
                  _showAlert('Course added successfully!');
                } catch (e) {
                  _showAlert('Error adding course: $e', isError: true);
                }
              }
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF667eea),
              foregroundColor: Colors.white,
            ),
            child: const Text('Add Course'),
          ),
        ],
      ),
    );
  }

  void _editCourse(Course course) {
    final _formKey = GlobalKey<FormState>();
    final _codeController = TextEditingController(text: course.code);
    final _titleController = TextEditingController(text: course.title);
    final _creditController = TextEditingController(text: course.creditUnits.toString());
    String _selectedDepartment = course.department;
    String _selectedLevel = course.level;
    String _selectedSemester = course.semester;

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Edit Course'),
        content: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextFormField(
                  controller: _codeController,
                  decoration: const InputDecoration(labelText: 'Course Code'),
                  validator: (value) => value?.isEmpty ?? true ? 'Required' : null,
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _titleController,
                  decoration: const InputDecoration(labelText: 'Course Title'),
                  validator: (value) => value?.isEmpty ?? true ? 'Required' : null,
                ),
                const SizedBox(height: 16),
                DropdownButtonFormField<String>(
                  value: _selectedDepartment,
                  decoration: const InputDecoration(labelText: 'Department'),
                  items: [
                    'Computer Science',
                    'Electrical Engineering',
                    'Mechanical Engineering',
                    'Mathematics',
                    'Physics',
                    'Chemistry',
                  ].map((dept) => DropdownMenuItem(value: dept, child: Text(dept))).toList(),
                  onChanged: (value) => _selectedDepartment = value ?? '',
                  validator: (value) => value?.isEmpty ?? true ? 'Required' : null,
                ),
                const SizedBox(height: 16),
                DropdownButtonFormField<String>(
                  value: _selectedLevel,
                  decoration: const InputDecoration(labelText: 'Level'),
                  items: ['Level 100', 'Level 200', 'Level 300', 'Level 400']
                      .map((level) => DropdownMenuItem(value: level, child: Text(level)))
                      .toList(),
                  onChanged: (value) => _selectedLevel = value ?? '',
                  validator: (value) => value?.isEmpty ?? true ? 'Required' : null,
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _creditController,
                  decoration: const InputDecoration(labelText: 'Credit Units'),
                  keyboardType: TextInputType.number,
                  validator: (value) {
                    if (value?.isEmpty ?? true) return 'Required';
                    final credit = int.tryParse(value!);
                    if (credit == null || credit < 1 || credit > 6) {
                      return 'Must be between 1-6';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16),
                DropdownButtonFormField<String>(
                  value: _selectedSemester,
                  decoration: const InputDecoration(labelText: 'Semester'),
                  items: ['First Semester', 'Second Semester']
                      .map((sem) => DropdownMenuItem(value: sem, child: Text(sem)))
                      .toList(),
                  onChanged: (value) => _selectedSemester = value ?? '',
                  validator: (value) => value?.isEmpty ?? true ? 'Required' : null,
                ),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () async {
              if (_formKey.currentState?.validate() ?? false) {
                try {
                  final updatedCourse = Course(
                    code: _codeController.text.toUpperCase(),
                    title: _titleController.text,
                    department: _selectedDepartment,
                    level: _selectedLevel,
                    creditUnits: int.parse(_creditController.text),
                    semester: _selectedSemester,
                    lecturer: course.lecturer,
                  );
                  
                  await _dataService.updateCourse(updatedCourse);
                  final index = _courses.indexWhere((c) => c.code == course.code);
                  if (index != -1) {
                    setState(() {
                      _courses[index] = updatedCourse;
                    });
                    _filterCourses();
                  }
                  Navigator.pop(context);
                  _showAlert('Course updated successfully!');
                } catch (e) {
                  _showAlert('Error updating course: $e', isError: true);
                }
              }
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF667eea),
              foregroundColor: Colors.white,
            ),
            child: const Text('Update Course'),
          ),
        ],
      ),
    );
  }

  void _deleteCourse(String courseCode) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Course'),
        content: Text('Are you sure you want to delete course $courseCode? This action cannot be undone.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () async {
              try {
                await _dataService.deleteCourse(courseCode);
                setState(() {
                  _courses.removeWhere((course) => course.code == courseCode);
                });
                _filterCourses();
                Navigator.pop(context);
                _showAlert('Course $courseCode deleted successfully!');
              } catch (e) {
                Navigator.pop(context);
                _showAlert('Error deleting course: $e', isError: true);
              }
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
  }

  void _assignLecturer(Course course) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Assign Lecturer to ${course.code}'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('Course: ${course.title}'),
            const SizedBox(height: 16),
            DropdownButtonFormField<String>(
              decoration: const InputDecoration(labelText: 'Select Lecturer'),
              items: [
                'Dr. Sarah Wilson',
                'Prof. David Brown',
                'Dr. Lisa Chen',
                'Dr. Michael Johnson',
                'Prof. Emily Davis',
              ].map((lecturer) => DropdownMenuItem(value: lecturer, child: Text(lecturer))).toList(),
              onChanged: (value) {},
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _showAlert('Lecturer assigned successfully!');
            },
            child: const Text('Assign'),
          ),
        ],
      ),
    );
  }

  void _viewEnrolledStudents(Course course) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Students Enrolled in ${course.code}'),
        content: SizedBox(
          width: double.maxFinite,
          height: 300,
          child: ListView(
            children: [
              ListTile(
                leading: const CircleAvatar(child: Text('JD')),
                title: const Text('John Doe'),
                subtitle: const Text('CS2021001'),
                trailing: IconButton(
                  icon: const Icon(Icons.remove_circle, color: Colors.red),
                  onPressed: () => _showAlert('Student removed from course'),
                ),
              ),
              ListTile(
                leading: const CircleAvatar(child: Text('JS')),
                title: const Text('Jane Smith'),
                subtitle: const Text('CS2021002'),
                trailing: IconButton(
                  icon: const Icon(Icons.remove_circle, color: Colors.red),
                  onPressed: () => _showAlert('Student removed from course'),
                ),
              ),
              ListTile(
                leading: const CircleAvatar(child: Text('MJ')),
                title: const Text('Mike Johnson'),
                subtitle: const Text('CS2021003'),
                trailing: IconButton(
                  icon: const Icon(Icons.remove_circle, color: Colors.red),
                  onPressed: () => _showAlert('Student removed from course'),
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _showAlert('Opening student enrollment...');
            },
            child: const Text('Add Students'),
          ),
        ],
      ),
    );
  }

  void _setCourseSchedule(Course course) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Set Schedule for ${course.code}'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            DropdownButtonFormField<String>(
              decoration: const InputDecoration(labelText: 'Day of Week'),
              items: [
                'Monday',
                'Tuesday',
                'Wednesday',
                'Thursday',
                'Friday',
              ].map((day) => DropdownMenuItem(value: day, child: Text(day))).toList(),
              onChanged: (value) {},
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: TextFormField(
                    decoration: const InputDecoration(
                      labelText: 'Start Time',
                      hintText: '08:00',
                    ),
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: TextFormField(
                    decoration: const InputDecoration(
                      labelText: 'End Time',
                      hintText: '10:00',
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            TextFormField(
              decoration: const InputDecoration(
                labelText: 'Venue',
                hintText: 'Lecture Hall A',
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _showAlert('Course schedule set successfully!');
            },
            child: const Text('Save Schedule'),
          ),
        ],
      ),
    );
  }

  void _duplicateCourse(Course course) {
    final newCode = '${course.code}_COPY';
    final duplicatedCourse = Course(
      code: newCode,
      title: '${course.title} (Copy)',
      department: course.department,
      level: course.level,
      creditUnits: course.creditUnits,
      semester: course.semester,
      lecturer: 'Unassigned',
    );
    
    setState(() {
      _courses.add(duplicatedCourse);
    });
    _filterCourses();
    _showAlert('Course duplicated as $newCode');
  }

  void _viewCourseDetails(Course course) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(course.title),
        content: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              _buildDetailRow('Course Code', course.code),
              _buildDetailRow('Department', course.department),
              _buildDetailRow('Level', course.level),
              _buildDetailRow('Credit Units', '${course.creditUnits}'),
              _buildDetailRow('Semester', course.semester),
              _buildDetailRow('Lecturer', course.lecturer),
              const SizedBox(height: 16),
              const Text(
                'Course Statistics',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              _buildDetailRow('Enrolled Students', '28'),
              _buildDetailRow('Average Attendance', '85%'),
              _buildDetailRow('Sessions Completed', '12'),
              _buildDetailRow('Next Session', 'Tomorrow 10:00 AM'),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _editCourse(course);
            },
            child: const Text('Edit Course'),
          ),
        ],
      ),
    );
  }

  Widget _buildDetailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 100,
            child: Text(
              '$label:',
              style: const TextStyle(fontWeight: FontWeight.w500),
            ),
          ),
          Expanded(
            child: Text(value),
          ),
        ],
      ),
    );
  }

  void _showBulkActions() {
    showModalBottomSheet(
      context: context,
      builder: (context) => Container(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              'Bulk Actions',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 20),
            ListTile(
              leading: const Icon(Icons.file_download),
              title: const Text('Export Courses'),
              onTap: () {
                Navigator.pop(context);
                _exportCourses();
              },
            ),
            ListTile(
              leading: const Icon(Icons.file_upload),
              title: const Text('Import Courses'),
              onTap: () {
                Navigator.pop(context);
                _importCourses();
              },
            ),
            ListTile(
              leading: const Icon(Icons.assignment),
              title: const Text('Bulk Assign Lecturers'),
              onTap: () {
                Navigator.pop(context);
                _bulkAssignLecturers();
              },
            ),
            ListTile(
              leading: const Icon(Icons.schedule),
              title: const Text('Bulk Set Schedules'),
              onTap: () {
                Navigator.pop(context);
                _bulkSetSchedules();
              },
            ),
          ],
        ),
      ),
    );
  }

  void _exportCourses() {
    _showAlert('Exporting courses to CSV...');
    // TODO: Implement actual export functionality
  }

  void _importCourses() {
    _showAlert('Opening file picker for course import...');
    // TODO: Implement actual import functionality
  }

  void _bulkAssignLecturers() {
    _showAlert('Opening bulk lecturer assignment...');
    // TODO: Implement bulk assignment functionality
  }

  void _bulkSetSchedules() {
    _showAlert('Opening bulk schedule setting...');
    // TODO: Implement bulk schedule functionality
  }

  void _showAlert(String message, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: isError ? Colors.red : Colors.green,
        duration: const Duration(seconds: 2),
        action: SnackBarAction(
          label: 'OK',
          textColor: Colors.white,
          onPressed: () {
            ScaffoldMessenger.of(context).hideCurrentSnackBar();
          },
        ),
      ),
    );
  }
}
