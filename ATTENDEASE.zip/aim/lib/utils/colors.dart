import 'package:flutter/material.dart';

class AppColors {
  static const Color primaryPurple = Color(0xFF6C63FF);
  static const Color primaryGreen = Color(0xFF4CAF50);
  static const Color white = Colors.white;
  static const Color transparent = Colors.transparent;
  
  static const LinearGradient primaryGradient = LinearGradient(
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
    colors: [primaryPurple, primaryGreen],
  );
}
