import 'package:flutter/material.dart';

class AppTheme {
  static final lightTheme = ThemeData(
    brightness: Brightness.light,
    primaryColor: const Color(0xFF667EEA),
    colorScheme: const ColorScheme.light(
      primary: Color(0xFF667EEA),
      secondary: Color(0xFF764BA2),
      background: Colors.white,
      surface: Colors.white,
      onBackground: Color(0xFF333333),
      onSurface: Color(0xFF333333),
    ),
    scaffoldBackgroundColor: Colors.white,
    cardColor: Colors.white,
    dividerColor: const Color(0xFFE0E0E0),
    textTheme: const TextTheme(
      displayLarge: TextStyle(color: Color(0xFF333333)),
      displayMedium: TextStyle(color: Color(0xFF333333)),
      displaySmall: TextStyle(color: Color(0xFF333333)),
      headlineMedium: TextStyle(color: Color(0xFF333333)),
      headlineSmall: TextStyle(color: Color(0xFF333333)),
      titleLarge: TextStyle(color: Color(0xFF333333)),
      titleMedium: TextStyle(color: Color(0xFF333333)),
      titleSmall: TextStyle(color: Color(0xFF6C757D)),
      bodyLarge: TextStyle(color: Color(0xFF333333)),
      bodyMedium: TextStyle(color: Color(0xFF333333)),
      bodySmall: TextStyle(color: Color(0xFF6C757D)),
      labelLarge: TextStyle(color: Color(0xFF333333)),
      labelSmall: TextStyle(color: Color(0xFF6C757D)),
    ),
    appBarTheme: const AppBarTheme(
      backgroundColor: Color(0xFF667EEA),
      foregroundColor: Colors.white,
      elevation: 0,
      centerTitle: true,
    ),
  );

  static final darkTheme = ThemeData(
    brightness: Brightness.dark,
    primaryColor: const Color(0xFF7C93E8),
    colorScheme: const ColorScheme.dark(
      primary: Color(0xFF7C93E8),
      secondary: Color(0xFF8A66AD),
      background: Color(0xFF212529),
      surface: Color(0xFF2C3034),
      onBackground: Color(0xFFF8F9FA),
      onSurface: Color(0xFFF8F9FA),
    ),
    scaffoldBackgroundColor: const Color(0xFF212529),
    cardColor: const Color(0xFF2C3034),
    dividerColor: const Color(0xFF495057),
    textTheme: const TextTheme(
      displayLarge: TextStyle(color: Color(0xFFF8F9FA)),
      displayMedium: TextStyle(color: Color(0xFFF8F9FA)),
      displaySmall: TextStyle(color: Color(0xFFF8F9FA)),
      headlineMedium: TextStyle(color: Color(0xFFF8F9FA)),
      headlineSmall: TextStyle(color: Color(0xFFF8F9FA)),
      titleLarge: TextStyle(color: Color(0xFFF8F9FA)),
      titleMedium: TextStyle(color: Color(0xFFF8F9FA)),
      titleSmall: TextStyle(color: Color(0xFFADB5BD)),
      bodyLarge: TextStyle(color: Color(0xFFF8F9FA)),
      bodyMedium: TextStyle(color: Color(0xFFF8F9FA)),
      bodySmall: TextStyle(color: Color(0xFFADB5BD)),
      labelLarge: TextStyle(color: Color(0xFFF8F9FA)),
      labelSmall: TextStyle(color: Color(0xFFADB5BD)),
    ),
    appBarTheme: const AppBarTheme(
      backgroundColor: Color(0xFF495057),
      foregroundColor: Colors.white,
      elevation: 0,
      centerTitle: true,
    ),
  );
}
