import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:camera/camera.dart';
import 'package:path_provider/path_provider.dart';

class FaceRecognitionService {
  CameraController? cameraController;
  List<CameraDescription>? cameras;
  bool isInitialized = false;

  Future<void> initializeCameras() async {
    try {
      cameras = await availableCameras();
      if (cameras!.isNotEmpty) {
        // Use front camera for face registration
        final frontCamera = cameras!.firstWhere(
          (camera) => camera.lensDirection == CameraLensDirection.front,
          orElse: () => cameras!.first,
        );
        
        cameraController = CameraController(
          frontCamera,
          ResolutionPreset.medium,
          enableAudio: false,
        );
        
        await cameraController!.initialize();
        isInitialized = true;
      } else {
        throw Exception('No cameras available');
      }
    } catch (e) {
      print('Error initializing cameras: $e');
      rethrow;
    }
  }

  Future<Map<String, dynamic>> captureFaceImage() async {
    if (!isInitialized || cameraController == null) {
      throw Exception('Camera not initialized');
    }

    try {
      // Capture image
      final XFile imageFile = await cameraController!.takePicture();
      
      // Read image bytes
      final Uint8List imageBytes = await imageFile.readAsBytes();
      
      // Convert to base64 for storage/transmission
      final String base64Image = base64Encode(imageBytes);
      
      // Simulate face detection and quality check
      await Future.delayed(Duration(milliseconds: 500));
      
      // Generate a simple "encoding" (in real implementation, this would be actual face encoding)
      final String faceEncoding = _generateSimpleFaceEncoding(base64Image);
      
      return {
        'image': base64Image,
        'encoding': faceEncoding,
        'quality_score': 0.85, // Simulated quality score
        'timestamp': DateTime.now().toIso8601String(),
      };
    } catch (e) {
      print('Error capturing face image: $e');
      rethrow;
    }
  }

  String _generateSimpleFaceEncoding(String imageData) {
    // This is a simplified encoding - in production, you'd use actual face recognition
    final hash = imageData.hashCode;
    return 'face_encoding_${hash}_${DateTime.now().millisecondsSinceEpoch}';
  }

  void dispose() {
    cameraController?.dispose();
    isInitialized = false;
  }
}
