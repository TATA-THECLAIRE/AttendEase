import 'package:supabase_flutter/supabase_flutter.dart';
import '../models/user.dart' as AppUser;
import 'dart:developer' as developer;

class SupabaseService {
  static final SupabaseService _instance = SupabaseService._internal();
  factory SupabaseService() => _instance;
  SupabaseService._internal();

  late final SupabaseClient _client;
  
  SupabaseClient get client => _client;

  Future<void> initialize() async {
    try {
      await Supabase.initialize(
        url: 'https://bywmivsvhtjbfrtpxdzl.supabase.co',
        anonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJ5d21pdnN2aHRqYmZydHB4ZHpsIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzM2NjI3NjQsImV4cCI6MjA0OTIzODc2NH0.placeholder_anon_key',
      );
      _client = Supabase.instance.client;
      developer.log('Supabase initialized successfully');
    } catch (e) {
      developer.log('Failed to initialize Supabase: $e');
      rethrow;
    }
  }

  // Test connection
  Future<bool> testConnection() async {
    try {
      final response = await _client
          .from('users')
          .select('id')
          .limit(1);
      developer.log('Supabase connection test: SUCCESS');
      return true;
    } catch (e) {
      developer.log('Supabase connection test failed: $e');
      return false;
    }
  }

  // Authentication methods
  Future<AuthResponse> signUp({
    required String email,
    required String password,
    required Map<String, dynamic> userData,
  }) async {
    try {
      final response = await _client.auth.signUp(
        email: email,
        password: password,
        data: userData,
      );
      
      if (response.user != null) {
        // Create user profile in users table
        await _client.from('users').insert({
          'id': response.user!.id,
          'email': email,
          'full_name': userData['full_name'],
          'role': userData['role'] ?? 'student',
          'student_id': userData['student_id'],
          'phone': userData['phone'],
          'created_at': DateTime.now().toIso8601String(),
        });
      }
      
      return response;
    } catch (e) {
      developer.log('Sign up error: $e');
      rethrow;
    }
  }

  Future<AuthResponse> signIn({
    required String email,
    required String password,
  }) async {
    try {
      return await _client.auth.signInWithPassword(
        email: email,
        password: password,
      );
    } catch (e) {
      developer.log('Sign in error: $e');
      rethrow;
    }
  }

  Future<void> signOut() async {
    try {
      await _client.auth.signOut();
    } catch (e) {
      developer.log('Sign out error: $e');
      rethrow;
    }
  }

  User? get currentUser => _client.auth.currentUser;
  
  Stream<AuthState> get authStateChanges => _client.auth.onAuthStateChange;

  // Real-time subscriptions
  RealtimeChannel subscribeToAttendance(String courseId, Function(List<Map<String, dynamic>>) onData) {
    return _client
        .channel('attendance_$courseId')
        .onPostgresChanges(
          event: PostgresChangeEvent.all,
          schema: 'public',
          table: 'attendance_records',
          filter: PostgresChangeFilter(
            type: PostgresChangeFilterType.eq,
            column: 'course_id',
            value: courseId,
          ),
          callback: (payload) {
            developer.log('Real-time attendance update: ${payload.newRecord}');
            onData([payload.newRecord]);
          },
        )
        .subscribe();
  }

  // Database operations
  Future<List<Map<String, dynamic>>> getCourses() async {
    try {
      final response = await _client
          .from('courses')
          .select('*')
          .eq('is_active', true)
          .order('created_at', ascending: false);
      return List<Map<String, dynamic>>.from(response);
    } catch (e) {
      developer.log('Get courses error: $e');
      rethrow;
    }
  }

  Future<List<Map<String, dynamic>>> getAttendanceSessions({String? courseId}) async {
    try {
      var query = _client
          .from('attendance_sessions')
          .select('*, courses(name, code)');
      
      if (courseId != null) {
        query = query.eq('course_id', courseId);
      }
      
      final response = await query.order('session_date', ascending: false);
      return List<Map<String, dynamic>>.from(response);
    } catch (e) {
      developer.log('Get attendance sessions error: $e');
      rethrow;
    }
  }

  Future<Map<String, dynamic>> createAttendanceSession(Map<String, dynamic> sessionData) async {
    try {
      final response = await _client
          .from('attendance_sessions')
          .insert(sessionData)
          .select()
          .single();
      return response;
    } catch (e) {
      developer.log('Create attendance session error: $e');
      rethrow;
    }
  }

  Future<Map<String, dynamic>> checkInStudent(Map<String, dynamic> attendanceData) async {
    try {
      final response = await _client
          .from('attendance_records')
          .insert(attendanceData)
          .select()
          .single();
      return response;
    } catch (e) {
      developer.log('Check in student error: $e');
      rethrow;
    }
  }

  Future<Map<String, dynamic>?> getUserProfile(String userId) async {
    try {
      final response = await _client
          .from('users')
          .select('*')
          .eq('id', userId)
          .single();
      return response;
    } catch (e) {
      developer.log('Get user profile error: $e');
      return null;
    }
  }
}
