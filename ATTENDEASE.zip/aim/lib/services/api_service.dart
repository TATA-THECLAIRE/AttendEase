import 'dart:convert';
import 'dart:async';
import '../models/user.dart';
import '../models/course.dart';
import '../models/attendance.dart';

class ApiService {
  static const String baseUrl = 'http://localhost:3000'; // Mock URL
  static const String apiVersion = '/api/v1';
  
  // Singleton pattern
  static final ApiService _instance = ApiService._internal();
  factory ApiService() => _instance;
  ApiService._internal();

  String? _accessToken;
  String? _refreshToken;

  // Mock user data
  final Map<String, dynamic> _mockUser = {
    'id': 'user_123',
    'email': 'john.doe@example.com',
    'full_name': 'John Doe',
    'role': 'student',
    'phone_number': '+1234567890',
    'student_id': 'STU001',
    'department': 'Computer Science',
    'year_of_study': 3,
    'is_verified': true,
    'created_at': DateTime.now().toIso8601String(),
  };

  // Mock courses data
  final List<Map<String, dynamic>> _mockCourses = [
    {
      'id': 'course_1',
      'name': 'Introduction to Programming',
      'code': 'CS101',
      'description': 'Learn the basics of programming',
      'lecturer_name': 'Dr. Smith',
      'department': 'Computer Science',
      'credits': 3,
      'schedule': 'Mon, Wed, Fri 10:00 AM',
    },
    {
      'id': 'course_2',
      'name': 'Data Structures',
      'code': 'CS201',
      'description': 'Advanced data structures and algorithms',
      'lecturer_name': 'Prof. Johnson',
      'department': 'Computer Science',
      'credits': 4,
      'schedule': 'Tue, Thu 2:00 PM',
    },
  ];

  // Set tokens after login
  void setTokens(String accessToken, String refreshToken) {
    _accessToken = accessToken;
    _refreshToken = refreshToken;
  }

  // Clear tokens on logout
  void clearTokens() {
    _accessToken = null;
    _refreshToken = null;
  }

  // Mock health check - always returns true
  Future<bool> checkHealth() async {
    await Future.delayed(Duration(milliseconds: 500)); // Simulate network delay
    return true;
  }

  // Mock authentication endpoints
  Future<Map<String, dynamic>> register(Map<String, dynamic> userData) async {
    await Future.delayed(Duration(seconds: 1)); // Simulate network delay
    
    // Mock successful registration
    return {
      'user': _mockUser,
      'access_token': 'mock_access_token_${DateTime.now().millisecondsSinceEpoch}',
      'refresh_token': 'mock_refresh_token_${DateTime.now().millisecondsSinceEpoch}',
      'message': 'Registration successful',
    };
  }

  Future<Map<String, dynamic>> login(String email, String password) async {
    await Future.delayed(Duration(seconds: 1)); // Simulate network delay
    
    // Mock login validation
    if (email.isEmpty || password.isEmpty) {
      throw Exception('Email and password are required');
    }
    
    // Mock successful login
    final mockTokens = {
      'access_token': 'mock_access_token_${DateTime.now().millisecondsSinceEpoch}',
      'refresh_token': 'mock_refresh_token_${DateTime.now().millisecondsSinceEpoch}',
    };
    
    setTokens(mockTokens['access_token']!, mockTokens['refresh_token']!);
    
    return {
      'user': _mockUser,
      ...mockTokens,
      'message': 'Login successful',
    };
  }

  Future<Map<String, dynamic>> verifyEmail(String email, String verificationCode) async {
    await Future.delayed(Duration(seconds: 1));
    
    // Mock email verification
    if (verificationCode == '123456') {
      return {'message': 'Email verified successfully'};
    } else {
      throw Exception('Invalid verification code');
    }
  }

  Future<Map<String, dynamic>> resendVerification(String email) async {
    await Future.delayed(Duration(seconds: 1));
    return {'message': 'Verification code sent successfully'};
  }

  Future<Map<String, dynamic>> forgotPassword(String email) async {
    await Future.delayed(Duration(seconds: 1));
    return {'message': 'Password reset link sent to your email'};
  }

  Future<Map<String, dynamic>> resetPassword(String token, String newPassword) async {
    await Future.delayed(Duration(seconds: 1));
    return {'message': 'Password reset successfully'};
  }

  Future<Map<String, dynamic>> getCurrentUser() async {
    await Future.delayed(Duration(milliseconds: 500));
    
    if (_accessToken == null) {
      throw Exception('Unauthorized - Please login again');
    }
    
    return _mockUser;
  }

  Future<Map<String, dynamic>> refreshToken() async {
    await Future.delayed(Duration(milliseconds: 500));
    
    final newTokens = {
      'access_token': 'mock_access_token_${DateTime.now().millisecondsSinceEpoch}',
      'refresh_token': 'mock_refresh_token_${DateTime.now().millisecondsSinceEpoch}',
    };
    
    setTokens(newTokens['access_token']!, newTokens['refresh_token']!);
    return newTokens;
  }

  // Mock course endpoints
  Future<List<Map<String, dynamic>>> getCourses() async {
    await Future.delayed(Duration(milliseconds: 800));
    return List<Map<String, dynamic>>.from(_mockCourses);
  }

  Future<Map<String, dynamic>> createCourse(Map<String, dynamic> courseData) async {
    await Future.delayed(Duration(seconds: 1));
    
    final newCourse = {
      'id': 'course_${DateTime.now().millisecondsSinceEpoch}',
      ...courseData,
      'created_at': DateTime.now().toIso8601String(),
    };
    
    _mockCourses.add(newCourse);
    return newCourse;
  }

  Future<Map<String, dynamic>> getCourse(String courseId) async {
    await Future.delayed(Duration(milliseconds: 500));
    
    final course = _mockCourses.firstWhere(
      (course) => course['id'] == courseId,
      orElse: () => throw Exception('Course not found'),
    );
    
    return course;
  }

  Future<Map<String, dynamic>> updateCourse(String courseId, Map<String, dynamic> courseData) async {
    await Future.delayed(Duration(seconds: 1));
    
    final courseIndex = _mockCourses.indexWhere((course) => course['id'] == courseId);
    if (courseIndex == -1) {
      throw Exception('Course not found');
    }
    
    _mockCourses[courseIndex] = {
      ..._mockCourses[courseIndex],
      ...courseData,
      'updated_at': DateTime.now().toIso8601String(),
    };
    
    return _mockCourses[courseIndex];
  }

  Future<void> deleteCourse(String courseId) async {
    await Future.delayed(Duration(milliseconds: 800));
    
    final courseIndex = _mockCourses.indexWhere((course) => course['id'] == courseId);
    if (courseIndex == -1) {
      throw Exception('Course not found');
    }
    
    _mockCourses.removeAt(courseIndex);
  }

  // Mock attendance endpoints
  Future<List<Map<String, dynamic>>> getAttendanceSessions() async {
    await Future.delayed(Duration(milliseconds: 600));
    
    return [
      {
        'id': 'session_1',
        'course_id': 'course_1',
        'course_name': 'Introduction to Programming',
        'date': DateTime.now().subtract(Duration(days: 1)).toIso8601String(),
        'start_time': '10:00',
        'end_time': '11:30',
        'status': 'completed',
        'attendance_count': 25,
        'total_students': 30,
      },
      {
        'id': 'session_2',
        'course_id': 'course_2',
        'course_name': 'Data Structures',
        'date': DateTime.now().toIso8601String(),
        'start_time': '14:00',
        'end_time': '15:30',
        'status': 'active',
        'attendance_count': 18,
        'total_students': 28,
      },
    ];
  }

  Future<Map<String, dynamic>> createAttendanceSession(Map<String, dynamic> sessionData) async {
    await Future.delayed(Duration(seconds: 1));
    
    return {
      'id': 'session_${DateTime.now().millisecondsSinceEpoch}',
      ...sessionData,
      'created_at': DateTime.now().toIso8601String(),
      'status': 'active',
      'attendance_count': 0,
    };
  }

  Future<Map<String, dynamic>> markAttendance(Map<String, dynamic> attendanceData) async {
    await Future.delayed(Duration(milliseconds: 800));
    
    return {
      'id': 'attendance_${DateTime.now().millisecondsSinceEpoch}',
      ...attendanceData,
      'timestamp': DateTime.now().toIso8601String(),
      'status': 'present',
      'method': 'manual', // or 'face_recognition', 'qr_code', etc.
    };
  }

  // Mock face registration
  Future<Map<String, dynamic>> registerFaceData(String userId, List<String> faceImages, String faceEncoding) async {
    await Future.delayed(Duration(seconds: 2));
    
    return {
      'message': 'Face data registered successfully',
      'face_id': 'face_${DateTime.now().millisecondsSinceEpoch}',
      'user_id': userId,
    };
  }

  // Logout
  void logout() {
    clearTokens();
  }

  // Parse level string to integer
  int _parseLevel(String? level) {
    if (level == null) return 1;
    final match = RegExp(r'\d+').firstMatch(level);
    return match != null ? int.parse(match.group(0)!) : 1;
  }
}
