import 'dart:async';
import '../models/attendance.dart';
import '../models/student.dart';

class AttendanceService {
  static final AttendanceService _instance = AttendanceService._internal();
  factory AttendanceService() => _instance;
  AttendanceService._internal();

  final StreamController<List<AttendanceRecord>> _attendanceController = 
      StreamController<List<AttendanceRecord>>.broadcast();

  Stream<List<AttendanceRecord>> get attendanceStream => _attendanceController.stream;

  List<AttendanceRecord> _currentRecords = [];
  Timer? _simulationTimer;

  void startSession(String courseCode) {
    _currentRecords.clear();
    _simulateRealTimeAttendance(courseCode);
  }

  void stopSession() {
    _simulationTimer?.cancel();
    _simulationTimer = null;
  }

  void _simulateRealTimeAttendance(String courseCode) {
    final students = [
      Student(id: '1', name: 'Tabe Mercy', matricle: 'FE19A001', level: '300', department: 'CS'),
      Student(id: '2', name: 'Ngozi Paul', matricle: 'FE19A002', level: '300', department: 'CS'),
      Student(id: '3', name: 'Fon Sandra', matricle: 'FE19A003', level: '300', department: 'CS'),
      Student(id: '4', name: 'Ako John', matricle: 'FE19A006', level: '300', department: 'CS'),
      Student(id: '5', name: 'Ndi Mary', matricle: 'FE19A007', level: '300', department: 'CS'),
    ];

    int studentIndex = 0;
    _simulationTimer = Timer.periodic(Duration(seconds: 5), (timer) {
      if (studentIndex < students.length) {
        final student = students[studentIndex];
        final record = AttendanceRecord(
          id: DateTime.now().millisecondsSinceEpoch.toString(),
          studentId: student.id,
          courseCode: courseCode,
          timestamp: DateTime.now(),
          isPresent: true,
        );
        
        _currentRecords.add(record);
        _attendanceController.add(List.from(_currentRecords));
        studentIndex++;
      } else {
        timer.cancel();
      }
    });
  }

  void dispose() {
    _attendanceController.close();
    _simulationTimer?.cancel();
  }
}
