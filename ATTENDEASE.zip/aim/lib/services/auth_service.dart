import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/user.dart';
import 'api_service.dart';

class AuthService {
  static final AuthService _instance = AuthService._internal();
  factory AuthService() => _instance;
  AuthService._internal();

  final ApiService _apiService = ApiService();
  User? _currentUser;
  
  User? get currentUser => _currentUser;
  bool get isLoggedIn => _currentUser != null;

  // Initialize auth service - check for stored tokens
  Future<void> initialize() async {
    final prefs = await SharedPreferences.getInstance();
    final accessToken = prefs.getString('access_token');
    final refreshToken = prefs.getString('refresh_token');
    final userJson = prefs.getString('current_user');

    if (accessToken != null && refreshToken != null && userJson != null) {
      _apiService.setTokens(accessToken, refreshToken);
      try {
        _currentUser = User.fromJson(json.decode(userJson));
        
        // Verify token is still valid (mock will always succeed)
        await _apiService.getCurrentUser();
      } catch (e) {
        // If there's an error parsing stored user data, logout
        await logout();
      }
    }
  }

  // Register new user
  Future<User> register(Map<String, dynamic> userData) async {
    try {
      final response = await _apiService.register(userData);
      
      // Create user from mock response
      _currentUser = User(
        id: response['user']['id'] as String,
        email: response['user']['email'] as String,
        fullName: response['user']['full_name'] as String,
        role: response['user']['role'] as String,
        phoneNumber: response['user']['phone_number'] as String?,
        studentId: response['user']['student_id'] as String?,
        department: response['user']['department'] as String?,
        yearOfStudy: response['user']['year_of_study'] as int?,
        isEmailVerified: (response['user']['is_verified'] as bool?) ?? false,
        status: (response['user']['status'] as String?) ?? 'active',
        createdAt: DateTime.parse(response['user']['created_at'] as String),
      );
      
      // Store tokens and user data
      await _storeAuthData(
        response['access_token'] as String,
        response['refresh_token'] as String,
        _currentUser!,
      );
      
      return _currentUser!;
    } catch (e) {
      throw Exception('Registration failed: $e');
    }
  }

  // Login user
  Future<User> login(String email, String password) async {
    try {
      final response = await _apiService.login(email, password);
      
      // Create user from mock response
      _currentUser = User(
        id: response['user']['id'] as String,
        email: response['user']['email'] as String,
        fullName: response['user']['full_name'] as String,
        role: response['user']['role'] as String,
        phoneNumber: response['user']['phone_number'] as String?,
        studentId: response['user']['student_id'] as String?,
        department: response['user']['department'] as String?,
        yearOfStudy: response['user']['year_of_study'] as int?,
        isEmailVerified: (response['user']['is_verified'] as bool?) ?? true,
        status: (response['user']['status'] as String?) ?? 'active',
        createdAt: DateTime.parse(response['user']['created_at'] as String),
      );
      
      // Store tokens and user data
      await _storeAuthData(
        response['access_token'] as String,
        response['refresh_token'] as String,
        _currentUser!,
      );
      
      return _currentUser!;
    } catch (e) {
      throw Exception('Login failed: $e');
    }
  }

  // Verify email
  Future<void> verifyEmail(String email, String verificationCode) async {
    try {
      await _apiService.verifyEmail(email, verificationCode);
      
      // Update current user verification status
      if (_currentUser != null) {
        _currentUser = User(
          id: _currentUser!.id,
          email: _currentUser!.email,
          fullName: _currentUser!.fullName,
          role: _currentUser!.role,
          phoneNumber: _currentUser!.phoneNumber,
          studentId: _currentUser!.studentId,
          department: _currentUser!.department,
          yearOfStudy: _currentUser!.yearOfStudy,
          isEmailVerified: true, // Mark as verified
          status: _currentUser!.status,
          createdAt: _currentUser!.createdAt,
        );
        
        // Update stored user data
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString('current_user', json.encode(_currentUser!.toJson()));
      }
    } catch (e) {
      throw Exception('Email verification failed: $e');
    }
  }

  // Resend verification email
  Future<void> resendVerification(String email) async {
    try {
      await _apiService.resendVerification(email);
    } catch (e) {
      throw Exception('Failed to resend verification: $e');
    }
  }

  // Forgot password
  Future<void> forgotPassword(String email) async {
    try {
      await _apiService.forgotPassword(email);
    } catch (e) {
      throw Exception('Password reset request failed: $e');
    }
  }

  // Reset password
  Future<void> resetPassword(String token, String newPassword) async {
    try {
      await _apiService.resetPassword(token, newPassword);
    } catch (e) {
      throw Exception('Password reset failed: $e');
    }
  }

  // Refresh token
  Future<void> refreshToken() async {
    try {
      final response = await _apiService.refreshToken();
      
      // Update stored tokens
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('access_token', response['access_token'] as String);
      await prefs.setString('refresh_token', response['refresh_token'] as String);
    } catch (e) {
      await logout();
      throw Exception('Token refresh failed: $e');
    }
  }

  // Get current user info
  Future<User> getCurrentUser() async {
    try {
      final response = await _apiService.getCurrentUser();
      
      _currentUser = User(
        id: response['id'] as String,
        email: response['email'] as String,
        fullName: response['full_name'] as String,
        role: response['role'] as String,
        phoneNumber: response['phone_number'] as String?,
        studentId: response['student_id'] as String?,
        department: response['department'] as String?,
        yearOfStudy: response['year_of_study'] as int?,
        isEmailVerified: (response['is_verified'] as bool?) ?? true,
        status: (response['status'] as String?) ?? 'active',
        createdAt: DateTime.parse(response['created_at'] as String),
      );
      
      // Update stored user data
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('current_user', json.encode(_currentUser!.toJson()));
      
      return _currentUser!;
    } catch (e) {
      throw Exception('Failed to get user info: $e');
    }
  }

  // Logout
  Future<void> logout() async {
    _apiService.logout();
    _currentUser = null;
    
    // Clear stored data
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('access_token');
    await prefs.remove('refresh_token');
    await prefs.remove('current_user');
  }

  // Store authentication data
  Future<void> _storeAuthData(String accessToken, String refreshToken, User user) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('access_token', accessToken);
    await prefs.setString('refresh_token', refreshToken);
    await prefs.setString('current_user', json.encode(user.toJson()));
  }

  // Mock login for testing (bypasses API)
  Future<User> mockLogin({String role = 'student'}) async {
    await Future.delayed(Duration(seconds: 1)); // Simulate network delay
    
    _currentUser = User(
      id: 'mock_user_${DateTime.now().millisecondsSinceEpoch}',
      email: 'mock@example.com',
      fullName: 'Mock User',
      role: role,
      phoneNumber: '+1234567890',
      studentId: role == 'student' ? 'STU001' : null,
      department: 'Computer Science',
      yearOfStudy: role == 'student' ? 3 : null,
      isEmailVerified: true,
      status: 'active',
      createdAt: DateTime.now(),
    );
    
    // Store mock tokens and user data
    await _storeAuthData(
      'mock_access_token_${DateTime.now().millisecondsSinceEpoch}',
      'mock_refresh_token_${DateTime.now().millisecondsSinceEpoch}',
      _currentUser!,
    );
    
    return _currentUser!;
  }
}
