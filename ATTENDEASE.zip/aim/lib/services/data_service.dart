import '../models/app_state.dart';

// Data service layer for easy backend integration
class DataService {
  // Singleton pattern for global access
  static final DataService _instance = DataService._internal();
  factory DataService() => _instance;
  DataService._internal();

  // Future method signatures for backend integration
  
  // Student operations
  Future<List<Student>> getStudents({String? searchQuery}) async {
    // TODO: Replace with actual API call
    await Future.delayed(const Duration(milliseconds: 500)); // Simulate network delay
    return _mockStudents.where((student) {
      if (searchQuery == null || searchQuery.isEmpty) return true;
      return student.name.toLowerCase().contains(searchQuery.toLowerCase()) ||
             student.matricle.toLowerCase().contains(searchQuery.toLowerCase()) ||
             student.department.toLowerCase().contains(searchQuery.toLowerCase());
    }).toList();
  }

  Future<Student> addStudent(Student student) async {
    // TODO: Replace with actual API call
    await Future.delayed(const Duration(milliseconds: 500));
    _mockStudents.add(student);
    return student;
  }

  Future<Student> updateStudent(Student student) async {
    // TODO: Replace with actual API call
    await Future.delayed(const Duration(milliseconds: 500));
    final index = _mockStudents.indexWhere((s) => s.matricle == student.matricle);
    if (index != -1) {
      _mockStudents[index] = student;
    }
    return student;
  }

  Future<bool> deleteStudent(String matricle) async {
    // TODO: Replace with actual API call
    await Future.delayed(const Duration(milliseconds: 500));
    final initialLength = _mockStudents.length;
    _mockStudents.removeWhere((student) => student.matricle == matricle);
    return _mockStudents.length < initialLength;
  }

  // Lecturer operations
  Future<List<Lecturer>> getLecturers({String? searchQuery}) async {
    // TODO: Replace with actual API call
    await Future.delayed(const Duration(milliseconds: 500));
    return _mockLecturers.where((lecturer) {
      if (searchQuery == null || searchQuery.isEmpty) return true;
      return lecturer.name.toLowerCase().contains(searchQuery.toLowerCase()) ||
             lecturer.id.toLowerCase().contains(searchQuery.toLowerCase()) ||
             lecturer.department.toLowerCase().contains(searchQuery.toLowerCase());
    }).toList();
  }

  Future<Lecturer> addLecturer(Lecturer lecturer) async {
    // TODO: Replace with actual API call
    await Future.delayed(const Duration(milliseconds: 500));
    _mockLecturers.add(lecturer);
    return lecturer;
  }

  Future<Lecturer> updateLecturer(Lecturer lecturer) async {
    // TODO: Replace with actual API call
    await Future.delayed(const Duration(milliseconds: 500));
    final index = _mockLecturers.indexWhere((l) => l.id == lecturer.id);
    if (index != -1) {
      _mockLecturers[index] = lecturer;
    }
    return lecturer;
  }

  Future<bool> deleteLecturer(String id) async {
    // TODO: Replace with actual API call
    await Future.delayed(const Duration(milliseconds: 500));
    final initialLength = _mockLecturers.length;
    _mockLecturers.removeWhere((lecturer) => lecturer.id == id);
    return _mockLecturers.length < initialLength;
  }

  // Course operations
  Future<List<Course>> getCourses({String? searchQuery}) async {
    // TODO: Replace with actual API call
    await Future.delayed(const Duration(milliseconds: 500));
    return _mockCourses.where((course) {
      if (searchQuery == null || searchQuery.isEmpty) return true;
      return course.title.toLowerCase().contains(searchQuery.toLowerCase()) ||
             course.code.toLowerCase().contains(searchQuery.toLowerCase()) ||
             course.department.toLowerCase().contains(searchQuery.toLowerCase());
    }).toList();
  }

  Future<Course> addCourse(Course course) async {
    // TODO: Replace with actual API call
    await Future.delayed(const Duration(milliseconds: 500));
    _mockCourses.add(course);
    return course;
  }

  Future<Course> updateCourse(Course course) async {
    // TODO: Replace with actual API call
    await Future.delayed(const Duration(milliseconds: 500));
    final index = _mockCourses.indexWhere((c) => c.code == course.code);
    if (index != -1) {
      _mockCourses[index] = course;
    }
    return course;
  }

  Future<bool> deleteCourse(String code) async {
    // TODO: Replace with actual API call
    await Future.delayed(const Duration(milliseconds: 500));
    final initialLength = _mockCourses.length;
    _mockCourses.removeWhere((course) => course.code == code);
    return _mockCourses.length < initialLength;
  }

  // Geofence operations
  Future<List<GeofenceLocation>> getGeofenceLocations({String? searchQuery}) async {
    // TODO: Replace with actual API call
    await Future.delayed(const Duration(milliseconds: 500));
    return _mockGeofenceLocations.where((location) {
      if (searchQuery == null || searchQuery.isEmpty) return true;
      return location.name.toLowerCase().contains(searchQuery.toLowerCase()) ||
             location.description.toLowerCase().contains(searchQuery.toLowerCase());
    }).toList();
  }

  Future<GeofenceLocation> addGeofenceLocation(GeofenceLocation location) async {
    // TODO: Replace with actual API call
    await Future.delayed(const Duration(milliseconds: 500));
    _mockGeofenceLocations.add(location);
    return location;
  }

  Future<GeofenceLocation> updateGeofenceLocation(GeofenceLocation location) async {
    // TODO: Replace with actual API call
    await Future.delayed(const Duration(milliseconds: 500));
    final index = _mockGeofenceLocations.indexWhere((l) => l.name == location.name);
    if (index != -1) {
      _mockGeofenceLocations[index] = location;
    }
    return location;
  }

  Future<bool> deleteGeofenceLocation(String name) async {
    // TODO: Replace with actual API call
    await Future.delayed(const Duration(milliseconds: 500));
    final initialLength = _mockGeofenceLocations.length;
    _mockGeofenceLocations.removeWhere((location) => location.name == name);
    return _mockGeofenceLocations.length < initialLength;
  }

  // Reports operations
  Future<List<AttendanceSession>> getAttendanceSessions() async {
    // TODO: Replace with actual API call
    await Future.delayed(const Duration(milliseconds: 500));
    return _mockSessions;
  }

  Future<Map<String, dynamic>> getDashboardStats() async {
    // TODO: Replace with actual API call
    await Future.delayed(const Duration(milliseconds: 500));
    return {
      'totalStudents': _mockStudents.length,
      'totalLecturers': _mockLecturers.length,
      'activeSessions': _mockSessions.where((s) => _isToday(s.dateTime)).length,
      'averageAttendance': _calculateAverageAttendance(),
      'totalCheckins': _mockSessions.fold<int>(0, (sum, session) => sum + session.presentCount),
      'sessionsToday': _mockSessions.where((s) => _isToday(s.dateTime)).length,
    };
  }

  // Settings operations
  Future<Map<String, dynamic>> getSettings() async {
    // TODO: Replace with actual API call
    await Future.delayed(const Duration(milliseconds: 500));
    return _mockSettings;
  }

  Future<bool> updateSettings(Map<String, dynamic> settings) async {
    // TODO: Replace with actual API call
    await Future.delayed(const Duration(milliseconds: 500));
    _mockSettings.addAll(settings);
    return true;
  }

  // Helper methods
  bool _isToday(DateTime date) {
    final now = DateTime.now();
    return date.year == now.year && date.month == now.month && date.day == now.day;
  }

  double _calculateAverageAttendance() {
    if (_mockSessions.isEmpty) return 0.0;
    final totalPercentage = _mockSessions.fold<double>(0, (sum, session) => sum + session.percentage);
    return totalPercentage / _mockSessions.length;
  }

  // Comprehensive Mock Data
  static final List<Student> _mockStudents = <Student>[
    Student(
      name: 'John Doe',
      matricle: 'CS2021001',
      department: 'Computer Science',
      level: 'Level 200',
      gender: 'Male',
      email: 'john.doe@university.edu',
    ),
    Student(
      name: 'Jane Smith',
      matricle: 'EE2021015',
      department: 'Electrical Engineering',
      level: 'Level 300',
      gender: 'Female',
      email: 'jane.smith@university.edu',
    ),
    Student(
      name: 'Mike Johnson',
      matricle: 'ME2020087',
      department: 'Mechanical Engineering',
      level: 'Level 400',
      gender: 'Male',
      email: 'mike.johnson@university.edu',
    ),
    Student(
      name: 'Sarah Williams',
      matricle: 'CS2022003',
      department: 'Computer Science',
      level: 'Level 100',
      gender: 'Female',
      email: 'sarah.williams@university.edu',
    ),
    Student(
      name: 'David Brown',
      matricle: 'MATH2021045',
      department: 'Mathematics',
      level: 'Level 300',
      gender: 'Male',
      email: 'david.brown@university.edu',
    ),
    Student(
      name: 'Emily Davis',
      matricle: 'PHY2020078',
      department: 'Physics',
      level: 'Level 400',
      gender: 'Female',
      email: 'emily.davis@university.edu',
    ),
    Student(
      name: 'Michael Wilson',
      matricle: 'CS2021089',
      department: 'Computer Science',
      level: 'Level 200',
      gender: 'Male',
      email: 'michael.wilson@university.edu',
    ),
    Student(
      name: 'Lisa Anderson',
      matricle: 'CHEM2022012',
      department: 'Chemistry',
      level: 'Level 100',
      gender: 'Female',
      email: 'lisa.anderson@university.edu',
    ),
    Student(
      name: 'Robert Taylor',
      matricle: 'EE2020056',
      department: 'Electrical Engineering',
      level: 'Level 400',
      gender: 'Male',
      email: 'robert.taylor@university.edu',
    ),
    Student(
      name: 'Jennifer Martinez',
      matricle: 'ME2021034',
      department: 'Mechanical Engineering',
      level: 'Level 300',
      gender: 'Female',
      email: 'jennifer.martinez@university.edu',
    ),
    Student(
      name: 'Christopher Lee',
      matricle: 'CS2022067',
      department: 'Computer Science',
      level: 'Level 100',
      gender: 'Male',
      email: 'christopher.lee@university.edu',
    ),
    Student(
      name: 'Amanda Garcia',
      matricle: 'MATH2021098',
      department: 'Mathematics',
      level: 'Level 300',
      gender: 'Female',
      email: 'amanda.garcia@university.edu',
    ),
    Student(
      name: 'Daniel Rodriguez',
      matricle: 'PHY2022023',
      department: 'Physics',
      level: 'Level 100',
      gender: 'Male',
      email: 'daniel.rodriguez@university.edu',
    ),
    Student(
      name: 'Michelle Thompson',
      matricle: 'CHEM2020045',
      department: 'Chemistry',
      level: 'Level 400',
      gender: 'Female',
      email: 'michelle.thompson@university.edu',
    ),
    Student(
      name: 'Kevin White',
      matricle: 'EE2021076',
      department: 'Electrical Engineering',
      level: 'Level 200',
      gender: 'Male',
      email: 'kevin.white@university.edu',
    ),
    Student(
      name: 'Ashley Harris',
      matricle: 'ME2022054',
      department: 'Mechanical Engineering',
      level: 'Level 100',
      gender: 'Female',
      email: 'ashley.harris@university.edu',
    ),
    Student(
      name: 'Ryan Clark',
      matricle: 'CS2020091',
      department: 'Computer Science',
      level: 'Level 400',
      gender: 'Male',
      email: 'ryan.clark@university.edu',
    ),
    Student(
      name: 'Nicole Lewis',
      matricle: 'MATH2022037',
      department: 'Mathematics',
      level: 'Level 100',
      gender: 'Female',
      email: 'nicole.lewis@university.edu',
    ),
    Student(
      name: 'Brandon Walker',
      matricle: 'PHY2021082',
      department: 'Physics',
      level: 'Level 200',
      gender: 'Male',
      email: 'brandon.walker@university.edu',
    ),
    Student(
      name: 'Stephanie Hall',
      matricle: 'CHEM2021063',
      department: 'Chemistry',
      level: 'Level 300',
      gender: 'Female',
      email: 'stephanie.hall@university.edu',
    ),
  ];

  static final List<Lecturer> _mockLecturers = <Lecturer>[
    Lecturer(
      name: 'Dr. Sarah Wilson',
      id: 'LEC001',
      department: 'Computer Science',
      email: 'sarah.wilson@university.edu',
      phone: '+237 123 456 789',
      courseCount: 3,
    ),
    Lecturer(
      name: 'Prof. David Brown',
      id: 'LEC002',
      department: 'Mathematics',
      email: 'david.brown@university.edu',
      phone: '+237 234 567 890',
      courseCount: 2,
    ),
    Lecturer(
      name: 'Dr. Lisa Chen',
      id: 'LEC003',
      department: 'Physics',
      email: 'lisa.chen@university.edu',
      phone: '+237 345 678 901',
      courseCount: 4,
    ),
    Lecturer(
      name: 'Prof. Michael Johnson',
      id: 'LEC004',
      department: 'Electrical Engineering',
      email: 'michael.johnson@university.edu',
      phone: '+237 456 789 012',
      courseCount: 3,
    ),
    Lecturer(
      name: 'Dr. Emily Davis',
      id: 'LEC005',
      department: 'Mechanical Engineering',
      email: 'emily.davis@university.edu',
      phone: '+237 567 890 123',
      courseCount: 2,
    ),
    Lecturer(
      name: 'Prof. Robert Taylor',
      id: 'LEC006',
      department: 'Chemistry',
      email: 'robert.taylor@university.edu',
      phone: '+237 678 901 234',
      courseCount: 3,
    ),
    Lecturer(
      name: 'Dr. Jennifer Martinez',
      id: 'LEC007',
      department: 'Computer Science',
      email: 'jennifer.martinez@university.edu',
      phone: '+237 789 012 345',
      courseCount: 4,
    ),
    Lecturer(
      name: 'Prof. Christopher Lee',
      id: 'LEC008',
      department: 'Mathematics',
      email: 'christopher.lee@university.edu',
      phone: '+237 890 123 456',
      courseCount: 2,
    ),
    Lecturer(
      name: 'Dr. Amanda Garcia',
      id: 'LEC009',
      department: 'Physics',
      email: 'amanda.garcia@university.edu',
      phone: '+237 901 234 567',
      courseCount: 3,
    ),
    Lecturer(
      name: 'Prof. Daniel Rodriguez',
      id: 'LEC010',
      department: 'Electrical Engineering',
      email: 'daniel.rodriguez@university.edu',
      phone: '+237 012 345 678',
      courseCount: 2,
    ),
  ];

  static final List<Course> _mockCourses = <Course>[
    Course(
      code: 'CS101',
      title: 'Introduction to Programming',
      department: 'Computer Science',
      level: 'Level 100',
      creditUnits: 3,
      semester: 'First Semester',
      lecturer: 'Dr. Sarah Wilson',
    ),
    Course(
      code: 'CS201',
      title: 'Data Structures & Algorithms',
      department: 'Computer Science',
      level: 'Level 200',
      creditUnits: 4,
      semester: 'First Semester',
      lecturer: 'Dr. Jennifer Martinez',
    ),
    Course(
      code: 'CS301',
      title: 'Database Systems',
      department: 'Computer Science',
      level: 'Level 300',
      creditUnits: 3,
      semester: 'Second Semester',
      lecturer: 'Dr. Sarah Wilson',
    ),
    Course(
      code: 'CS401',
      title: 'Software Engineering',
      department: 'Computer Science',
      level: 'Level 400',
      creditUnits: 4,
      semester: 'First Semester',
      lecturer: 'Dr. Jennifer Martinez',
    ),
    Course(
      code: 'MATH101',
      title: 'Calculus I',
      department: 'Mathematics',
      level: 'Level 100',
      creditUnits: 4,
      semester: 'First Semester',
      lecturer: 'Prof. David Brown',
    ),
    Course(
      code: 'MATH201',
      title: 'Linear Algebra',
      department: 'Mathematics',
      level: 'Level 200',
      creditUnits: 3,
      semester: 'Second Semester',
      lecturer: 'Prof. Christopher Lee',
    ),
    Course(
      code: 'MATH301',
      title: 'Discrete Mathematics',
      department: 'Mathematics',
      level: 'Level 300',
      creditUnits: 3,
      semester: 'First Semester',
      lecturer: 'Prof. David Brown',
    ),
    Course(
      code: 'PHY101',
      title: 'General Physics I',
      department: 'Physics',
      level: 'Level 100',
      creditUnits: 4,
      semester: 'First Semester',
      lecturer: 'Dr. Lisa Chen',
    ),
    Course(
      code: 'PHY201',
      title: 'Mechanics',
      department: 'Physics',
      level: 'Level 200',
      creditUnits: 3,
      semester: 'Second Semester',
      lecturer: 'Dr. Amanda Garcia',
    ),
    Course(
      code: 'PHY301',
      title: 'Thermodynamics',
      department: 'Physics',
      level: 'Level 300',
      creditUnits: 3,
      semester: 'First Semester',
      lecturer: 'Dr. Lisa Chen',
    ),
    Course(
      code: 'PHY401',
      title: 'Quantum Physics',
      department: 'Physics',
      level: 'Level 400',
      creditUnits: 4,
      semester: 'Second Semester',
      lecturer: 'Dr. Amanda Garcia',
    ),
    Course(
      code: 'EE101',
      title: 'Circuit Analysis',
      department: 'Electrical Engineering',
      level: 'Level 100',
      creditUnits: 3,
      semester: 'First Semester',
      lecturer: 'Prof. Michael Johnson',
    ),
    Course(
      code: 'EE201',
      title: 'Digital Logic Design',
      department: 'Electrical Engineering',
      level: 'Level 200',
      creditUnits: 4,
      semester: 'Second Semester',
      lecturer: 'Prof. Daniel Rodriguez',
    ),
    Course(
      code: 'EE301',
      title: 'Microprocessors',
      department: 'Electrical Engineering',
      level: 'Level 300',
      creditUnits: 3,
      semester: 'First Semester',
      lecturer: 'Prof. Michael Johnson',
    ),
    Course(
      code: 'ME101',
      title: 'Engineering Drawing',
      department: 'Mechanical Engineering',
      level: 'Level 100',
      creditUnits: 2,
      semester: 'First Semester',
      lecturer: 'Dr. Emily Davis',
    ),
    Course(
      code: 'ME201',
      title: 'Statics',
      department: 'Mechanical Engineering',
      level: 'Level 200',
      creditUnits: 3,
      semester: 'Second Semester',
      lecturer: 'Dr. Emily Davis',
    ),
    Course(
      code: 'CHEM101',
      title: 'General Chemistry',
      department: 'Chemistry',
      level: 'Level 100',
      creditUnits: 4,
      semester: 'First Semester',
      lecturer: 'Prof. Robert Taylor',
    ),
    Course(
      code: 'CHEM201',
      title: 'Organic Chemistry',
      department: 'Chemistry',
      level: 'Level 200',
      creditUnits: 4,
      semester: 'Second Semester',
      lecturer: 'Prof. Robert Taylor',
    ),
  ];

  static final List<GeofenceLocation> _mockGeofenceLocations = <GeofenceLocation>[
    GeofenceLocation(
      name: 'Lecture Hall A',
      latitude: 5.9547,
      longitude: 10.1697,
      radius: 50,
      description: 'Main lecture hall for large classes',
      isActive: true,
    ),
    GeofenceLocation(
      name: 'Computer Lab 1',
      latitude: 5.9548,
      longitude: 10.1698,
      radius: 30,
      description: 'Primary computer laboratory',
      isActive: true,
    ),
    GeofenceLocation(
      name: 'Physics Laboratory',
      latitude: 5.9549,
      longitude: 10.1699,
      radius: 40,
      description: 'Physics lab building with equipment',
      isActive: false,
    ),
    GeofenceLocation(
      name: 'Engineering Workshop',
      latitude: 5.9550,
      longitude: 10.1700,
      radius: 60,
      description: 'Mechanical engineering workshop',
      isActive: true,
    ),
    GeofenceLocation(
      name: 'Chemistry Lab',
      latitude: 5.9551,
      longitude: 10.1701,
      radius: 35,
      description: 'Chemistry laboratory with fume hoods',
      isActive: true,
    ),
    GeofenceLocation(
      name: 'Library Study Hall',
      latitude: 5.9552,
      longitude: 10.1702,
      radius: 45,
      description: 'Quiet study area in main library',
      isActive: true,
    ),
    GeofenceLocation(
      name: 'Lecture Hall B',
      latitude: 5.9553,
      longitude: 10.1703,
      radius: 50,
      description: 'Secondary lecture hall',
      isActive: true,
    ),
    GeofenceLocation(
      name: 'Computer Lab 2',
      latitude: 5.9554,
      longitude: 10.1704,
      radius: 30,
      description: 'Advanced programming laboratory',
      isActive: false,
    ),
    GeofenceLocation(
      name: 'Mathematics Classroom',
      latitude: 5.9555,
      longitude: 10.1705,
      radius: 25,
      description: 'Specialized math classroom with smart boards',
      isActive: true,
    ),
    GeofenceLocation(
      name: 'Electrical Lab',
      latitude: 5.9556,
      longitude: 10.1706,
      radius: 40,
      description: 'Electrical engineering laboratory',
      isActive: true,
    ),
  ];

  static final List<AttendanceSession> _mockSessions = <AttendanceSession>[
    AttendanceSession(
      courseCode: 'CS301',
      courseName: 'Database Systems',
      dateTime: DateTime.now().subtract(const Duration(hours: 2)),
      presentCount: 28,
      totalCount: 35,
    ),
    AttendanceSession(
      courseCode: 'MATH201',
      courseName: 'Linear Algebra',
      dateTime: DateTime.now().subtract(const Duration(hours: 4)),
      presentCount: 42,
      totalCount: 45,
    ),
    AttendanceSession(
      courseCode: 'PHY401',
      courseName: 'Quantum Physics',
      dateTime: DateTime.now().subtract(const Duration(days: 1)),
      presentCount: 18,
      totalCount: 25,
    ),
    AttendanceSession(
      courseCode: 'CS201',
      courseName: 'Data Structures & Algorithms',
      dateTime: DateTime.now().subtract(const Duration(hours: 6)),
      presentCount: 32,
      totalCount: 38,
    ),
    AttendanceSession(
      courseCode: 'EE301',
      courseName: 'Microprocessors',
      dateTime: DateTime.now().subtract(const Duration(hours: 8)),
      presentCount: 24,
      totalCount: 30,
    ),
    AttendanceSession(
      courseCode: 'CHEM201',
      courseName: 'Organic Chemistry',
      dateTime: DateTime.now().subtract(const Duration(days: 1, hours: 2)),
      presentCount: 19,
      totalCount: 22,
    ),
    AttendanceSession(
      courseCode: 'ME201',
      courseName: 'Statics',
      dateTime: DateTime.now().subtract(const Duration(days: 1, hours: 4)),
      presentCount: 26,
      totalCount: 28,
    ),
    AttendanceSession(
      courseCode: 'CS101',
      courseName: 'Introduction to Programming',
      dateTime: DateTime.now().subtract(const Duration(days: 2)),
      presentCount: 45,
      totalCount: 50,
    ),
    AttendanceSession(
      courseCode: 'PHY201',
      courseName: 'Mechanics',
      dateTime: DateTime.now().subtract(const Duration(days: 2, hours: 3)),
      presentCount: 33,
      totalCount: 40,
    ),
    AttendanceSession(
      courseCode: 'MATH301',
      courseName: 'Discrete Mathematics',
      dateTime: DateTime.now().subtract(const Duration(days: 3)),
      presentCount: 29,
      totalCount: 35,
    ),
    AttendanceSession(
      courseCode: 'EE201',
      courseName: 'Digital Logic Design',
      dateTime: DateTime.now().subtract(const Duration(days: 3, hours: 2)),
      presentCount: 21,
      totalCount: 25,
    ),
    AttendanceSession(
      courseCode: 'CS401',
      courseName: 'Software Engineering',
      dateTime: DateTime.now().subtract(const Duration(days: 4)),
      presentCount: 16,
      totalCount: 20,
    ),
    AttendanceSession(
      courseCode: 'PHY301',
      courseName: 'Thermodynamics',
      dateTime: DateTime.now().subtract(const Duration(days: 4, hours: 5)),
      presentCount: 22,
      totalCount: 27,
    ),
    AttendanceSession(
      courseCode: 'CHEM101',
      courseName: 'General Chemistry',
      dateTime: DateTime.now().subtract(const Duration(days: 5)),
      presentCount: 38,
      totalCount: 42,
    ),
    AttendanceSession(
      courseCode: 'ME101',
      courseName: 'Engineering Drawing',
      dateTime: DateTime.now().subtract(const Duration(days: 5, hours: 3)),
      presentCount: 31,
      totalCount: 35,
    ),
  ];

  static final Map<String, dynamic> _mockSettings = <String, dynamic>{
    'academicYear': '2024/2025',
    'semester': 'First Semester',
    'facultyName': 'Faculty of Science and Technology',
    'sessionDuration': 120,
    'geofenceRadius': 50,
    'confidenceThreshold': 0.85,
    'appTheme': 'light',
    'autoBackup': true,
    'notificationsEnabled': true,
    'faceRecognitionEnabled': true,
    'geofencingEnabled': true,
    'maxStudentsPerSession': 100,
    'attendanceGracePeriod': 15,
    'lowAttendanceThreshold': 75,
    'systemLanguage': 'English',
    'timeZone': 'Africa/Douala',
    'dateFormat': 'DD/MM/YYYY',
    'timeFormat': '24-hour',
  };
}
