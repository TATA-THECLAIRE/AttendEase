import 'package:flutter/material.dart';
import 'services/auth_service.dart';
import 'services/api_service.dart';
import 'screens/auth/welcome_screen.dart';
import 'screens/student_dashboard.dart';
import 'screens/lecturer/lecturer_dashboard.dart';
import 'screens/admin/admin_main_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // Initialize services
  await AuthService().initialize();
  
  // Check backend health
  final isBackendHealthy = await ApiService().checkHealth();
  if (!isBackendHealthy) {
    print('Warning: Backend is not responding');
  }
  
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Attendease',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: AuthWrapper(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class AuthWrapper extends StatefulWidget {
  @override
  _AuthWrapperState createState() => _AuthWrapperState();
}

class _AuthWrapperState extends State<AuthWrapper> {
  final AuthService _authService = AuthService();

  @override
  Widget build(BuildContext context) {
    if (_authService.isLoggedIn) {
      final user = _authService.currentUser!;
      
      switch (user.role.toLowerCase()) {
        case 'student':
          return StudentDashboard();
        case 'lecturer':
          return LecturerDashboard();
        case 'admin':
          return AdminMainScreen();
        default:
          return WelcomeScreen();
      }
    } else {
      return WelcomeScreen();
    }
  }
}
