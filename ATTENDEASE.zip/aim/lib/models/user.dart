// models/user.dart
class User {
  final String id;
  final String email;
  final String fullName;
  final String role;
  final String? phoneNumber;
  final String? studentId;
  final String? department;
  final int? yearOfStudy;
  final String? employeeId;
  final String? specialization;
  final bool isEmailVerified;
  final String status;
  final DateTime? lastLogin;
  final DateTime createdAt;
  final String? matricule;

  User({
    required this.id,
    required this.email,
    required this.fullName,
    required this.role,
    this.phoneNumber,
    this.studentId,
    this.department,
    this.yearOfStudy,
    this.employeeId,
    this.specialization,
    required this.isEmailVerified,
    required this.status,
    this.lastLogin,
    this.matricule,
    required this.createdAt,
  });

  factory User.fromJson(Map<String, dynamic> json) {
    return User(
      id: json['id'].toString(),
      email: json['email'],
      fullName: json['full_name'],
      role: json['role'],
      phoneNumber: json['phone_number'],
      studentId: json['student_id'],
      department: json['department'],
      yearOfStudy: json['year_of_study'],
      employeeId: json['employee_id'],
      specialization: json['specialization'],
      isEmailVerified: json['is_email_verified'] ?? false,
      status: json['status'],
      lastLogin: json['last_login'] != null 
          ? DateTime.parse(json['last_login']) 
          : null,
      createdAt: DateTime.parse(json['created_at']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'email': email,
      'full_name': fullName,
      'role': role,
      'phone_number': phoneNumber,
      'student_id': studentId,
      'department': department,
      'year_of_study': yearOfStudy,
      'employee_id': employeeId,
      'specialization': specialization,
      'is_email_verified': isEmailVerified,
      'status': status,
      'last_login': lastLogin?.toIso8601String(),
      'created_at': createdAt.toIso8601String(),
    };
  }
}
