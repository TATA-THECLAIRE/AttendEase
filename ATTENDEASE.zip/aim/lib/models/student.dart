class Student {
  final String id;
  final String name;
  final String matricle;
  final String level;
  final String department;

  Student({
    required this.id,
    required this.name,
    required this.matricle,
    required this.level,
    required this.department,
  });
}
