// attendance_record.dart
class AttendanceRecord {
  final String id;
  final String course;
  final String date;
  final String time;
  final String status;
  final String? checkInTime;
  final String location;
  final String? confidence;
  final String topic;
  final String duration;
  final int classSize;
  final int attendanceCount;
  final String semester;

  AttendanceRecord({
    required this.id,
    required this.course,
    required this.date,
    required this.time,
    required this.status,
    this.checkInTime,
    required this.location,
    this.confidence,
    required this.topic,
    required this.duration,
    required this.classSize,
    required this.attendanceCount,
    required this.semester,
  });
}
