// models/session.dart
class AttendanceSession {
  final String id;
  final String courseId;
  final String lecturerId;
  final DateTime startTime;
  final DateTime? endTime;
  final bool isActive;
  final List<String> geofence; // [lat, lng, radius]
  final int attendanceCount;

  AttendanceSession({
    required this.id,
    required this.courseId,
    required this.lecturerId,
    required this.startTime,
    this.endTime,
    required this.isActive,
    required this.geofence,
    this.attendanceCount = 0,
  });

  Map<String, dynamic> toJson() => {
    'id': id,
    'courseId': courseId,
    'lecturerId': lecturerId,
    'startTime': startTime.toIso8601String(),
    'endTime': endTime?.toIso8601String(),
    'isActive': isActive,
    'geofence': geofence,
    'attendanceCount': attendanceCount,
  };

  factory AttendanceSession.fromJson(Map<String, dynamic> json) => AttendanceSession(
    id: json['id'],
    courseId: json['courseId'],
    lecturerId: json['lecturerId'],
    startTime: DateTime.parse(json['startTime']),
    endTime: json['endTime'] != null ? DateTime.parse(json['endTime']) : null,
    isActive: json['isActive'],
    geofence: List<String>.from(json['geofence']),
    attendanceCount: json['attendanceCount'] ?? 0,
  );
}
