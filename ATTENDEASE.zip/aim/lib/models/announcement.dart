enum AnnouncementType {
  classCancelled,
  reminder,
  courseMaterial,
  general,
}

class Announcement {
  final String id;
  final String title;
  final String message;
  final String courseCode;
  final DateTime timestamp;
  final AnnouncementType type;

  Announcement({
    required this.id,
    required this.title,
    required this.message,
    required this.courseCode,
    required this.timestamp,
    required this.type,
  });
}
