enum CourseStatus {
  present,
  absent,
  pending,
  upcoming,
}