class Student {
  final String name;
  final String matricle;
  final String department;
  final String level;
  final String gender;
  final String email;

  Student({
    required this.name,
    required this.matricle,
    required this.department,
    required this.level,
    required this.gender,
    required this.email,
  });
}

class Lecturer {
  final String name;
  final String id;
  final String department;
  final String email;
  final String phone;
  final int courseCount;

  Lecturer({
    required this.name,
    required this.id,
    required this.department,
    required this.email,
    required this.phone,
    this.courseCount = 0,
  });
}

class Course {
  final String code;
  final String title;
  final String department;
  final String level;
  final int creditUnits;
  final String semester;
  final String lecturer;

  Course({
    required this.code,
    required this.title,
    required this.department,
    required this.level,
    required this.creditUnits,
    required this.semester,
    required this.lecturer,
  });
}

class GeofenceLocation {
  final String name;
  final double latitude;
  final double longitude;
  final int radius;
  final String description;
  final bool isActive;

  GeofenceLocation({
    required this.name,
    required this.latitude,
    required this.longitude,
    required this.radius,
    required this.description,
    this.isActive = true,
  });
}

class AttendanceSession {
  final String courseCode;
  final String courseName;
  final DateTime dateTime;
  final int presentCount;
  final int totalCount;
  final double percentage;

  AttendanceSession({
    required this.courseCode,
    required this.courseName,
    required this.dateTime,
    required this.presentCount,
    required this.totalCount,
  }) : percentage = (presentCount / totalCount * 100);
}
