import 'course_status.dart';

class Course {
  final String id;
  final String code;
  final String name;
  final String description;
  final String department;
  final int creditHours;
  final String semester;
  final String? lecturerId;
  final bool isActive;
  final DateTime createdAt;
  
  // Additional properties needed by the app
  final String type;
  final String lecturer;
  final String time;
  CourseStatus status;
  bool isCheckedIn;
  final String schedule;
  final double attendancePercentage;
  final int sessionsAttended;
  final int totalSessions;
  final int onTime;
  final int late;

  Course({
    required this.id,
    required this.code,
    required this.name,
    required this.description,
    required this.department,
    required this.creditHours,
    required this.semester,
    this.lecturerId,
    required this.isActive,
    required this.createdAt,
    this.type = '',
    this.lecturer = '',
    this.time = '',
    this.status = CourseStatus.pending,
    this.isCheckedIn = false,
    this.schedule = '',
    this.attendancePercentage = 0.0,
    this.sessionsAttended = 0,
    this.totalSessions = 0,
    this.onTime = 0,
    this.late = 0,
  });

  factory Course.fromJson(Map<String, dynamic> json) {
    return Course(
      id: json['id'].toString(),
      code: json['code'],
      name: json['name'],
      description: json['description'] ?? '',
      department: json['department'],
      creditHours: json['credit_hours'],
      semester: json['semester'],
      lecturerId: json['lecturer_id']?.toString(),
      isActive: json['is_active'] ?? true,
      createdAt: DateTime.parse(json['created_at']),
      // Additional properties can be populated if available in the JSON
      lecturer: json['lecturer_name'] ?? '',
      type: json['type'] ?? '',
      time: json['time'] ?? '',
      schedule: json['schedule'] ?? '',
      attendancePercentage: json['attendance_percentage']?.toDouble() ?? 0.0,
      sessionsAttended: json['sessions_attended'] ?? 0,
      totalSessions: json['total_sessions'] ?? 0,
      onTime: json['on_time'] ?? 0,
      late: json['late'] ?? 0,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'code': code,
      'name': name,
      'description': description,
      'department': department,
      'credit_hours': creditHours,
      'semester': semester,
      'lecturer_id': lecturerId,
      'is_active': isActive,
      'created_at': createdAt.toIso8601String(),
      // Additional properties
      'lecturer_name': lecturer,
      'type': type,
      'time': time,
      'schedule': schedule,
      'attendance_percentage': attendancePercentage,
      'sessions_attended': sessionsAttended,
      'total_sessions': totalSessions,
      'on_time': onTime,
      'late': late,
    };
  }
}
