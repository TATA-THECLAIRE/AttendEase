// models/attendance.dart
class AttendanceRecord {
  final String id;
  final String studentId;
  final String sessionId;
  final String courseId;
  final DateTime timestamp;
  final AttendanceStatus status;
  final String? notes;
  final bool isManualOverride;
  final String? overrideBy;

  AttendanceRecord({
    required this.id,
    required this.studentId,
    required this.sessionId,
    required this.courseId,
    required this.timestamp,
    required this.status,
    this.notes,
    this.isManualOverride = false,
    this.overrideBy,
  });

  Map<String, dynamic> toJson() => {
    'id': id,
    'studentId': studentId,
    'sessionId': sessionId,
    'courseId': courseId,
    'timestamp': timestamp.toIso8601String(),
    'status': status.name,
    'notes': notes,
    'isManualOverride': isManualOverride,
    'overrideBy': overrideBy,
  };

  factory AttendanceRecord.fromJson(Map<String, dynamic> json) => AttendanceRecord(
    id: json['id'],
    studentId: json['studentId'],
    sessionId: json['sessionId'],
    courseId: json['courseId'],
    timestamp: DateTime.parse(json['timestamp']),
    status: AttendanceStatus.values.firstWhere((e) => e.name == json['status']),
    notes: json['notes'],
    isManualOverride: json['isManualOverride'] ?? false,
    overrideBy: json['overrideBy'],
  );
}

enum AttendanceStatus { present, absent, late, excused }
