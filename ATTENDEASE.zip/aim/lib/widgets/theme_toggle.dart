import 'package:flutter/material.dart';

class ThemeToggle extends StatelessWidget {
  final VoidCallback onToggle;

  const ThemeToggle({Key? key, required this.onToggle}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    
    return IconButton(
      onPressed: onToggle,
      icon: Icon(
        isDark ? Icons.wb_sunny : Icons.nightlight_round,
        color: Colors.white,
      ),
      style: IconButton.styleFrom(
        backgroundColor: Colors.white.withOpacity(0.2),
        shape: CircleBorder(),
      ),
    );
  }
}
